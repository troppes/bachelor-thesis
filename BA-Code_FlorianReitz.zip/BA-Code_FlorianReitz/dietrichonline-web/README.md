# Dietrich-Online

Das Projekt Dietrich-Online enthält Masken und Werkzeuge zum Suchen und Bearbeiten einer Datenbank mit ca. 5. Mio Datensätzen.

## Struktur

### Repositorium

Momentan besteht das Gesamtprojekt aus zwei Teilprojekten:
- Das [Web-Projekt](https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web) verwaltet die Such-Plattform des Projekts.
- Das [Datenbank-Projekt](https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-datenbank) verwaltet Änderungsskripte und Werkzeuge für die Datenbank.

### Ordner

| Ordner | Inhalt |
| --- | --- |
| `app` | Konfigurationsdateien (`app/config`) und [Twig-Templates](https://twig.symfony.com/) (`app/Resources/views`) |
| `bin` | Ausführbare Scripte des [Symfony-Frameworks](https://symfony.com/) |
| `scripts` | Eigene ausführbare Scripte nach Laufzeitumgebung (`dev`, `install`, `prod`) |
| `src` | Der Quellcode |
| `test` | Die Testfälle |
| `web` | Symfony-Framework-Verzeichnis für öffentliche Dateien (z.B. Bilder, css- und js-Dateien) |

## Externe Abhängigkeiten

Siehe [Wiki](https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/wikis/home#externe-abh%C3%A4ngigkeiten)

## Installation

Siehe [Wiki](https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/wikis/Install-and-Setup)

## Bekannte Fehler und Bug-Reports

Siehe [Issue-Tracker](https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/issues)

## Changelog

Weitere Details im [Changelog](https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/wikis/changelog) (*atm in der Wiki geführt*).
