#!/bin/bash

# 
# @author: Martin Kock <kock@uni-trier.de>
#
# Installs automatically the last composer.phar into the root directory.

set +x
 
#>>
# setup of local vars
#>>
readonly TRUE=1
readonly FALSE=0
DEBUG="${FALSE}"

readonly LOG_OK=" OK "
readonly LOG_INFO="INFO"
readonly LOG_DEBUG="DEBG"
readonly LOG_ERROR="EXCP"
readonly LOG_UNKNOWN=" ?? "

#>>
# runtime calls
#>>

# caller dir
PWD_DIR="$(pwd)"
 
# script dir
SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )


#>>
# functions 
#>>
function echo_log {
    if [ $# -ne 0 ]; then
        if [ $# -eq 1 ]; then
            echo_log "${LOG_UNKNOWN}" "${1}"
        elif [ $# -eq 2 ]; then
        	local out_stage="${1}"
        	$(is_log_state_accepted "${1}")
        	local log_stage_accepted=$?
        	if [ ${log_stage_accepted} -ne ${TRUE} ]; then
        		out_stage="${LOG_UNKNOWN}"
        	fi
            echo "[${out_stage}]" "${2}"
        else
            echo_log "${1}" "${2}"
        fi
    fi
}

function is_log_state_accepted {
	local state=${FALSE}
	
	if [ $# -eq 1 ]; then
		case "${1}" in
			"${LOG_OK}" | "${LOG_INFO}" | "${LOG_DEBUG}" | "${LOG_ERROR}" | "${LOG_UNKNOWN}")
			state=${TRUE}
			;;
			
		*)
			state=${FALSE}
			;;
					
		esac
    fi
    
    return ${state}
}

COMPOSER_URL="https://raw.githubusercontent.com/composer/getcomposer.org"
COMPOSER_VERSION="1.8.3"
COMPOSER_VERSION_ID="da7be05fa1c9f68b9609726451d1aaac7dd832cb"
COMPOSER_INSTALL_DIR="${SCRIPT_DIR}/../.."

echo_log "${LOG_INFO}" "Install composer to root dir."
echo_log "${LOG_INFO}" "Download URL: ${COMPOSER_URL}"
echo_log "${LOG_INFO}" "Version URL-ID: ${COMPOSER_VERSION_ID}"
echo_log "${LOG_INFO}" "Start"

# https://getcomposer.org/doc/faqs/how-to-install-composer-programmatically.md
# exec the following code without the brackets ($( ... ), because the return value of wget will change to 127 (normally an error)
cd "${COMPOSER_INSTALL_DIR}"; wget "${COMPOSER_URL}/${COMPOSER_VERSION_ID}/web/installer" -O - -q | php -- --quiet

if [ "$?" -ne 0 ]; then
    echo_log "${LOG_ERROR}" "An error occured while downloading composer."
    echo_log "${LOG_INFO}" "Check <${COMPOSER_URL}/${COMPOSER_VERSION_ID}/web/installer -O - -q | php -- --quiet> manually."
    exit 1
else
    echo_log "${LOG_OK}" "Composer v${COMPOSER_VERSION} successfully downloaded and installed in the root directory (<${COMPOSER_INSTALL_DIR}>) of the project."
fi

exit 0
