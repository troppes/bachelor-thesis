#!/usr/bin/env bash

docker exec dietrich_web php /var/www/html/dietrich/htdocs/bin/console cache:clear --no-warmup --env=prod
docker exec dietrich_web php /var/www/html/dietrich/htdocs/bin/console cache:clear --no-warmup --env=dev
docker exec dietrich_web php /var/www/html/dietrich/htdocs/bin/console doctrine:cache:clear-metadata
docker exec dietrich_web php /var/www/html/dietrich/htdocs/bin/console doctrine:cache:clear-query
docker exec dietrich_web php /var/www/html/dietrich/htdocs/bin/console doctrine:cache:clear-result

docker exec dietrich_web mkdir -p /var/www/html/dietrich/htdocs/bin/var
docker exec dietrich_web mkdir -p /var/www/html/dietrich/htdocs/bin/var/cache
docker exec dietrich_web mkdir -p /var/www/html/dietrich/htdocs/bin/var/log
docker exec dietrich_web mkdir -p /var/www/html/dietrich/htdocs/bin/var/sessions
docker exec dietrich_web chmod -R 777 /var/www/html/dietrich/htdocs/bin/var
