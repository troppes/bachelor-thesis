php /var/www/html/dietrich/htdocs/bin/console cache:clear --no-warmup --env=prod
php /var/www/html/dietrich/htdocs/bin/console cache:clear --no-warmup --env=dev
php /var/www/html/dietrich/htdocs/bin/console doctrine:cache:clear-metadata
php /var/www/html/dietrich/htdocs/bin/console doctrine:cache:clear-query
php /var/www/html/dietrich/htdocs/bin/console doctrine:cache:clear-result

mkdir -p /var/www/html/dietrich/htdocs/bin/var
mkdir -p /var/www/html/dietrich/htdocs/bin/var/cache
mkdir -p /var/www/html/dietrich/htdocs/bin/var/log
mkdir -p /var/www/html/dietrich/htdocs/bin/var/sessions
chmod -R 777 /var/www/html/dietrich/htdocs/bin/var

( cd /var/www/html/dietrich/htdocs && composer dump-autoload --optimize --classmap-authoritative )

exec "apache2-foreground"