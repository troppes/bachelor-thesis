#!/bin/bash

set +x

readonly TRUE=1
readonly FALSE=0

# caller dir
# shellcheck disable=SC2034
readonly PWD_DIR="$(pwd)"

# script dir
readonly SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)

CONFIG_FILE="${SCRIPT_DIR}/config.ini"
if [ ! -r "${CONFIG_FILE}" ]; then
  echo "[ERR!] Config file <${CONFIG_FILE}> does not exists."
  exit 1
fi
# shellcheck source=./config.ini
source "${CONFIG_FILE}" #read from config.ini

# configs
readonly CACHE_GROUP="dietrich-cache"
readonly VAR_DIR_PATH="${SCRIPT_DIR}/../../var"
readonly CACHE_FOLDER="cache/prod"
readonly VAR_BACKUP_NAME="var-cache-prod-$(date +%Y-%m-%d_%H%M%S)"
readonly VAR_BACKUP_PATH="${SCRIPT_DIR}/${TMP_DIR}/${VAR_BACKUP_NAME}"
readonly SYMFONY_CONSOLE_PATH="${SCRIPT_DIR}/../../bin"
readonly SYMFONY_CONSOLE_VERBOSE="-vvv"
readonly PHP_MEMORY_LIMIT="3G"
# log-file
readonly LOG_FILE_NAME="clear_cache.log"
readonly LOG_FILE_FOLDER="${VAR_DIR_PATH}/logs"
readonly LOG_FILE_PATH="${LOG_FILE_FOLDER}/${LOG_FILE_NAME}"
# backup-config
readonly BACKUP_SOURCE="${VAR_DIR_PATH}/${CACHE_FOLDER}"
readonly BACKUP_DESTINATION="${VAR_BACKUP_PATH}"

#globals
IS_CACHE_WARMUP=${TRUE}

# logs ok messages to stdout and logfile
function ok() {
  printf '%s [ OK ] %s\n' "$(date --rfc-3339=seconds)" "$@" | tee -a "${LOG_FILE_PATH}"
}

# logs info messages to stdout and logfile
function info() {
  printf '%s [INFO] %s\n' "$(date --rfc-3339=seconds)" "$@" | tee -a "${LOG_FILE_PATH}"
}

# logs error messages to stdout and logfile
function err() {
  printf '%s [ERR!] %s\n' "$(date --rfc-3339=seconds)" "$@" | tee -a "${LOG_FILE_PATH}" >&2
}

# Execution for manually aborted runs.
function manually_aborted() {
  info "Manually aborted with ctrl-c"
  exit 1
}
# Catches manually aborted runs (CTRL+C)
trap manually_aborted SIGINT

# Backups the cache folder of the symfony application.
# <p>
# If the cache folder doesn't exists, it will skip.
function backup_cache() {
  info "Check existing cache."

  # check cache source exists
  if ! test -d "${BACKUP_SOURCE}"; then
    info "No cache exists at <${BACKUP_SOURCE}>. Skip backup."
  else
    info "Move cache (filesystem)."
    info "- source:  <${BACKUP_SOURCE}>"
    info "- to dest: <${BACKUP_DESTINATION}>"
    mv "${BACKUP_SOURCE}" "${BACKUP_DESTINATION}"
  fi
}

# Creates a directory with the given permissions
# <p>
# Exits when something went wrong.
#
# @args 1 path The path to create the directory
# @args 2 permissions The permissions to set.
function create_directory_with_permission() {
  local path="${1}"
  local permissions="${2}"
  #info "- Try to create directory <${path}> with permissions <${permissions}>."

  if ! mkdir -p "${path}"; then
    err "- Can't create directory <${path}>."
    exit 1
  fi

  if ! chmod "${permissions}" "${path}"; then
    err "- Can't set permissions for directory <${path}> to <${permissions}>."
    exit 2
  fi

  ok "- Directory <${path}> with permissions <${permissions}> successfully created."
}

# Creates the subdirectories for the var folder and sets the permissons of them to 777.
# <p>
# 7s74 is ok, because the Webserver creates file for another user within.
# Otherwise the browser can't access the files and the webpage will be blank only.
function create_subdires_with_permissions() {
  info "Validate subdirectories for folder var"
  create_directory_with_permission "${VAR_DIR_PATH}/cache" 'u=rwx,g=srwx,o=rwx'
  create_directory_with_permission "${VAR_DIR_PATH}/cache/prod" 'u=rwx,g=srwx,o=rwx'
  create_directory_with_permission "${VAR_DIR_PATH}/logs" 'u=rwx,g=srwx,o=rwx'
  create_directory_with_permission "${VAR_DIR_PATH}/sessions" 'u=rwx,g=srwx,o=rwx'
  ok "Subdirectories successfully created."
}

# Calls the symfony console to clear and rebuild the cache.
# <p>
# For more informations start the command with <code>-vvv</code> and without the <code>--no-debug</code> arguments.
# <p>
# Prints symfony execution errors into the log file.
function symfony_cache_rebuild() {
  info "Clear cache (symfony-console with php memory <${PHP_MEMORY_LIMIT}>)."
  cd "${SYMFONY_CONSOLE_PATH}" || exit 1
  if ! php -dmemory_limit="${PHP_MEMORY_LIMIT}" console "${SYMFONY_CONSOLE_VERBOSE}" cache:clear --no-warmup --env=prod --no-debug 2>>"${LOG_FILE_PATH}"; then
    err "Clear cache aborted with errors."
    err "> run manually: cd ${SYMFONY_CONSOLE_PATH}; php -dmemory_limit=${PHP_MEMORY_LIMIT} console ${SYMFONY_CONSOLE_VERBOSE} cache:clear --no-warmup --env=prod --no-debug"
    exit 2
  fi

  if [ ${IS_CACHE_WARMUP} -eq ${FALSE} ]; then
    info "$(basename "${0}") started with option \"no cache warmup\". So skip cache:warmup."
    return
  fi

  info "Warm up cache (symfony-console with php memory <${PHP_MEMORY_LIMIT}>)."
  cd "${SYMFONY_CONSOLE_PATH}" || exit 1
  if ! php -dmemory_limit="${PHP_MEMORY_LIMIT}" console cache:warmup --env=prod 2>>"${LOG_FILE_PATH}"; then
    err "Warm up cache aborted with errors."
    err "> run manually for more details: cd ${SYMFONY_CONSOLE_PATH}; php -dmemory_limit=${PHP_MEMORY_LIMIT} console ${SYMFONY_CONSOLE_VERBOSE} cache:warmup --env=prod"
    exit 4
  fi
}

# Sets the user permissions for the var folder
# <p>
# I think, that it is a historic one but we don't know it yet.
function set_user_permissions_for_var_folder() {
  info "Check user for cache permission exists."
  grep </etc/group "^${CACHE_GROUP}:"

  # shellcheck disable=SC2181
  if [ $? -ne 0 ]; then
    err "User <${CACHE_GROUP}> does not exists."
    info "May it's ok to change the permissions to <g=rwx> recursive for <var> manually."
  else
    info "Change permissions of folder <var> to <${CACHE_GROUP}:g=rwx>."
    chgrp --recursive "${CACHE_GROUP}" "${VAR_DIR_PATH}"
    chmod --recursive g=rwx "${VAR_DIR_PATH}"
  fi
}

# Initializate the logging components.
# <p>
# Checks that the folder for the logging exists and is writeable
function init_log() {
  echo "[INFO] Logging initialization started."
  if ! test -d "${LOG_FILE_FOLDER}"; then
    echo "[INFO] Log folder doesn't exists at <${LOG_FILE_FOLDER}>."
    create_directory_with_permission "${LOG_FILE_FOLDER}" 'u=rwx,g=srwx,o=r'
  fi

  echo "[ OK ] Logging initialization successfully finished."
}

# Print the help to stdout
function print_help() {
  cat << EOF
    The following commands are possible with $(basename "${0}").

    no arguments:
        The script makes a backup:
        - from: ${BACKUP_SOURCE}
        - to  : ${BACKUP_DESTINATION}
        and checks the the var directory with permissions.
        After that it will use the symfony console to
        - clear the cache
        - warm the cache up

        Note: if you have problems with the warmup and a blank white page in your browser
              have a look for the "$(basename "${0}") -no-cw" option.

    -no-cw | --no-cache-warmup
        Excludes the cache warmup while running.
        The webserver calls will create the needed files on the fly (maybe slower while startup)

    -h | --help
        Prints this help
EOF
}

###
# MAIN-Loop
###
function main() {
  init_log
  info "Rebuild cache for PROD environment."
  backup_cache
  create_subdires_with_permissions
  symfony_cache_rebuild
  ok "Rebuild cache successfully finished for PROD environment."
}

###
# CLI arguments
###
if [ $# -eq 0 ]; then
  main
else
  case "${1}" in
    -no-cw | --no-cache-warmup)
      IS_CACHE_WARMUP=${FALSE}
      main
      ;;

    -h | --help | *)
      print_help
      ;;
  esac
fi