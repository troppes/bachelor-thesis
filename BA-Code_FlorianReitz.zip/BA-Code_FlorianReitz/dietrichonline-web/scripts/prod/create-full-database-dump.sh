#!/bin/bash

#
# @author: Martin Kock <kock@uni-trier.de>
#
# Creates a standardized database dump into the temp sql directory.

set +x

# caller dir
# shellcheck disable=SC2034
readonly PWD_DIR="$(pwd)"

# script dir
readonly SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )

CONFIG_FILE="${SCRIPT_DIR}/config.ini"
if [ ! -r "${CONFIG_FILE}" ]; then
  echo "[ERR!] Config file <${CONFIG_FILE}> does not exists."
  exit 1
fi
# shellcheck source=./config.ini
source "${CONFIG_FILE}" #read from config.ini

readonly DATE="$(date +%Y%m%d-%H%M)"
readonly DUMP_DIR="${SCRIPT_DIR}/${TMP_DIR}/sql"
readonly DUMP_NAME="db-dietrichonline-${DATE}.sql"

# Validates that the dump directory exists.
# <p>
# <ol>
# <li>checks that the dump dir exists
# <li>or will create it (if not exists)
# </ol>
function create_dump_directory() {
  if [ ! -d "${DUMP_DIR}" ]; then
    echo "[INFO] Create directory for dumps <${DUMP_DIR}>."
    if ! mkdir -p "${DUMP_DIR}"; then
      echo "[FAIL] An error occured while creating the directory <${DUMP_DIR}>."
      exit 1
    fi
  fi
}

echo "[INFO] Try to create full dump of database <${DB_NAME}>."
create_dump_directory
echo "[INFO] Need password for user <${DB_USER}>:"

if ! mysqldump -u"${DB_USER}" -p --default-character-set="UTF8" --routines "${DB_NAME}" > "${DUMP_DIR}/${DUMP_NAME}"; then
  echo "[ERR!] An error occured while creating the backup via <mysqldump>."
  exit 1
else
  echo "[ OK ] Create dump <${DUMP_DIR}/${DUMP_NAME}> successfully."
fi
