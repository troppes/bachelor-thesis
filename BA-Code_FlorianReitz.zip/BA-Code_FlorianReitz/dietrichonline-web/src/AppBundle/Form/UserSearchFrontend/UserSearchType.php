<?php
namespace AppBundle\Form\UserSearchFrontend;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use AppBundle\NativeSql\UserSearchItem;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;

class UserSearchType extends AbstractType {
	// Total number of possible search rows = 1 + MAX_ADDITIONAL_SEARCH_ROWS
	const MAX_ADDITIONAL_SEARCH_ROWS = 10;
	
	const KATEGORIEN = [
		'Stichwort des Artikels [Lemma]' => UserSearchItem::TYPE_LEMMA,
		'Titel des Artikels' => UserSearchItem::TYPE_ARTIKEL,
		'Verfasser' => UserSearchItem::TYPE_AUTOR,
		'GND Schlagwort' => UserSearchItem::TYPE_GND,
		'Erschienen in (Zeitschrift/Zeitung/Buch)' => UserSearchItem::TYPE_NORMLITERATURREFERENZ,
		'aus Dietrichband' => UserSearchItem::TYPE_BAND,
		'Dietrich-Sigle' => UserSearchItem::TYPE_SIGLE,
        'Artikel-ID' => UserSearchItem::TYPE_ID,
        'Vollständige Suche' => UserSearchItem::TYPE_FULL_SEARCH,
	];
	
	const JUNKTOREN = [
		'und' => UserSearchItem::JUNKTOR_AND,
		'oder' => UserSearchItem::JUNKTOR_OR,
		'und nicht' => UserSearchItem::JUNKTOR_AND_NOT
	];
		
	public function buildForm(FormBuilderInterface $builder, array $options) {				
		// Add primary search row with no junktor
		$options['csrf_protection'] = false;
		$builder
		->add('k1', ChoiceType::class, array(
				'choices' => self::KATEGORIEN,
				'placeholder' => false,
				'required' => false
		))
		->add('b1', TextType::class, array(
				'required' => false
		));
		
		$builder->add('vonJahr', NumberType::class, array(
		    'required' => false,
		    'invalid_message' => 'Geben Sie bitte eine Jahreszahl ein.'
		))->add('bisJahr', NumberType::class, array(
		    'required' => false,
		    'invalid_message' => 'Geben Sie bitte eine Jahreszahl ein.'
		));
		
		$rowIndex = 1;
		
		// Add every additional search row with junktor
		for ($i = 0; $i < self::MAX_ADDITIONAL_SEARCH_ROWS; ++$i) {
			$builder->add('j'.$rowIndex, ChoiceType::class, array(
				'choices' => self::JUNKTOREN,
				'placeholder' => false,
				'required' => false,
				
				'attr' => array(
					'dynamicElement' => True,
					'type' => 'junktor'
				)				
			))
			->add('k'.($rowIndex+1), ChoiceType::class, array(
				'choices' => self::KATEGORIEN,
				'placeholder' => false,
				'required' => false,
			
				'attr' => array(
					'dynamicElement' => True,
					'type' => 'categorySelect'
				)
			))
			->add('b'.($rowIndex+1), TextType::class, array(
				'required' => false,
				
				'attr' => array(
					'dynamicElement' => True,
					'type' => 'input'
				)
			));
			
			$rowIndex += 1;
		}
						
		// Add submit button
		$builder->add('suchen', SubmitType::class, array(
			'label' => 'suchen'
		));
	}
}