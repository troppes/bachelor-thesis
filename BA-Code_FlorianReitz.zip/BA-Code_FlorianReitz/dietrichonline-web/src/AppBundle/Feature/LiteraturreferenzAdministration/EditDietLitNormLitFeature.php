<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Crawler\ZdbDublinCore;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Entity\LiteraturtypEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use AppBundle\Entity\NormliteraturreferenzEntity;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormView;

class EditDietLitNormLitFeature extends FeatureBase
{
    const UPDATED_DIET_LIT_NORM_LIT_KEY = 'updatedDietLitNormLit';

    /**
     * @see EditDietLitNormLitFeature::getAnyFeatureHasError()
     * @var bool
     */
    private static $anyFeatureHasError = false;

    private $dietrichlitrefNormlitrefEntity;
    private $normliteraturreferenzEntity;
    private $context;

    /**
     * @var FormView
     */
    private $kvkBezeichnungFormView;

    /**
     * @var FormView
     */
    private $administrationFormView;

    /**
     * @var FormView
     */
    private $deleteDietLitNormLitFormView;

    private $editWerkUrlFeatures;
    private $editBandUrlFeatures;
    private $newBandUrlFeature;
    private $newWerkUrlFeature;

    /**
     * @var bool
     */
    private $hasBeenUpdated;

    /**
     * Is set to true if a subfeature has an error
     *
     * @var bool
     */
    private $subFeatureHasError = false;

    public function __construct(FeatureContext $context, DietrichlitrefNormlitrefEntity $dietrichlitrefNormlitrefEntity)
    {
        parent::__construct($context);

        $this->hasBeenUpdated = (int)$context->request->query->get(self::UPDATED_DIET_LIT_NORM_LIT_KEY)
            === $dietrichlitrefNormlitrefEntity->getId();
        $this->context = $context;
        $this->dietrichlitrefNormlitrefEntity = $dietrichlitrefNormlitrefEntity;
        $this->normliteraturreferenzEntity = $dietrichlitrefNormlitrefEntity->getNormliteraturreferenzEntity();

        $this->checkAndUpdateIdn();

        $this->manageKvkBezeichnungForm();
        $this->manageAdministrationForm();
        $this->manageDeleteDietLitNormLitForm();

        $this->editWerkUrlFeatures = EditWerkUrlFeature::constructList(
            $context,
            $this->normliteraturreferenzEntity->getWerkUrlEntities(),
            $this
        );
        $this->editBandUrlFeatures = EditBandUrlFeature::constructList(
            $context,
            $this->dietrichlitrefNormlitrefEntity->getBandUrlEntities(),
            $this
        );
        $this->newBandUrlFeature = new NewBandUrlFeature($context, $dietrichlitrefNormlitrefEntity, $this);
        $this->newWerkUrlFeature = new NewWerkUrlFeature($context, $this->normliteraturreferenzEntity, $this);
    }

    public static function constructList(FeatureContext $context, $dietrichlitrefNormlitrefEntities)
    {
        $editDietLitNormLitFeatures = [];
        foreach ($dietrichlitrefNormlitrefEntities as $dietLitNormLit) {
            $editDietLitNormLitFeatures[] = new EditDietLitNormLitFeature($context, $dietLitNormLit);
        }
        return $editDietLitNormLitFeatures;
    }

    /**
     * @return FormView
     */
    public function getKvkBezeichnungFormView()
    {
        return $this->kvkBezeichnungFormView;
    }

    /**
     * @return FormView
     */
    public function getAdministrationFormView()
    {
        return $this->administrationFormView;
    }

    /**
     * @return array
     */
    public function getEditWerkUrlFeatures()
    {
        return $this->editWerkUrlFeatures;
    }

    /**
     * @return array
     */
    public function getEditBandUrlFeatures()
    {
        return $this->editBandUrlFeatures;
    }

    /**
     * @return NormliteraturreferenzEntity
     */
    public function getNormliteraturreferenzEntity()
    {
        return $this->normliteraturreferenzEntity;
    }

    /**
     * @return DietrichliteraturreferenzEntity
     */
    public function getDietrichliteraturreferenzEntity(): DietrichliteraturreferenzEntity
    {
        return $this->dietrichlitrefNormlitrefEntity->getDietrichliteraturreferenzEntity();
    }

    /**
     * @return FormView
     */
    public function getDeleteDietLitNormLitFormView()
    {
        return $this->deleteDietLitNormLitFormView;
    }

    /**
     * @return NewBandUrlFeature
     */
    public function getNewBandUrlFeature(): NewBandUrlFeature
    {
        return $this->newBandUrlFeature;
    }

    /**
     * @return NewWerkUrlFeature
     */
    public function getNewWerkUrlFeature(): NewWerkUrlFeature
    {
        return $this->newWerkUrlFeature;
    }

    public function manageKvkBezeichnungForm()
    {
        if ($this->normliteraturreferenzEntity->getKvkBezeichnung()) {
            $name = 'kvkBezeichnungForm_' . $this->normliteraturreferenzEntity->getId();
            $form = $this->context->formFactory->createNamedBuilder(
                $name,
                FormType::class,
                $this->normliteraturreferenzEntity
            )
                ->add(NormliteraturreferenzEntity::KVK_BEZEICHNUNG, TextareaType::class)
                ->getForm();

            $form->handleRequest($this->context->request);

            if ($form->isSubmitted() && $form->isValid()) {
                $this->context->backendDoctrineManager->flush();

                $this->setHasBeenUpdatedAndRedirect();
            }

            $this->kvkBezeichnungFormView = $form->createView();
        } else {
            $this->kvkBezeichnungFormView = null;
        }
    }

    public function manageAdministrationForm()
    {
        $dietLitNormLit = $this->dietrichlitrefNormlitrefEntity;
        $normLit = $dietLitNormLit->getNormliteraturreferenzEntity();

        $name = 'dietLitNormLitAdministrationForm_' . $this->dietrichlitrefNormlitrefEntity->getId();
        $data = [
            NormliteraturreferenzEntity::BEMERKUNG => $normLit->getBemerkung(),
            NormliteraturreferenzEntity::LITERATURTYP_ENTITY => $normLit->getLiteraturtypEntity(),
            NormliteraturreferenzEntity::KEINE_WERK_URL_GEFUNDEN => $normLit->getKeineWerkUrlGefunden(),
            DietrichlitrefNormlitrefEntity::NORMKOLLATION => $dietLitNormLit->getNormkollation(),
            DietrichlitrefNormlitrefEntity::KEINE_BAND_URL_GEFUNDEN => $dietLitNormLit->getKeineBandUrlGefunden(),
        ];
        $form = $this->context->formFactory->createNamedBuilder($name, FormType::class, $data)
            ->add(NormliteraturreferenzEntity::BEMERKUNG, TextType::class, ['required' => false])
            ->add(NormliteraturreferenzEntity::LITERATURTYP_ENTITY, EntityType::class, [
                'class' => LiteraturtypEntity::class,
                'choice_label' => LiteraturtypEntity::BEZEICHNUNG,
                'placeholder' => false,
                'em' => $this->context->backendDoctrineManager,
            ])
            ->add(
                NormliteraturreferenzEntity::KEINE_WERK_URL_GEFUNDEN,
                CheckboxType::class,
                ['required' => false]
            )
            ->add(DietrichlitrefNormlitrefEntity::NORMKOLLATION)
            ->add(DietrichlitrefNormlitrefEntity::KEINE_BAND_URL_GEFUNDEN,
                CheckboxType::class,
                ['required' => false]
            )
            ->getForm();

        $form->handleRequest($this->context->request);

        if ($form->isSubmitted() && $form->isValid()) {
            $data = $form->getData();
            $normLit
                ->setBemerkung($data[NormliteraturreferenzEntity::BEMERKUNG])
                ->setLiteraturtypEntity($data[NormliteraturreferenzEntity::LITERATURTYP_ENTITY])
                ->setKeineWerkUrlGefunden($data[NormliteraturreferenzEntity::KEINE_WERK_URL_GEFUNDEN]);
            $dietLitNormLit
                ->setNormkollation($data[DietrichlitrefNormlitrefEntity::NORMKOLLATION])
                ->setKeineBandUrlGefunden($data[DietrichlitrefNormlitrefEntity::KEINE_BAND_URL_GEFUNDEN]);

            $this->context->backendDoctrineManager->flush();

            $this->setHasBeenUpdatedAndRedirect();
        }

        $this->administrationFormView = $form->createView();
    }

    private function manageDeleteDietLitNormLitForm()
    {
        $name = 'delete_diet_lit_norm_lit_form_' . $this->dietrichlitrefNormlitrefEntity->getId();
        $form = $this->context->formFactory->createNamedBuilder($name)->getForm();

        $form->handleRequest($this->getRequest());

        if ($form->isSubmitted() && $form->isValid()) {
            $doctrineManager = $this->getBackendDoctrineManager();
            foreach ($this->dietrichlitrefNormlitrefEntity->getBandUrlEntities() as $bandUrlEntity) {
                $doctrineManager->remove($bandUrlEntity);
            }
            $doctrineManager->remove($this->dietrichlitrefNormlitrefEntity);
            $doctrineManager->flush();
            $this->getRedirectRequest()->shallRedirect = true;
        }

        $this->deleteDietLitNormLitFormView = $form->createView();
    }

    private function checkAndUpdateIdn()
    {
        if ($this->normliteraturreferenzEntity->getZdbIdn() === null) {
            try {
                ZdbDublinCore::updateNormlitref($this->normliteraturreferenzEntity);
                $this->getBackendDoctrineManager()->flush();
            } catch (\Exception $e) {
            }
        }
    }

    public function getHasBeenUpdated()
    {
        return $this->hasBeenUpdated;
    }

    public function setHasBeenUpdatedAndRedirect()
    {
        $redirectRequest = $this->context->redirectRequest;
        $redirectRequest->params[self::UPDATED_DIET_LIT_NORM_LIT_KEY] = $this->dietrichlitrefNormlitrefEntity->getId();
        $redirectRequest->shallRedirect = true;
        $this->hasBeenUpdated = true;
    }

    public function getDietrichLitrefNormLitrefEntity()
    {
        return $this->dietrichlitrefNormlitrefEntity;
    }

    public function setSubFeatureHasError(bool $subFeaturehasError)
    {
        if ($subFeaturehasError)
        {
            self::$anyFeatureHasError = true;
        }
        $this->subFeatureHasError = $subFeaturehasError;
    }

    /**
     * Returns the error state of the feature (includes sub features).
     *
     * @return bool <code>true</code> if the feature or an included sub feature has an error, otherwise <code>false</code>
     */
    public function hasSubFeatureAnError(): bool
    {
        return $this->subFeatureHasError;
    }

    /**
     * If any EditDietLitNormLitFeature instance has an error, every instance must be able to inform its view.
     *
     * @return bool true if any instance of EditDietLitNormLitFeature has an error, false otherwise.
     */
    public function getAnyFeatureHasError(): bool
    {
        return self::$anyFeatureHasError;
    }
}