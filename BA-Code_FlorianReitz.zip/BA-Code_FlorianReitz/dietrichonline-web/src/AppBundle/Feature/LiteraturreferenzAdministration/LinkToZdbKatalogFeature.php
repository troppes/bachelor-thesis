<?php
namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Crawler\ZdbDublinCore;
use Doctrine\Bundle\DoctrineBundle\Registry;

class LinkToZdbKatalogFeature {
	/**
	 * @var Registry
	 */
	protected $doctrineManager;
	
	public function __construct(Registry $doctrine) {
		$this->doctrineManager = $doctrine->getManager('backend');
	}
	
	public function getUrl(NormliteraturreferenzEntity $normlitref) {
		$idn = $normlitref->getZdbIdn();
		if (is_null($idn)) { 
			try {
				ZdbDublinCore::updateNormlitref($normlitref);
			} catch (\Exception $e) {
				return null;
			}
			$idn = $normlitref->getZdbIdn();
			$this->doctrineManager->flush();
		}
		$url = 'http://zdb-katalog.de/title.xhtml?idn='.$idn;
		return $url;
	}
	
	public function produceNormlitrefOriginUrl(NormliteraturreferenzEntity $normlitref) {
	    return ZdbDublinCore::produceNormlitrefOriginUrl($normlitref->getZdbId());
	}
}
