<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Entity\LiteraturtypEntity;
use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\NativeSql\UserSearchItem;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormView;

class AddKvkLitrefFeature extends FeatureBase
{
    private $dietrichLitref;
    private $addKvkLitrefFormView;

    public function __construct(LitrefAdminFeatureContext $context)
    {
        parent::__construct($context);

        $this->dietrichLitref = $context->dietrichLitref;

        $this->manageAddKvkLitrefForm();
    }

    public function getUserSearchNormlitrefCategory()
    {
        return UserSearchItem::TYPE_NORMLITERATURREFERENZ;
    }

    /**
     * @return FormView
     */
    public function getAddKvkLitrefFormView()
    {
        return $this->addKvkLitrefFormView;
    }

    private function manageAddKvkLitrefForm()
    {
        $form = $this->getFormFactory()->createNamedBuilder('addKvkLitrefForm')
            ->add(NormliteraturreferenzEntity::KVK_BEZEICHNUNG, TextareaType::class)
            ->getForm();

        $form->handleRequest($this->getRequest());
        if ($form->isSubmitted() && $form->isValid()) {
            $bezeichnung = $form->getData()[NormliteraturreferenzEntity::KVK_BEZEICHNUNG];

            $normLitref = $this->findOrCreateNormlitref($bezeichnung);

            $dietLitNormLit = $this->findOrCreateDietLitNormLit($normLitref);

            $this->getRedirectRequest()->shallRedirect = true;
            $this->getRedirectRequest()->params[EditDietLitNormLitFeature::UPDATED_DIET_LIT_NORM_LIT_KEY]
                = $dietLitNormLit->getId();
        }

        $this->addKvkLitrefFormView = $form->createView();
    }

    /**
     * @param $bezeichnung
     * @return NormliteraturreferenzEntity
     */
    private function findOrCreateNormlitref($bezeichnung)
    {
        $doctrineManager = $this->getBackendDoctrineManager();
        $normLitrefRepo = $doctrineManager->getRepository(NormliteraturreferenzEntity::class);
        $normLitref = $normLitrefRepo->findOneBy([NormliteraturreferenzEntity::KVK_BEZEICHNUNG => $bezeichnung]);

        if (!$normLitref) {
            $literaturTypRepo = $doctrineManager->getRepository(LiteraturtypEntity::class);
            /** @var LiteraturtypEntity $literaturTypBuch */
            $literaturTypBuch = $literaturTypRepo->findOneBy([LiteraturtypEntity::BEZEICHNUNG => 'Buch']);
            $normLitref = new NormliteraturreferenzEntity();
            $normLitref
                ->setKvkBezeichnung($bezeichnung)
                ->setLiteraturtypEntity($literaturTypBuch)
                ->setKeineWerkUrlGefunden(false);
            $doctrineManager->persist($normLitref);
            $doctrineManager->flush();
        }

        return $normLitref;
    }

    /**
     * @param $normLitref
     * @return DietrichlitrefNormlitrefEntity
     */
    private function findOrCreateDietLitNormLit(NormliteraturreferenzEntity $normLitref)
    {
        $doctrineManager = $this->getBackendDoctrineManager();
        $dietLitNormLitRepo = $doctrineManager->getRepository(DietrichlitrefNormlitrefEntity::class);
        $dietLitNormLit = $dietLitNormLitRepo->findOneBy([
            DietrichlitrefNormlitrefEntity::DIETRICHLITERATURREFERENZ_ENTITY => $this->dietrichLitref,
            DietrichlitrefNormlitrefEntity::NORMLITERATURREFERENZ_ENTITY => $normLitref
        ]);

        if (!$dietLitNormLit) {
            $dietLitNormLit = new DietrichlitrefNormlitrefEntity();
            $dietLitNormLit
                ->setDietrichliteraturreferenzEntity($this->dietrichLitref)
                ->setNormliteraturreferenzEntity($normLitref)
                ->setKeineBandUrlGefunden(false);
            $doctrineManager->persist($dietLitNormLit);
            $doctrineManager->flush();
        }

        return $dietLitNormLit;
    }
}