<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;


use AppBundle\Entity\BandEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\BandRepository;


class ArticleLinkFeature extends FeatureBase
{
    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichLitref;

    /**
     * @var bool
     */
    private $dietrichLitrefHasArticles;

    /**
     * @var int
     */
    private $dietrichLitrefArticleCount;

    /**
     * @var bool
     */
    private $isBandSearchAble;

    public function __construct(LitrefAdminFeatureContext $context)
    {
        parent::__construct($context);

        $this->dietrichLitref = $context->dietrichLitref;
        $this->dietrichLitrefHasArticles = $context->dietrichLitrefHasArticles;
        $this->dietrichLitrefArticleCount = $context->dietrichLitrefArticleCount;


        /** @var BandRepository $bandRepository */
        $bandRepository = $this->getFrontendDoctrineManager()->getRepository(BandEntity::class);

        $this->isBandSearchAble = $this->checkIfBandSearchable($bandRepository->findIdsOfSearchableBaende(), $this->dietrichLitref->getBandEntity()->getId());

    }

    private function checkIfBandSearchable($idsSearchable, $bandId){
        foreach ($idsSearchable as $id){
            if($bandId === $id){
                return true;
            }
        }
        return false;

    }

    /**
     * @return bool
     */
    public function isDietrichLitrefHasArticles(): bool
    {
        return $this->dietrichLitrefHasArticles;
    }

    /**
     * @return int
     */
    public function getDietrichLitrefArticleCount(): int
    {
        return $this->dietrichLitrefArticleCount;
    }

    /**
     * @return bool
     */
    public function isBandSearchAble(): bool
    {
        return $this->isBandSearchAble;
    }

    /**
     * @return DietrichliteraturreferenzEntity
     */
    public function getDietrichLitref(): DietrichliteraturreferenzEntity
    {
        return $this->dietrichLitref;
    }


}