<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Entity\BandUrlEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Util\UrlUtil;
use InvalidArgumentException;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormView;
use Symfony\Component\Form\SubmitButton;

class EditBandUrlFeature extends FeatureBase
{
    private $context;
    private $bandUrlEntity;
    private $bandUrlEditFormView;
    private $dietLitNormLitFeature;

    public function __construct(FeatureContext $context, BandUrlEntity $bandUrlEntity,
                                EditDietLitNormLitFeature $dietLitNormLitFeature)
    {
        parent::__construct($context);

        $this->context = $context;
        $this->bandUrlEntity = $bandUrlEntity;
        $this->dietLitNormLitFeature = $dietLitNormLitFeature;

        $this->manageBandUrlEditForm();
    }

    /**
     * @return FormView
     */
    public function getBandUrlEditFormView(): FormView
    {
        return $this->bandUrlEditFormView;
    }

    public static function constructList(FeatureContext $context, $bandUrlEntities,
                                         EditDietLitNormLitFeature $dietLitNormLitFeature): array
    {
        $editBandUrlFeatures = [];
        foreach ($bandUrlEntities as $bandUrlEntity) {
            $editBandUrlFeatures[] = new EditBandUrlFeature($context, $bandUrlEntity, $dietLitNormLitFeature);
        }
        return $editBandUrlFeatures;
    }

    private function manageBandUrlEditForm()
    {
        $name = 'bandUrlEditForm_' . $this->bandUrlEntity->getId();
        $form = $this->context->formFactory->createNamedBuilder($name, FormType::class, $this->bandUrlEntity)
            ->add(BandUrlEntity::NORMKOLLATION, TextType::class)
            ->add(BandUrlEntity::URL, TextType::class)
            ->add(BandUrlEntity::BEMERKUNG, TextType::class, ['required' => false])
            ->add('delete', SubmitType::class)
            ->getForm();

        $form->handleRequest($this->context->request);

        if ($form->isSubmitted()) {
            /** @var SubmitButton $deleteButton */
            $deleteButton = $form->get('delete');
            if ($deleteButton->isClicked()) {
                $this->context->backendDoctrineManager->remove($this->bandUrlEntity);
            }
            if ($form->isValid() || $deleteButton->isClicked()) {
                $this->context->backendDoctrineManager->flush();
                $this->dietLitNormLitFeature->setHasBeenUpdatedAndRedirect();
            } else try {
                $repairedUrl = UrlUtil::getSpecialEncodedUrl($this->bandUrlEntity->getUrl());
                $form->get(BandUrlEntity::URL)
                    ->addError(new FormError(UrlUtil::LITERAL_ERROR_MSG))
                    ->addError(new FormError($repairedUrl));

                $this->dietLitNormLitFeature->setSubFeatureHasError(true);
            } catch (InvalidArgumentException $e) {
                // shown as general "not an URL" error
            }
        }

        $this->bandUrlEditFormView = $form->createView();
    }
}