<?php
namespace AppBundle\Feature\LiteraturreferenzAdministration\GoToSigle;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints as Assert;

class GoToSigleModel {
	protected $bandkuerzel;

    const REQUESTED_SIGLE = 'requestedSigle';
	protected $requestedSigle;

	protected $dietrichLitrefRepo;

	public function __construct($bandkuerzel, $dietrichLitrefRepo) {
		$this->bandkuerzel = $bandkuerzel;
		$this->dietrichLitrefRepo = $dietrichLitrefRepo;
	}

	public function getRequestedSigle() {
		return $this->requestedSigle;
	}

	public function getUrlEscapedRequestedSigle() {
	    return rawurlencode($this->requestedSigle);
    }

	public function setRequestedSigle($requestedSigle) {
		$this->requestedSigle = $requestedSigle;
		return $this;
	}

    const REQUESTED_SIGLE_EXISTS = 'requestedSigleExists';
	public function getRequestedSigleExists() {
		$requestedSigleExists = $this->dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(
			$this->bandkuerzel, $this->requestedSigle
		) !== NULL;
		if (!$requestedSigleExists) {
			$requestedSigleHasPoint = $this->requestedSigle[strlen($this->requestedSigle)-1] === '.';
			if ($requestedSigleHasPoint) {
				// strip off point
				$this->requestedSigle = substr($this->requestedSigle, 0, strlen($this->requestedSigle)-1);
			} else {
				// add point
				$this->requestedSigle = $this->requestedSigle.'.';
			}
			// try again
			$requestedSigleExists = $this->dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(
				$this->bandkuerzel, $this->requestedSigle
			) !== NULL;
		}
		return $requestedSigleExists;
	}

	public static function loadValidatorMetadata(ClassMetadata $metadata) {
        $metadata->addGetterConstraint(self::REQUESTED_SIGLE_EXISTS, new Assert\IsTrue(array(
			'message' => 'Sigle wurde nicht gefunden.'
		)));
	}
}
