<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration\GoToSigle;


use AppBundle\Controller\Literaturreferenzadministration\LiteraturreferenzAdministrationController;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Repository\DietrichliteraturreferenzRepository;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;

class GoToSigleFeature extends FeatureBase
{
    /**
     * @var FormInterface
     */
    private $form;

    /**
     * @var FormView
     */
    private $formView;

    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $bandEntity;

    public function __construct(FeatureContext $context, BandEntity $bandEntity)
    {
        parent::__construct($context);
        $this->bandEntity = $bandEntity;
        $this->buildForm();
        $this->handleRequest();
        $this->formView = $this->form->createView();
    }

    public function getFormView(): FormView
    {
        return $this->formView;
    }

    public function getBandkuerzel(): string
    {
        return $this->bandEntity->getBandkuerzel();
    }

    private function handleRequest()
    {
        $this->form->handleRequest($this->getRequest());
        if ($this->form->isSubmitted() && $this->form->isValid()) {
            /** @var GoToSigleModel $model */
            $model = $this->form->getData();
            $this->getRedirectRequest()
                ->setShallRedirect(true)
                ->setRoute(LiteraturreferenzAdministrationController::LITERATURREFERENZADMINISTRATION_ROUTE)
                ->addParam(LiteraturreferenzAdministrationController::BANDKUERZEL, $this->bandEntity->getBandkuerzel())
                ->addParam(LiteraturreferenzAdministrationController::SIGLE, $model->getUrlEscapedRequestedSigle());
        }
    }

    private function buildForm()
    {
        /** @var $dietrichLitrefRepo DietrichliteraturreferenzRepository */
        $dietrichLitrefRepo = $this->getDoctrineRegistry()
            ->getRepository(DietrichliteraturreferenzEntity::class);
        $model = new GoToSigleModel($this->bandEntity->getBandkuerzel(), $dietrichLitrefRepo);
        $this->form = $this->getFormFactory()->createNamedBuilder('goToSigleForm', FormType::class, $model)
            ->add(GoToSigleModel::REQUESTED_SIGLE, TextType::class)
            ->getForm();
    }
}