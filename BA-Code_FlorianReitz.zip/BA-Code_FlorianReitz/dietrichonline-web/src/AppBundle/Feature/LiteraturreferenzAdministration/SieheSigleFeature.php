<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormView;

class SieheSigleFeature
{
    const SIGLE_DOES_NOT_EXIST_ERROR = 'Die Sigle %s existiert nicht in Band %s.';
    const WOULD_CREATE_CIRCLE_ERROR = 'Kann %s nicht mit %s verknüpfen, weil dadurch eine Kreisreferenzierung entstünde.';
    const NORMLITREFS_EXIST_ERROR =
        'Kann %1$s nicht mit %2$s verknüpfen, weil %1$s mit Normliteraturreferenzen verknüpft ist.';

    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichLitref;

    /**
     * @var FeatureContext
     */
    private $context;

    /**
     * @var FormView
     */
    private $form;

    /**
     * @var FormView
     */
    private $deleteForm;

    /**
     * @var array
     */
    private $errors;

    private $doctrineManager;

    /**
     * SieheSigleFeature constructor.
     * @param LitrefAdminFeatureContext $featureContext
     */
    public function __construct(LitrefAdminFeatureContext $featureContext)
    {
        $this->errors = [];
        $this->doctrineManager = $featureContext->doctrine->getManager(FeatureBase::DB_BACKEND);
        $this->dietrichLitref = $featureContext->dietrichLitref;
        $this->context = $featureContext;
        $this->handleForm();
        $this->handleDeleteForm();
    }

    private function handleForm()
    {
        $form = $this->context->formFactory->createNamedBuilder("sieheSigleForm")
            ->add("sieheSigle", TextType::class)
            ->getForm();

        $form->handleRequest($this->context->request);
        if ($form->isSubmitted()) {
            $sigle = $form->getData()['sieheSigle'];

            /* @var $referencedDietrichlitref DietrichliteraturreferenzEntity */
            $referencedDietrichlitref = $this->doctrineManager->getRepository(DietrichliteraturreferenzEntity::class)->findOneBy([
                'bandEntity' => $this->dietrichLitref->getBandEntity(),
                'sigle' => $sigle,
            ]);
            $this->validate($sigle, $referencedDietrichlitref);
            if ($this->isValid()) {
                $this->dietrichLitref->setDietrichliteraturreferenzEntity($referencedDietrichlitref);
                $this->doctrineManager->flush();
            }
        }

        $this->form = $form->createView();
    }

    private function validate($sigle, $referencedDietrichlitref)
    {
        $this->validateSigleExists($sigle, $referencedDietrichlitref);
        if ($this->hasErrors()) { return; }

        $this->validateCircleFree($referencedDietrichlitref);

        $this->validateNoNormlitrefs($sigle);
    }

    private function validateSigleExists($sigle, $referencedDietrichlitref) {
        if ($referencedDietrichlitref === null) {
            $this->errors[] = sprintf(
                self::SIGLE_DOES_NOT_EXIST_ERROR,
                $sigle,
                $this->dietrichLitref->getBandEntity()->getBandkuerzel()
            );
        }
    }

    private function validateCircleFree(DietrichliteraturreferenzEntity $referencedDietrichlitref)
    {
        $currentDietrichlitref = $referencedDietrichlitref;
        while ($currentDietrichlitref !== null) {
            if ($this->dietrichLitref->getId() === $currentDietrichlitref->getId()) {
                $this->addCircleError($referencedDietrichlitref);
                return;
            }
            $currentDietrichlitref = $currentDietrichlitref->getDietrichliteraturreferenzEntity();
        }
    }

    private function addCircleError(DietrichliteraturreferenzEntity $referencedDietrichlitref)
    {
        if ($this->dietrichLitref->getId() == $referencedDietrichlitref->getId()) {
            $this->errors[] = "Eine Dietrichliteraturreferenz kann nicht mit sich selbst verknüpft werden. Haben Sie sich vertippt?";
        } else {
            $this->errors[] = "Die Dietrichliteraturreferenz " . $this->dietrichLitref->getSigle()
                . " kann nicht mit " . $referencedDietrichlitref->getSigle() . " verknüpft werden. Durch die Verknüpfung 
                würde eine Kreisreferenzierung entstehen.";
            $currentDietrichlitref = $referencedDietrichlitref;
            $msg = "Folgende Verknüpfungen bestehen: ";
            while (true) {
                $msg .= "[".$currentDietrichlitref->getSigle()."]";
                if ($currentDietrichlitref->getId() == $this->dietrichLitref->getId()) {
                    break;
                }
                $msg .= "->";
                $currentDietrichlitref = $currentDietrichlitref->getDietrichliteraturreferenzEntity();
            }
            $msg .= " Wenn ". $this->dietrichLitref->getSigle() . " mit " . $referencedDietrichlitref->getSigle()
                . " verknüpft wird, entsteht also eine Kreisreferenzierung.";
            $this->errors[] = $msg;
        }
    }

    private function validateNoNormlitrefs($sigle)
    {
        if (count($this->dietrichLitref->getDietrichlitrefNormlitrefEntities()) > 0) {
            $this->errors[] = sprintf(
                self::NORMLITREFS_EXIST_ERROR,
                $this->dietrichLitref->getSigle(),
                $sigle
            );
        }
    }

    public function getForm()
    {
        return $this->form;
    }

    public function getDeleteForm() {
        return $this->deleteForm;
    }

    public function getErrors()
    {
        return $this->errors;
    }

    public function hasErrors()
    {
        return count($this->errors) > 0;
    }

    public function isValid() {
        return !$this->hasErrors();
    }

    private function handleDeleteForm()
    {
        $form = $this->context->formFactory->createNamedBuilder('deleteSieheSigle')->getForm();

        $form->handleRequest($this->context->request);
        if ($form->isSubmitted()) {
            $this->dietrichLitref->setDietrichliteraturreferenzEntity(null);
            $this->doctrineManager->flush();
        }

        $this->deleteForm = $form->createView();
    }

    public function dietrichLitrefHasNormlitrefs()
    {
        return count($this->dietrichLitref->getDietrichlitrefNormlitrefEntities()) > 0;
    }

    public function dietrichLitrefHasLinkedDietrichLitref()
    {
        return $this->dietrichLitref->getDietrichliteraturreferenzEntity() !== null;
    }

    public function getLinkedDietrichLitref()
    {
        return $this->dietrichLitref->getDietrichliteraturreferenzEntity();
    }
}