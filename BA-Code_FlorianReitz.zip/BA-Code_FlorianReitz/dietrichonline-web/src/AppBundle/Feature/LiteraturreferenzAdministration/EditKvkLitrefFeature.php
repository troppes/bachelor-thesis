<?php
namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use AppBundle\Entity\NormliteraturreferenzEntity;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\FormView;

class EditKvkLitrefFeature {
    /**
     * @var FormView with KVK-Literaturreferenz edit fields.
     */
    public $form;
    
    /**
     * @param NormliteraturreferenzEntity $normlitref as KVK-Literaturreferenz which can be edited
     * @param FeatureContext $context @see FeatureContext
     */
    public function __construct(NormliteraturreferenzEntity $normlitref, FeatureContext $context) {
        $form = $context->formFactory->createNamedBuilder('editKvkForm_'.$normlitref->getId(), FormType::class, $normlitref)
        ->add('kvkBezeichnung', TextareaType::class)
        ->getForm();
        
        $form->handleRequest($context->request);
        if ($form->isSubmitted() && $form->isValid()) {
            $context->doctrine->getManager(FeatureBase::DB_BACKEND)->flush();
            $context->redirectRequest->shallRedirect = true;
        }
        
        $this->form = $form->createView();
    }
}