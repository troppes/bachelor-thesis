<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;


use AppBundle\Entity\BandUrlEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Util\UrlUtil;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormView;

class NewBandUrlFeature extends FeatureBase
{
    private $dietrichlitrefNormlitrefEntity;
    private $formView;
    private $editDietLitNormLitFeature;

    /**
     * NewBandUrlFeature constructor.
     * @param FeatureContext $context
     * @param DietrichlitrefNormlitrefEntity $dietrichlitrefNormlitrefEntity
     * @param EditDietLitNormLitFeature $editDietLitNormLitFeature
     */
    public function __construct(FeatureContext $context, DietrichlitrefNormlitrefEntity $dietrichlitrefNormlitrefEntity,
                                EditDietLitNormLitFeature $editDietLitNormLitFeature)
    {
        parent::__construct($context);

        $this->dietrichlitrefNormlitrefEntity = $dietrichlitrefNormlitrefEntity;
        $this->editDietLitNormLitFeature = $editDietLitNormLitFeature;

        $this->manageForm();
    }

    /**
     * @return FormView
     */
    public function getFormView()
    {
        return $this->formView;
    }

    /**
     * If something is changed in this function, please check NewWerkUrlFeature::manageForm() too. Code Duplications are
     * here, but resolving them would lead to over complicated structures. If you've got a decent amount of spare time
     * maybe you can implement a better solution.
     */
    private function manageForm()
    {
        $newBandUrlEntity = new BandUrlEntity();
        $form = $this->getFormFactory()->createNamedBuilder(
            'newBandUrlForm_' . $this->editDietLitNormLitFeature->getDietrichLitrefNormLitrefEntity()->getId(),
            FormType::class,
            $newBandUrlEntity
        )
            ->add(BandUrlEntity::NORMKOLLATION, TextType::class)
            ->add(BandUrlEntity::URL, UrlType::class)
            ->add(BandUrlEntity::BEMERKUNG, TextType::class, ['required' => false])
            ->getForm();

        $form->handleRequest($this->getRequest());

        if ($form->isSubmitted()) {
            if ($form->isValid()) {
                $newBandUrlEntity->setDietrichlitrefNormlitrefEntity($this->dietrichlitrefNormlitrefEntity);
                $this->getBackendDoctrineManager()->persist($newBandUrlEntity);
                $this->getBackendDoctrineManager()->flush();
                $this->editDietLitNormLitFeature->setHasBeenUpdatedAndRedirect();
            } else {
                try
                {
                    $repairedUrl = UrlUtil::getSpecialEncodedUrl($newBandUrlEntity->getUrl());
                    $form->get(BandUrlEntity::URL)
                        ->addError(new FormError(UrlUtil::LITERAL_ERROR_MSG))
                        ->addError(new FormError($repairedUrl));
                }
                catch (\InvalidArgumentException $e)
                {
                    // shown as general 'not an URL' error
                }

                $this->editDietLitNormLitFeature->setSubFeatureHasError(true);
            }
        }

        $this->formView = $form->createView();
    }
}