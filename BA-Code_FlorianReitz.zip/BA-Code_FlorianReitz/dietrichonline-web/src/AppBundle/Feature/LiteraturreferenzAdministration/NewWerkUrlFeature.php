<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;


use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Entity\WerkUrlEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Util\UrlUtil;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormView;
use Symfony\Component\Validator\Constraints\Url;

class NewWerkUrlFeature extends FeatureBase
{
    private $normliteraturreferenzEntity;
    private $newWerkUrlFormView;
    private $editDietLitNormLitFeature;

    /**
     * NewWerkUrlFeature constructor.
     * @param FeatureContext $context
     * @param NormliteraturreferenzEntity $normliteraturreferenzEntity
     * @param EditDietLitNormLitFeature $editDietLitNormLitFeature
     */
    public function __construct(FeatureContext $context, NormliteraturreferenzEntity $normliteraturreferenzEntity,
                                EditDietLitNormLitFeature $editDietLitNormLitFeature)
    {
        parent::__construct($context);

        $this->normliteraturreferenzEntity = $normliteraturreferenzEntity;
        $this->editDietLitNormLitFeature = $editDietLitNormLitFeature;

        $this->manageNewWerkUrlForm();
    }

    /**
     * @return FormView
     */
    public function getNewWerkUrlFormView()
    {
        return $this->newWerkUrlFormView;
    }

    /**
     * If something is changed in this function, please check NewBandUrlFeature::manageForm() too. Code Duplications are
     * here, but resolving them would lead to over complicated structures. If you've got a decent amount of spare time
     * maybe you can implement a better solution.
     */
    private function manageNewWerkUrlForm()
    {
        $newWerkUrlEntity = new WerkUrlEntity();
        $form = $this->getFormFactory()->createNamedBuilder(
            'newWerkUrlForm_' . $this->editDietLitNormLitFeature->getDietrichLitrefNormLitrefEntity()->getId(),
            FormType::class,
            $newWerkUrlEntity
        )
            ->add(WerkUrlEntity::URL, UrlType::class)
            ->add(WerkUrlEntity::BEMERKUNG, TextType::class, ['required' => false])
            ->getForm();

        $form->handleRequest($this->getRequest());

        if ($form->isSubmitted())
        {
            if ($form->isValid())
            {
                $newWerkUrlEntity->setNormliteraturreferenzEntity($this->normliteraturreferenzEntity);
                $this->getBackendDoctrineManager()->persist($newWerkUrlEntity);
                $this->getBackendDoctrineManager()->flush();
                $this->editDietLitNormLitFeature->setHasBeenUpdatedAndRedirect();
            }
            else
            {
                    try
                    {
                        $repairedUrl = UrlUtil::getSpecialEncodedUrl($newWerkUrlEntity->getUrl());
                        $form->get(WerkUrlEntity::URL)
                            ->addError(new FormError(UrlUtil::LITERAL_ERROR_MSG))
                            ->addError(new FormError($repairedUrl));
                    }
                    catch (\InvalidArgumentException $e)
                    {
                        // shown as general "not an URL" error
                    }

                    $this->editDietLitNormLitFeature->setSubFeatureHasError(true);
            }
        }

        $this->newWerkUrlFormView = $form->createView();
    }
}