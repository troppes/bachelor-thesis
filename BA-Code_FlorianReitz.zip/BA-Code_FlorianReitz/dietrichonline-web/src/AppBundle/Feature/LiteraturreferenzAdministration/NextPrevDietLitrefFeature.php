<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;


use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\DietrichliteraturreferenzRepository;

class NextPrevDietLitrefFeature extends FeatureBase
{
    /**
     * @var DietrichliteraturreferenzRepository
     */
    private $dietLitrefRepo;

    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichLitref;


    /**
     * @string
     */
    private $filter;

    /**
     * NextPrevDietLitrefFeature constructor.
     * @param LitrefAdminFeatureContext $featureContext
     */
    public function __construct(LitrefAdminFeatureContext $featureContext)
    {
        parent::__construct($featureContext);

        $this->dietLitrefRepo = $this->getBackendDoctrineManager()
            ->getRepository(DietrichliteraturreferenzEntity::class);

        $this->dietrichLitref = $featureContext->dietrichLitref;


        $this->filter = $featureContext->request->query->get('filter', 'all_paged');
    }

    public function getNextDietrichLiteraturreferenz()
    {
        return $this->dietLitrefRepo->findNextDietrichliteraturreferenzOf($this->dietrichLitref, $this->filter);
    }

    public function getPreviousDietrichLiteraturreferenz()
    {
        return $this->dietLitrefRepo->findPreviousDietrichliteraturreferenzOf($this->dietrichLitref, $this->filter);
    }

    /**
     * @return mixed
     */
    public function getFilter()
    {
        return $this->filter;
    }
}