<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Controller\Literaturreferenzadministration\LiteraturreferenzAdministrationController;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\LiteraturreferenzbearbeitungsstatusEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;

class EditDietrichLitrefFeature extends FeatureBase
{
    /**
     * @var FormInterface
     */
    private $form;

    /**
     * @var FormView
     */
    private $formView;

    /**
     * @var FormInterface
     */
    private $bezeichnungForm;

    /**
     * @var FormView
     */
    private $bezeichnungFormView;

    /**
     * @var FormInterface
     */
    private $sigleForm;

    /**
     * @var FormView
     */
    private $sigleFormView;

    /**
     * @var LitrefAdminFeatureContext
     */
    private $context;

    public function __construct(LitrefAdminFeatureContext $context)
    {
        parent::__construct($context);
        $this->context = $context;
        $this->form = $this->buildForm();
        $this->bezeichnungForm = $this->buildBezeichnungForm();
        $this->sigleForm = $this->buildSigleForm();
        $this->handleRequest();
        $this->formView = $this->form->createView();
        $this->bezeichnungFormView = $this->bezeichnungForm->createView();
        $this->sigleFormView = $this->sigleForm->createView();
    }

    public function getFormView()
    {
        return $this->formView;
    }

    public function getBezeichnungFormView()
    {
        return $this->bezeichnungFormView;
    }

    public function getSigleFormView()
    {
        return $this->sigleFormView;
    }

    public function getDietrichLitrefHasArticles()
    {
        return $this->context->dietrichLitrefHasArticles;
    }

    public function getDietrichLiteraturreferenz()
    {
        return $this->context->dietrichLitref;
    }

    private function buildForm()
    {
        return $this->getFormFactory()->createNamedBuilder(
            'editDietrichLitrefForm',
            FormType::class,
            $this->context->dietrichLitref
        )
            ->add(
                DietrichliteraturreferenzEntity::LITERATURREFERENZBEARBEITUNGSSTATUS_ENTITY,
                EntityType::class,
                [
                    'class' => LiteraturreferenzbearbeitungsstatusEntity::class,
                    'choice_label' => 'bezeichnung',
                    'placeholder' => false,
                    'required' => false,
                    'em' => $this->getBackendDoctrineManager()
                ]
            )
            ->add(DietrichliteraturreferenzEntity::ALLGEMEINEBEMERKUNG, TextType::class, [
                'required' => false
            ])
            ->add(DietrichliteraturreferenzEntity::DIETRICHKOLLATION, TextType::class, [
                'required' => false
            ])
            ->getForm();
    }

    private function handleRequest()
    {
        $this->form->handleRequest($this->getRequest());
        $this->bezeichnungForm->handleRequest($this->getRequest());
        $this->sigleForm->handleRequest($this->getRequest());
        if (
            ($this->form->isSubmitted() && $this->form->isValid())
            || ($this->bezeichnungForm->isSubmitted() && $this->bezeichnungForm->isValid())
        ) {
            $this->getBackendDoctrineManager()->flush();
        }

        if ($this->sigleForm->isSubmitted() && $this->sigleForm->isValid()) {
            $this->getBackendDoctrineManager()->flush();
            $this->getRedirectRequest()->shallRedirect = true;
            $this->getRedirectRequest()->route
                = LiteraturreferenzAdministrationController::LITERATURREFERENZADMINISTRATION_ROUTE;
            $this->getRedirectRequest()->params = [
                'bandkuerzel' => $this->getDietrichLiteraturreferenz()->getBandEntity()->getBandkuerzel(),
                'sigle' => $this->getDietrichLiteraturreferenz()->getUrlEscapedSigle()
            ];
        }
    }

    private function buildBezeichnungForm()
    {
        return $this->getFormFactory()->createNamedBuilder(
            'editDietrichlitrefBezeichnungForm',
            FormType::class,
            $this->context->dietrichLitref
        )
            ->add(DietrichliteraturreferenzEntity::DIETRICHBEZEICHNUNG, TextareaType::class)
            ->getForm();
    }

    private function buildSigleForm()
    {
        return $this->getFormFactory()->createNamedBuilder(
            'editSigleForm',
            FormType::class,
            $this->context->dietrichLitref
        )
            ->add(DietrichliteraturreferenzEntity::SIGLE, TextType::class)
            ->getForm();
    }
}