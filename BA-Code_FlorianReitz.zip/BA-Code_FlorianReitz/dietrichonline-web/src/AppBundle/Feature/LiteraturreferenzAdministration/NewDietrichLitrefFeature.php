<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;


use AppBundle\Controller\Literaturreferenzadministration\LiteraturreferenzAdministrationController;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\LiteraturreferenzbearbeitungsstatusEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormView;

class NewDietrichLitrefFeature extends FeatureBase
{
    private $newDietrichLitrefFormView;
    private $band;

    public function __construct(FeatureContext $context, BandEntity $band)
    {
        parent::__construct($context);

        $this->band = $band;
        $this->manageNewDietrichLitrefForm();
    }

    /**
     * @return FormView
     */
    public function getNewDietrichLitrefFormView()
    {
        return $this->newDietrichLitrefFormView;
    }

    private function manageNewDietrichLitrefForm()
    {
        $dietLit = new DietrichliteraturreferenzEntity();
        $form = $this->getFormFactory()->createNamedBuilder('newDietrichLitrefForm', FormType::class, $dietLit)
            // sigle, dietrichbezeichnung are checked via symfony entity validation so that they cannot be empty
            ->add('sigle', TextType::class, ['required' => false])
            ->add('dietrichbezeichnung', TextareaType::class, ['required' => false])
            ->add('literaturreferenzbearbeitungsstatusEntity', EntityType::class, [
                'class' => LiteraturreferenzbearbeitungsstatusEntity::class,
                'choice_label' => 'bezeichnung',
                'placeholder' => false,
                'em' => $this->getBackendDoctrineManager()
            ])
            ->add('allgemeinebemerkung', TextType::class, ['required' => false])
            ->add('dietrichkollation', TextType::class, ['required' => false])
            ->getForm();

        $form->handleRequest($this->getRequest());

        if ($form->isSubmitted() && $form->isValid()) {
            if ($this->sigleIsNew($dietLit->getSigle())) {
                $dietLit->setBandEntity($this->band);

                $this->getBackendDoctrineManager()->persist($dietLit);
                $this->getBackendDoctrineManager()->flush();

                $this->getRedirectRequest()->route
                    = LiteraturreferenzAdministrationController::LITERATURREFERENZADMINISTRATION_ROUTE;
                $this->getRedirectRequest()->params['sigle'] = $dietLit->getUrlEscapedSigle();
                $this->getRedirectRequest()->params['bandkuerzel'] = $this->band->getBandkuerzel();
                $this->getRedirectRequest()->shallRedirect = true;
            } else {
                $msg = sprintf(
                    'Die Sigle %s existiert bereits in Band %s.',
                    $dietLit->getSigle(),
                    $this->band->getBandkuerzel()
                );
                $form->addError(new FormError($msg));
            }
        }

        $this->newDietrichLitrefFormView = $form->createView();
    }

    private function sigleIsNew($sigle)
    {
        $normLitRepo = $this->getBackendDoctrineManager()->getRepository(DietrichliteraturreferenzEntity::class);
        $witness = $normLitRepo->findOneBy([
            DietrichliteraturreferenzEntity::SIGLE => $sigle,
            DietrichliteraturreferenzEntity::BAND_ENTITY => $this->band
        ]);

        return $witness === null;
    }
}