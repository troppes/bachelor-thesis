<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\DietrichliteraturreferenzRepository;

class BackToListFeature extends FeatureBase
{
    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichLitref;

    /**
     * @var string
     */
    private $filter;

    /**
     * @var string
     */
    private $filterText;

    /**
     * @var int
     */
    private $pageNumber;

    public function __construct(LitrefAdminFeatureContext $context)
    {
        parent::__construct($context);

        $this->dietrichLitref = $context->dietrichLitref;

        $this->filter = $context->request->get('filter', 'all_paged');
        $this->pageNumber = $context->request->get('pageNumber', 1);

        /** @var DietrichliteraturreferenzRepository $dietrichLitRefRepository */
        $dietrichLitRefRepository = $this->getFrontendDoctrineManager()->getRepository(DietrichliteraturreferenzEntity::class);

        $this->pageNumber = $dietrichLitRefRepository->getPageNumberByEntry($this->dietrichLitref, $this->filter);

        switch ($this->filter) {
            case DietrichliteraturreferenzRepository::STATUS_FILTER_UNCLEAR:
                $this->filterText = "unklar - Seite $this->pageNumber";
                break;

            case DietrichliteraturreferenzRepository::STATUS_FILTER_NEW:
                $this->filterText = "neu - Seite $this->pageNumber";
                break;

            case DietrichliteraturreferenzRepository::STATUS_FILTER_ALL_PAGED:
                $this->filterText = "alle - Seite $this->pageNumber";
                break;

            case DietrichliteraturreferenzRepository::STATUS_FILTER_ALL:
            default:
                $this->filterText = 'alle auf einer Seite';
        }
    }

    /**
     * @return DietrichliteraturreferenzEntity
     */
    public function getDietrichLitref(): DietrichliteraturreferenzEntity
    {
        return $this->dietrichLitref;
    }

    /**
     * @return string
     */
    public function getFilter(): string
    {
        return $this->filter;
    }

    /**
     * @return int
     */
    public function getPageNumber(): int
    {
        return $this->pageNumber;
    }

    /**
     * @return string
     */
    public function getFilterText(): string
    {
        return $this->filterText;
    }


}