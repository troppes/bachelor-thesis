<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Controller\RedirectRequest;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Feature\FeatureContext;
use AppBundle\Repository\DietrichliteraturreferenzRepository;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Psr\Log\LoggerInterface;

class LitrefAdminFeatureContext
    extends FeatureContext
{
    /**
     * @var DietrichliteraturreferenzEntity
     */
    public $dietrichLitref;

    /**
     * @var bool
     */
    public $dietrichLitrefHasArticles;

    /**
     * @var int
     */
    public $dietrichLitrefArticleCount;

    public function __construct(
        Request $request,
        Registry $doctrine,
        FormFactory $formFactory,
        LoggerInterface $logger,
        RedirectRequest $redirectRequest,
        $bandkuerzel,
        $sigle
    )
    {
        parent::__construct($request, $doctrine, $formFactory, $redirectRequest, $logger);

        /* @var $dietrichLitrefRepo DietrichliteraturreferenzRepository */
        $dietrichLitrefRepo = $this->backendDoctrineManager
            ->getRepository(DietrichliteraturreferenzEntity::class);
        $dietrichLitref     = $dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(
            $bandkuerzel,
            $sigle
        );
        if ($dietrichLitref === null) {
            $siglePoint          = $sigle.'.';
            $dietrichLitrefPoint = $dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(
                $bandkuerzel,
                $siglePoint
            );

            if ($dietrichLitrefPoint !== null) {
                throw new HttpException(
                    419,
                    'Sigle '.$sigle.' was not found in Band '.$bandkuerzel.'.',
                    null,
                    ['bandkuerzel' => $bandkuerzel,  'sigle' => $sigle, 'siglePoint' => $siglePoint]
                );
            } else {
                throw new HttpException(
                    419,
                    'Sigle '.$sigle.' was not found in Band '.$bandkuerzel.'. No Sigle with added . found.',
                    null,
                    ['bandkuerzel' => $bandkuerzel, 'sigle' => $sigle]
                );
            }
        }
        $this->dietrichLitref             = $dietrichLitref;
        $this->dietrichLitrefHasArticles  = $dietrichLitrefRepo->hasArticles($this->dietrichLitref);
        $this->dietrichLitrefArticleCount = $dietrichLitrefRepo->getArticleCount($this->dietrichLitref);
    }
}
