<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LiteraturreferenzAdministration;


use AppBundle\Controller\Literaturreferenzadministration\LiteraturreferenzAdministrationController;
use AppBundle\Controller\Literaturreferenzadministration\LiteraturreferenzListeController;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\DietrichliteraturreferenzRepository;
use Symfony\Component\Form\FormView;

class DeleteDietrichLitrefFeature extends FeatureBase
{
    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichLitref;

    /**
     * @var FormView
     */
    private $deleteDietrichLitrefFormView;

    /**
     * @var bool
     */
    private $dietrichLitrefHasArticles;

    public function __construct(LitrefAdminFeatureContext $context)
    {
        parent::__construct($context);

        $this->dietrichLitref = $context->dietrichLitref;
        $this->dietrichLitrefHasArticles = $context->dietrichLitrefHasArticles;
        $this->manageDeleteDietrichLitrefForm();
    }

    /**
     * @return FormView
     */
    public function getDeleteDietrichLitrefFormView()
    {
        return $this->deleteDietrichLitrefFormView;
    }

    public function getSigle()
    {
        return $this->dietrichLitref->getSigle();
    }

    public function getDietrichLitrefHasArticles()
    {
        return $this->dietrichLitrefHasArticles;
    }

    private function manageDeleteDietrichLitrefForm()
    {
        $form = $this->getFormFactory()->createNamedBuilder('deleteDietrichLitrefForm')->getForm();

        $form->handleRequest($this->getRequest());

        if ($form->isSubmitted() && $form->isValid()) {
            $this->deleteDietrichLitref();
            $this->setRedirectRoute();
        }

        $this->deleteDietrichLitrefFormView = $form->createView();
    }

    private function deleteDietrichLitref()
    {
        $doctrineManager = $this->getBackendDoctrineManager();

        $linkedDietrichlitrefs = $doctrineManager->getRepository(DietrichliteraturreferenzEntity::class)
            ->findBy([DietrichliteraturreferenzEntity::DIETRICHLITERATURREFERENZ_ENTITY => $this->dietrichLitref]);
        foreach ($linkedDietrichlitrefs as $linkedDietrichlitref) {
            /** @var $linkedDietrichlitref DietrichliteraturreferenzEntity */
            $linkedDietrichlitref->setDietrichliteraturreferenzEntity(null);
        }

        $dietLitrefNormLitrefs = $this->dietrichLitref->getDietrichlitrefNormlitrefEntities();
        foreach ($dietLitrefNormLitrefs as $dietLitrefNormLitref) {
            /** @var DietrichlitrefNormlitrefEntity $dietLitrefNormLitref */
            $bandUrls = $dietLitrefNormLitref->getBandUrlEntities();
            foreach ($bandUrls as $bandUrl) {
                $doctrineManager->remove($bandUrl);
            }
            $doctrineManager->remove($dietLitrefNormLitref);
        }

        $doctrineManager->remove($this->dietrichLitref);

        $doctrineManager->flush();
    }

    private function setRedirectRoute()
    {
        /** @var DietrichliteraturreferenzRepository $dietrichLitrefRepo */
        $dietrichLitrefRepo = $this->getBackendDoctrineManager()
            ->getRepository(DietrichliteraturreferenzEntity::class);
        $dietrichLitref = $this->dietrichLitref;
        if ($this->dietrichLitref->getBandEntity() === null) {
            throw new \RuntimeException('DietrichliteraturreferenzEntity has no associated BandEntity.');
        }
        $bandkuerzel = $this->dietrichLitref->getBandEntity()->getBandkuerzel();

        $redirectRequest = $this->getRedirectRequest();
        $redirectRequest->route = LiteraturreferenzAdministrationController::LITERATURREFERENZADMINISTRATION_ROUTE;
        $redirectRequest->shallRedirect = true;
        $redirectRequest->params['bandkuerzel'] = $bandkuerzel;

        $nextDietrichLitref = $dietrichLitrefRepo->findNextDietrichliteraturreferenzOf($dietrichLitref);
        if ($nextDietrichLitref) {
            $redirectRequest->params['sigle'] = $nextDietrichLitref->getUrlEscapedSigle();
        } else {
            $previousDietrichLitref = $dietrichLitrefRepo->findPreviousDietrichliteraturreferenzOf($dietrichLitref);
            if ($previousDietrichLitref) {
                $redirectRequest->params['sigle'] = $previousDietrichLitref->getUrlEscapedSigle();
            } else {
                $redirectRequest->route = LiteraturreferenzListeController::ROUTE_LIST_ALL_LITERATURREFERENZEN;
                $redirectRequest->params['pageNumber'] = 1;
            }
        }
    }
}