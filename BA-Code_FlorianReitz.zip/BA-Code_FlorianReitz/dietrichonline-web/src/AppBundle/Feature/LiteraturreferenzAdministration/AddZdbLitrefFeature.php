<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Feature\FeatureBase;
use AppBundle\Util\Log;
use Doctrine\ORM\EntityRepository;
use OutOfBoundsException;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use AppBundle\Crawler\ZdbDublinCore;
use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use AppBundle\Entity\LiteraturtypEntity;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;

class AddZdbLitrefFeature
    extends FeatureBase
{
    /**
     * @var FormInterface
     */
    private $addZdbLitrefForm;

    /**
     * @var EntityRepository
     */
    private $normlitrefRepository;

    /**
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichlitref;

    /**
     * @var string
     */
    private $addZdbLitrefFormError;

    /**
     * @var FormView
     */
    private $addZdbLitrefFormView;

    public function __construct(LitrefAdminFeatureContext $context)
    {
        parent::__construct($context);
        $this->dietrichlitref = $context->dietrichLitref;
        $this->normlitrefRepository = $this->getBackendDoctrineManager()
            ->getRepository(NormliteraturreferenzEntity::class);
        $this->addZdbLitrefForm = $this->buildAddZdbLitrefForm();
        $this->handleRequest();
        $this->addZdbLitrefFormView = $this->addZdbLitrefForm->createView();
    }

    public function getAddZdbLitrefFormView()
    {
        return $this->addZdbLitrefFormView;
    }

    public function getAddZdbLitrefFormError()
    {
        return $this->addZdbLitrefFormError;
    }

    public function getAddZdbLitrefForm()
    {
        return $this->addZdbLitrefForm;
    }

    private function buildAddZdbLitrefForm()
    {
        return $this->getFormFactory()->createNamedBuilder('add_zdb_litref_by_id')
            ->add('id', TextType::class)
            ->add('add', SubmitType::class, ['label' => 'hinzufügen'])
            ->getForm();
    }

    private function handleRequest()
    {
        try {
            $form = $this->addZdbLitrefForm;
            $form->handleRequest($this->getRequest());
            if ($form->isSubmitted() && $form->isValid()) {
                $id = $form->getData()['id'];
                $newNormlitref = ZdbDublinCore::retrieveNormlitrefEntityByZdbId($id);
                $normlitrefSuccessfullyRetrieved = $newNormlitref !== null;
                if ($normlitrefSuccessfullyRetrieved) {
                    $storedNormlitref = $this->findStoredNormlitref($newNormlitref);
                    if (!$storedNormlitref) {
                        $storedNormlitref = $this->persistNormlitref($newNormlitref);
                        $dietrichlitrefNormlitrefIsStored = false;
                    } else {
                        $dietrichlitrefNormlitrefIsStored = $this->checkDietrichlitrefNormlitrefIsStored(
                            $storedNormlitref
                        );
                    }

                    if (!$dietrichlitrefNormlitrefIsStored) {
                        $this->persistDietrichlitrefNormlitref($storedNormlitref);
                    }
                } else {
                    $this->addZdbLitrefFormError = 'Es konnte keine Zeitschrift mit der ZDB-ID "'
                        .$id.'" gefunden werden.';
                }
            }
        } catch (ServiceUnavailableHttpException $e) {
            Log::error($this->getLogger(), 'The ZDB-Services are unavailable. The data could not be retrieved.', $e);
            $this->addZdbLitrefFormError = 'Die ZDB-ID konnte nicht geprüft werden. 
            Der ZDB-Dienst ist momentan nicht erreichbar. 
            Versuchen Sie es bitte später nochmal. 
            Weitere Informationen finden Sie unter https://zdb-katalog.de.';
        } catch (OutOfBoundsException $e) {
            Log::error($this->getLogger(), $e->getMessage(), $e);
            $this->addZdbLitrefFormError = 'Fehler: Es wurde nach der Suche mit der eingegebenen ZDB-ID mehr als ein Ergebnis gefunden.
            Bitte benachrichtigen Sie zuständige Mitarbeiter der Dietrich-Online IT-Crew.';
        }
    }

    private function persistNormlitref(NormliteraturreferenzEntity $newNormlitref)
    {
        $doctrineManager = $this->getBackendDoctrineManager();
        $literaturtypRepository = $doctrineManager->getRepository(LiteraturtypEntity::class);
        /** @var $zeitschriftLiteraturtyp LiteraturtypEntity */
        $zeitschriftLiteraturtyp = $literaturtypRepository->findOneBy(['bezeichnung' => 'Zeitschrift']);
        $newNormlitref->setLiteraturtypEntity($zeitschriftLiteraturtyp);
        $newNormlitref->setKeineWerkUrlGefunden(false);
        $doctrineManager->persist($newNormlitref);
        $doctrineManager->flush();

        return $newNormlitref;
    }

    /**
     * @param NormliteraturreferenzEntity $newNormlitref
     * @return NormliteraturreferenzEntity|null
     */
    private function findStoredNormlitref(NormliteraturreferenzEntity $newNormlitref)
    {
        /** @var NormliteraturreferenzEntity $storedNormLitref */
        $storedNormLitref = $this->normlitrefRepository->findOneBy(
            [NormliteraturreferenzEntity::ZDB_ID => $newNormlitref->getZdbId()]
        );

        return $storedNormLitref;
    }

    private function checkDietrichlitrefNormlitrefIsStored(NormliteraturreferenzEntity $storedNormlitref)
    {
        $dietrichlitrefNormlitrefRepository = $this->getBackendDoctrineManager()
            ->getRepository(DietrichlitrefNormlitrefEntity::class);
        $dietrichlitrefNormlitref = $dietrichlitrefNormlitrefRepository->findOneBy(
            [
                'dietrichliteraturreferenzEntity' => $this->dietrichlitref,
                'normliteraturreferenzEntity' => $storedNormlitref,
            ]
        );

        return $dietrichlitrefNormlitref !== null;
    }

    private function persistDietrichlitrefNormlitref(NormliteraturreferenzEntity $storedNormlitref)
    {
        $doctrineManager = $this->getBackendDoctrineManager();
        $dietrichlitrefNormlitref = new DietrichlitrefNormlitrefEntity();
        $dietrichlitrefNormlitref->setDietrichliteraturreferenzEntity($this->dietrichlitref);
        $dietrichlitrefNormlitref->setNormliteraturreferenzEntity($storedNormlitref);
        $dietrichlitrefNormlitref->setKeineBandUrlGefunden(false);
        $doctrineManager->persist($dietrichlitrefNormlitref);

        $doctrineManager->flush();

        /* weird workaround cause the oneToMany-ralation to bandUrls is
         * not working properly somehow, without refreshing the cache of the
         * object. */
        $doctrineManager->refresh($dietrichlitrefNormlitref);
    }
}
