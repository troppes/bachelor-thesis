<?php

namespace AppBundle\Feature\LiteraturreferenzAdministration;

use AppBundle\Entity\WerkUrlEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Util\UrlUtil;
use InvalidArgumentException;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormError;
use Symfony\Component\Form\FormView;
use Symfony\Component\Form\SubmitButton;

class EditWerkUrlFeature extends FeatureBase
{
    private $context;
    private $werkUrlEntity;
    private $werkUrlEditFormView;
    private $werkUrlDeleteFormView;
    private $dietLitNormLitFeature;

    public function __construct(FeatureContext $context, WerkUrlEntity $werkUrlEntity,
                                EditDietLitNormLitFeature $dietLitNormLitFeature)
    {
        parent::__construct($context);

        $this->context = $context;
        $this->werkUrlEntity = $werkUrlEntity;
        $this->dietLitNormLitFeature = $dietLitNormLitFeature;

        $this->manageWerkUrlEditForm();
    }

    /**
     * @return FormView
     */
    public function getWerkUrlDeleteFormView()
    {
        return $this->werkUrlDeleteFormView;
    }

    /**
     * @return FormView
     */
    public function getWerkUrlEditFormView()
    {
        return $this->werkUrlEditFormView;
    }

    public static function constructList(FeatureContext $context, $werkUrlEntities,
                                         EditDietLitNormLitFeature $dietLitNormLitFeature)
    {
        $editWerkUrlFeatures = [];
        foreach ($werkUrlEntities as $werkUrlEntity) {
            $editWerkUrlFeatures[] = new EditWerkUrlFeature($context, $werkUrlEntity, $dietLitNormLitFeature);
        }
        return $editWerkUrlFeatures;
    }

    private function manageWerkUrlEditForm()
    {
        $name = 'werkUrlEditForm_' . $this->werkUrlEntity->getId();
        $form = $this->context->formFactory->createNamedBuilder(
            $name,
            FormType::class,
            $this->werkUrlEntity
        )
            ->add(WerkUrlEntity::URL, UrlType::class)
            ->add(WerkUrlEntity::BEMERKUNG, TextType::class, ['required' => false])
            ->add('delete', SubmitType::class)
            ->getForm();

        $form->handleRequest($this->getRequest());

        if ($form->isSubmitted())
        {
            /* @var $deleteButton SubmitButton */
            $deleteButton = $form->get('delete');
            if ($deleteButton->isClicked())
            {
                $this->context->backendDoctrineManager->remove($this->werkUrlEntity);

                $this->context->backendDoctrineManager->flush();
                $this->dietLitNormLitFeature->setHasBeenUpdatedAndRedirect();
            }
            else if ($form->isValid())
            {
                //update
                $this->context->backendDoctrineManager->merge($this->werkUrlEntity);

                $this->context->backendDoctrineManager->flush();
                $this->dietLitNormLitFeature->setHasBeenUpdatedAndRedirect();
            }
            else
            {
                try
                {
                    $repairedUrl = UrlUtil::getSpecialEncodedUrl($this->werkUrlEntity->getUrl());
                    $form->get(WerkUrlEntity::URL)
                        ->addError(new FormError(UrlUtil::LITERAL_ERROR_MSG))
                        ->addError(new FormError($repairedUrl));
                }
                catch (InvalidArgumentException $e)
                {
                    // shown as general "not an URL" error
                }

                $this->dietLitNormLitFeature->setSubFeatureHasError(true);
            }
        }

        $this->werkUrlEditFormView = $form->createView();
    }
}