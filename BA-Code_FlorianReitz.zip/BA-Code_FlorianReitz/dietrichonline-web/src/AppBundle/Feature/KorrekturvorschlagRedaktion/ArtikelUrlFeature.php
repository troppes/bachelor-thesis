<?php
/*
TODO: in ubdgigbib2 db einfügen und in ER Diagramm einfügen
CREATE TABLE `artikel_url` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `url` text NOT NULL,
    `fk_artikel` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    UNIQUE KEY `id` (`id`),
    KEY `fk_artikel` (`fk_artikel`),
    CONSTRAINT `artikel_url_ibfk_1` FOREIGN KEY (`fk_artikel`) REFERENCES `artikel` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
    ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8
*/

namespace AppBundle\Feature\KorrekturvorschlagRedaktion;

use AppBundle\Entity\KorrekturvorschlagEntity;
use AppBundle\Feature\FeatureContext;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\FormInterface;
use AppBundle\Entity\VorgeschlageneUrlEntity;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use AppBundle\Entity\ArtikelUrlEntity;
use AppBundle\Feature\FeatureBase;

class ArtikelUrlFeature {
    const ARTIKEL_URL_FORM = 'artikel_url_form';
    
    public function __construct(KorrekturvorschlagEntity $korrekturvorschlag, FeatureContext $context) {
        $this->korrekturvorschlag = $korrekturvorschlag;
        $this->context = $context;
        $this->doctrineManager = $context->doctrine->getManager(FeatureBase::DB_BACKEND);
        
        $this->createArtikelForms();
        $this->processArtikelUrlForm();
    }
    
    public function getArtikelUrlForms() {
        return $this->artikelUrlForms;
    }
    
    private function createArtikelForms() {
        $this->artikelUrlForms = [];
        foreach ($this->korrekturvorschlag->getVorgeschlageneUrlEntities() as $urlEntity) {
            /* @var $urlEntity VorgeschlageneUrlEntity */
             $this->artikelUrlForm = $this->context->formFactory->createNamedBuilder(
                self::ARTIKEL_URL_FORM,
                FormType::class,
                ['url' => $urlEntity->getUrl()]
            )
            ->add('url', TextType::class)
            ->getForm();
            $this->artikelUrlForms[] = $this->artikelUrlForm->createView();
        }
    }
    
    private function processArtikelUrlForm() {
        if (isset($this->artikelUrlForm)) {
            /* @var $artikelUrlForm FormInterface */
            $artikelUrlForm = $this->artikelUrlForm;
            $artikelUrlForm->handleRequest($this->context->request);
            if($artikelUrlForm->isSubmitted() && $artikelUrlForm->isValid()) {
                $url = $artikelUrlForm->getData()['url'];
                $artikelUrlRepo = $this->doctrineManager->getRepository(ArtikelUrlEntity::class);
                //Check if URL is already set
                $urlIsStored = !is_null($artikelUrlRepo->findOneBy([
                    'artikelEntity' => $this->korrekturvorschlag->getArtikelEntity(),
                    'url' => $url
                ]));
                if (!$urlIsStored) {
                    $artikelUrlEntity = new ArtikelUrlEntity();
                    $artikelUrlEntity->setArtikelEntity($this->korrekturvorschlag->getArtikelEntity());
                    $artikelUrlEntity->setUrl($url);
                    $this->doctrineManager->persist($artikelUrlEntity);
                    $this->doctrineManager->flush();
                }
            }
        }
    }
    
    private $korrekturvorschlag;
    private $context;

  /**
   * @var ObjectManager
   */
    private $doctrineManager;
    
    private $artikelUrlForms;
    private $artikelUrlForm;
}
