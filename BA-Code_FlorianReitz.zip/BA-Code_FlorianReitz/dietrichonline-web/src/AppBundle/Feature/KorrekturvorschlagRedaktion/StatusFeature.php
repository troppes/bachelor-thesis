<?php
namespace AppBundle\Feature\KorrekturvorschlagRedaktion;

use AppBundle\Entity\KorrekturvorschlagEntity;
use AppBundle\Entity\KorrekturvorschlagstatusEntity;
use AppBundle\Feature\FeatureContext;
use Doctrine\Common\Persistence\ObjectManager;
use AppBundle\Feature\FeatureBase;

class StatusFeature {
    public function __construct(KorrekturvorschlagEntity $korrekturvorschlag, FeatureContext $context) {
        $this->korrekturvorschlag = $korrekturvorschlag;
        $this->context = $context;
        $this->doctrineManager = $context->doctrine->getManager(FeatureBase::DB_BACKEND);
        
        $this->processStatusList();
    }
    
    public function getCurrentStatus() {
        return $this->korrekturvorschlag->getKorrekturvorschlagstatusEntity()->getBezeichnung();
    }
    
    /**
     * Get statusList
     *
     * @return array
     */
    public function getStatusFormList() {
        return $this->statusFormList;
    }
    
    private function processStatusList() {
        $statusList = $this->doctrineManager->getRepository(KorrekturvorschlagstatusEntity::class)
          ->findAll();
        $statusFormList = [];
        /* @var $status KorrekturvorschlagstatusEntity */
        foreach ($statusList as $status) {
            $formView = $this->processStatus($status->getBezeichnung())->createView();
            $formView->vars['status_bezeichnung'] = $status->getBezeichnung(); 
            $statusFormList[] = $formView;
        }
        $this->statusFormList = $statusFormList;
    }
    
    private function processStatus($bezeichnung) {
        $formName = 'set_status_'.str_replace(' ', '_', $bezeichnung);
        $form = $this->context->formFactory->createNamed($formName);
        $form->handleRequest($this->context->request);
        if ($form->isSubmitted() && $form->isValid()) {
            $status = $this->doctrineManager->getRepository(KorrekturvorschlagstatusEntity::class)
              ->findOneBy(['bezeichnung'=>$bezeichnung]);
            $this->korrekturvorschlag->setKorrekturvorschlagstatusEntity($status);
            $this->doctrineManager->flush();
            $this->context->redirectRequest->shallRedirect = true;
        }
        return $form;
    }
    
    private $korrekturvorschlag;
    private $context;

    /**
     * @var ObjectManager
     */
    protected $doctrineManager;
    
    /**
     * @var array
     */
    protected $statusFormList;
}
