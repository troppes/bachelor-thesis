<?php


namespace AppBundle\Feature;


use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;

class SimpleUserSearchFeature
{
    /**
     * @var FormInterface
     */
    private $simpleUserSearchForm;
    /**
     * @var \Symfony\Component\Form\FormView
     */
    private $simpleUserSearchFormView;

    public function __construct(FeatureContext $featureContext)
    {
        $router = $featureContext->getRouter();
        if (!$router) {
            throw new \Error('Router must be given to generate URL.');
        }
        $this->simpleUserSearchForm = $featureContext->formFactory->createNamedBuilder('simpleUserSearch', FormType::class, null, [
            'method' => 'GET',
            'action' => $router->generate('user_search'),
            'csrf_protection' => false
        ])
            ->add('begriff', TextType::class)
            ->getForm();

        $this->simpleUserSearchFormView = $this->simpleUserSearchForm->createView();
    }

    /**
     * @return \Symfony\Component\Form\FormView
     */
    public function getSimpleUserSearchFormView(): \Symfony\Component\Form\FormView
    {
        return $this->simpleUserSearchFormView;
    }
}