<?php

namespace AppBundle\Feature;

use AppBundle\Controller\RedirectRequest;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Psr\Log\LoggerInterface;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;

class FeatureContext
{
    public $request;
    public $doctrine;
    public $formFactory;
    public $redirectRequest;
    public $backendDoctrineManager;
    public $frontendDoctrineManager;

    /** @var LoggerInterface */
    private $logger;

    /**
     * @var Router
     */
    private $router;


    public function __construct(Request $request,
                                Registry $doctrine,
                                FormFactory $formFactory,
                                RedirectRequest $redirectRequest,
                                LoggerInterface $logger = null,
                                Router $router = null
    )
    {
        $this->request = $request;
        $this->doctrine = $doctrine;
        $this->formFactory = $formFactory;
        $this->redirectRequest = $redirectRequest;
        $this->backendDoctrineManager = $doctrine->getManager(FeatureBase::DB_BACKEND);
        $this->frontendDoctrineManager = $doctrine->getManager(FeatureBase::DB_FRONTEND);
        $this->logger = $logger;
        $this->router = $router;
    }

    /**
     * @return LoggerInterface|null
     */
    public function getLogger()
    {
        return $this->logger;
    }

    /**
     * @return Router|null
     */
    public function getRouter()
    {
        return $this->router;
    }
}