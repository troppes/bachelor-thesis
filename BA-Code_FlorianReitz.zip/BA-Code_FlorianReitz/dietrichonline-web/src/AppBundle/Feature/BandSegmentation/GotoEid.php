<?php

namespace AppBundle\Feature\BandSegmentation;

use AppBundle\Controller\BandSegmentation\BandSegmentationController;
use AppBundle\Entity\SegmentationsFehlerEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Repository\BandSegmentationRepository;
use Exception;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class GotoEid
    extends FeatureBase
{
    /**
     * @var FormInterface
     */
    private $form;

    /**
     * @var FormView
     */
    private $formView;

    private $eidField;


    public function __construct(FeatureContext $context)
    {
        parent::__construct($context);
        $this->buildForm();
        $this->handleRequest();
        $this->formView = $this->form->createView();
    }

    public function getFormView(): FormView
    {
        return $this->formView;
    }

    private function handleRequest()
    {
        $this->form->handleRequest($this->getRequest());
        if ($this->form->isSubmitted() && $this->form->isValid()) {

            /** @var BandSegmentationRepository $repo */
            $repo = $this->getBackendDoctrineManager()->getRepository(SegmentationsFehlerEntity::class);

            $eid = $this->getRequest()->get('gotoEid')['eidField'];

            /** @var SegmentationsFehlerEntity $entry */
            $entry = $repo->find($eid);


            if ($entry === null) { //If an invalid Entry was called do nothing
                return null;
            }

            $bandNr =$entry->getBand();
            try {
                $page = $repo->getPageNumberByEntry($eid);
            } catch (Exception $e) {
                $page = BandSegmentationController::DEFAULT_PAGE_INDEX;
            }

            $this->getRedirectRequest()
                ->setShallRedirect(true)
                ->setRoute('band_segmentation')
                ->addParam('pageNumber', $page)
                ->addParam('bandkuerzel', $bandNr)
                ->addParam('_fragment', $eid);
        }
    }

    private function buildForm()
    {
        $this->form = $this->getFormFactory()->createNamedBuilder('gotoEid', FormType::class, $this)
            ->add('eidField', TextType::class)
            ->getForm();
    }

    /**
     * @return mixed
     */
    public function getEidField()
    {
        return $this->eidField;
    }

    /**
     * @param mixed $eidField
     */
    public function setEidField($eidField)
    {
        $this->eidField = $eidField;
    }
}
