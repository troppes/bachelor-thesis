<?php
namespace AppBundle\Feature\Korrekturvorschlag;

use Symfony\Bridge\Twig\Form\TwigRenderer;
use AppBundle\Entity\KorrektorEntity;

class DankesMailFeature {
    const FROM = 'info@dietrich.uni-trier.de';
    const SUBJECT = 'Vielen Dank für Ihre Mithilfe bei Dietrich Online';
    
    public static function send(KorrektorEntity $korrektor, \Swift_Mailer $mailer, \Twig_Environment $twig) {
        $to = $korrektor->getEmail();
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            // TODO: error handling? Error silently ignored now, because you never really know that every data record is consistent.
            return;
        }
        
        $message = new \Swift_Message();
        $message->setFrom(self::FROM)
        ->setTo($to)
        ->setSubject(self::SUBJECT)
        ->setBody($twig->render('Korrekturvorschlag\dankesMail.html.twig', ['dietrichEmailAddress' => self::FROM]), 'text/html');
        
        $mailer->send($message);
    }
}
