<?php
namespace AppBundle\Feature\Korrekturvorschlag;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use AppBundle\Entity\KorrektorEntity;
use AppBundle\Entity\KorrekturvorschlagEntity;
use AppBundle\Entity\VorgeschlageneUrlEntity;
use Gregwar\CaptchaBundle\Type\CaptchaType;

class KorrekturvorschlagType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder->add('titel', TextareaType::class, ['required' => false])
        ->add('autor', TextType::class, ['required' => false])
        ->add('literaturreferenz', TextareaType::class, ['required' => false])
        ->add('sonstiges', TextareaType::class, ['required' => false])
        ->add('vorgeschlageneUrlEntities', CollectionType::class, [
            'required' => false,
            'entry_type' => VorgeschlageneUrlType::class,
            'by_reference' => false,
            'allow_add' => true,
            'prototype' => true,
            'prototype_name' => '__index__'
        ])
        ->add('korrektorEntity', KorrektorType::class)
        ->add('captcha', CaptchaType::class, [
            'width' => 240,
            'height' => 80,
            'invalid_message' => 'Leider konnte die Eingabe nicht validiert werden. Bitte versuchen Sie es erneut.',
        ]);
    }
    
    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefault('data_class', KorrekturvorschlagEntity::class);
    }
    
    public function getName() {
        return 'korrekturvorschlag';
    }
}

class KorrektorType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder->add('email', TextType::class, ['required' => false])
        ->add('vorname', TextType::class, ['required' => false])
        ->add('nachname', TextType::class, ['required' => false])
        ->add('titel', TextType::class, ['required' => false]);
    }
    
    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefault('data_class', KorrektorEntity::class);
    }
    
    public function getName() {
        return 'korrektor';
    }
}

class VorgeschlageneUrlType extends AbstractType {
    public function buildForm(FormBuilderInterface $builder, array $options) {
        $builder->add('url');
    }
    
    public function configureOptions(OptionsResolver $resolver) {
        $resolver->setDefault('data_class', VorgeschlageneUrlEntity::class);
    }
    
    public function getName() {
        return 'vorgeschlageneUrl';
    }
}
