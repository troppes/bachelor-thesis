<?php

namespace AppBundle\Feature;


use AppBundle\Controller\RedirectRequest;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use Psr\Log\LoggerInterface;

abstract class FeatureBase
{
    /**
     * Backend Doctrine Manager Name
     */
    const DB_BACKEND = "backend";

    /**
     * Frontend Doctrine Manager Name
     *
     * "frontend" is set as default manager in app/config/config.yml
     */
    const DB_FRONTEND = "frontend";

    /**
     * Doctrine Manager Option Variable Name
     *
     * Used for example in configureOptions(..) of derived symfony form types
     */
    const DOCTRINE_MANAGER = 'doctrine_manager';

    private $request;

    private $doctrine;

    private $formFactory;

    private $redirectRequest;

    private $backendDoctrineManager;

    private $frontendDoctrineManager;

    /**
     * @var FeatureContext
     */
    private $context;

    /**
     * @param FeatureContext $context for initialization. A controller usually uses several different Feature objects.
     * The common initialization parameters are bundled into the given FeatureContext.
     */
    public function __construct(FeatureContext $context)
    {
        $this->context = $context;
        $this->request = $context->request;
        $this->doctrine = $context->doctrine;
        $this->formFactory = $context->formFactory;
        $this->redirectRequest = $context->redirectRequest;
        $this->backendDoctrineManager = $context->backendDoctrineManager;
        $this->frontendDoctrineManager = $context->frontendDoctrineManager;
    }

    /**
     * @return Request
     */
    public function getRequest()
    {
        return $this->request;
    }

    /**
     * @return Registry
     */
    public function getDoctrineRegistry()
    {
        return $this->doctrine;
    }

    /**
     * @return FormFactory
     */
    public function getFormFactory()
    {
        return $this->formFactory;
    }

    /**
     * @return RedirectRequest
     */
    public function getRedirectRequest()
    {
        return $this->redirectRequest;
    }

    /**
     * @return ObjectManager
     */
    public function getBackendDoctrineManager()
    {
        return $this->backendDoctrineManager;
    }

    /**
     * @return ObjectManager
     */
    public function getFrontendDoctrineManager()
    {
        return $this->frontendDoctrineManager;
    }

    /**
     * @return LoggerInterface|null
     */
    public function getLogger()
    {
        return $this->context->getLogger();
    }
}