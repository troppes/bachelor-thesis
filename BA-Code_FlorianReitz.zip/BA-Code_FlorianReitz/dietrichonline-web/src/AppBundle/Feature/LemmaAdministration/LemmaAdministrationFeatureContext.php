<?php

namespace AppBundle\Feature\LemmaAdministration;


use AppBundle\Controller\RedirectRequest;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Feature\FeatureContext;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;

class LemmaAdministrationFeatureContext
    extends FeatureContext
{
    /** @var LemmaEntity */
    private $lemmaEntity;

    public function __construct(Request $request,
                                Registry $doctrine,
                                FormFactory $formFactory,
                                RedirectRequest $redirectRequest,
                                $lemmaId,
                                LoggerInterface $logger)
    {
        parent::__construct($request, $doctrine, $formFactory, $redirectRequest, $logger);
        $this->lemmaEntity = $this->backendDoctrineManager->getRepository(LemmaEntity::class)->find($lemmaId);
    }

    /**
     * @return LemmaEntity|null
     */
    public function getLemmaEntity()
    {
        return $this->lemmaEntity;
    }
}