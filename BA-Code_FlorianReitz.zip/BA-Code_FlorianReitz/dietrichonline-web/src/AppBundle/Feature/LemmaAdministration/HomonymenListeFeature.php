<?php

namespace AppBundle\Feature\LemmaAdministration;

use AppBundle\Entity\BandEntity;
use AppBundle\Repository\BandRepository;
use AppBundle\Repository\LemmaRepository;
use AppBundle\Entity\LemmaEntity;

class HomonymenListeFeature extends LemmaAdminstrationFeatureBase
{
    /**
     * @var array
     */
    private $homonymeLemmaEntitiesAndBaende;

    public function getHomonymeLemmaEntitiesAndBaende()
    {
        return $this->homonymeLemmaEntitiesAndBaende;
    }

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);
        $doctrineManager = $this->getBackendDoctrineManager();

        /** @var $lemmaRepo LemmaRepository */
        $lemmaRepo = $doctrineManager->getRepository(LemmaEntity::class);

        /** @var $bandRepo BandRepository */
        $bandRepo = $doctrineManager->getRepository(BandEntity::class);

        $this->homonymeLemmaEntitiesAndBaende = [];
        $homonymeLemmaEntities = $lemmaRepo->findHomonymList($this->getLemmaEntity());

        /** @var $homonymesLemmaEntity LemmaEntity */
        foreach ($homonymeLemmaEntities as $homonymesLemmaEntity) {
            $baende = $bandRepo->findByLemmaId($homonymesLemmaEntity->getId());

            $this->homonymeLemmaEntitiesAndBaende[] = [
                'lemmaEntity' => $homonymesLemmaEntity,
                'baende' => $baende
            ];
        }
    }
}