<?php

namespace AppBundle\Feature\LemmaAdministration;

use AppBundle\Entity\LemmaEntity;
use AppBundle\Entity\BandEntity;
use AppBundle\Repository\BandRepository;

class LemmaBandFeature extends LemmaAdminstrationFeatureBase
{
    public $baende;

    /**
     * @var array
     */
    private $baendeFromSubLemmas;

    public function getBaendeFromSubLemmas(): array
    {
        return $this->baendeFromSubLemmas;
    }

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);

        /* @var $bandRepo BandRepository */
        $bandRepo = $this->getBackendDoctrineManager()->getRepository(BandEntity::class);
        $this->baende = $bandRepo->findByLemmaId($this->getLemmaEntity()->getId());

        $this->baendeFromSubLemmas = [];
        /** @var LemmaEntity $groupedLemma */
        foreach ($this->getLemmaEntity()->getGroupedLemmas() as $groupedLemma) {
            if ($groupedLemma->isSubLemma()) {
                $baende = $bandRepo->findByLemmaId($groupedLemma->getId());
                foreach ($baende as $band) {
                    $this->baendeFromSubLemmas[] = $band;
                }
            }
        }
    }
}