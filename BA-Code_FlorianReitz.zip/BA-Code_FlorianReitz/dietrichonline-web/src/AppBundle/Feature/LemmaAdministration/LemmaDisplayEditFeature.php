<?php
namespace AppBundle\Feature\LemmaAdministration;

use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

class LemmaDisplayEditFeature extends LemmaAdminstrationFeatureBase {
    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);
        $this->lemmaEditForm = $this->buildLemmaEditForm();
        $this->handleRequest();
        $this->lemmaEditFormView = $this->lemmaEditForm->createView();
    }

    private function buildLemmaEditForm()
    {
        return $this->getFormFactory()->createNamedBuilder(
            'lemmaEditForm',
            FormType::class,
            $this->getLemmaEntity()
        )
            ->add('originalBezeichnung', TextType::class)
            ->add('erweiterung', TextType::class, ['required' => false])
            ->add('originalHomonymZusatz', TextType::class, ['required' => false])
            ->add('neuerHomonymZusatz', TextType::class, ['required' => false])
            ->getForm();
    }

    /**
     * @var FormInterface
     */
    private $lemmaEditForm;

    /**
     * @var FormView
     */
    private $lemmaEditFormView;

    public function getLemmaEditFormView() {
        return $this->lemmaEditFormView;
    }

    public function setLemmaEditFormView(FormView $lemmaEditFormView) {
        $this->lemmaEditFormView = $lemmaEditFormView;
        return $this;
    }

    public function getLemmaEditForm() {
        return $this->lemmaEditForm;
    }

    public function setLemmaEditForm(FormInterface $lemmaEditForm) {
        $this->lemmaEditForm = $lemmaEditForm;
        return $this;
    }

    private function handleRequest()
    {
        $lemmaEditForm = $this->lemmaEditForm;
        $doctrineManager = $this->getBackendDoctrineManager();
        $redirectRequest = $this->getRedirectRequest();

        $lemmaEditForm->handleRequest($this->getRequest());
        if ($lemmaEditForm->isSubmitted()) {
            if ($lemmaEditForm->isValid()) {
                $doctrineManager->flush();

                $redirectRequest->params['lemmaEditSubmitted'] = 1;
                $redirectRequest->shallRedirect = true;
            } else {
                // reset changes via refresh
                $doctrineManager->refresh($this->getLemmaEntity());
            }
        }
    }
}
