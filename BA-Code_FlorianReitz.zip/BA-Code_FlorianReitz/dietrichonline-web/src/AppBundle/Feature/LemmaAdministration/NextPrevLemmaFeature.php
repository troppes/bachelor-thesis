<?php
namespace AppBundle\Feature\LemmaAdministration;

use AppBundle\Entity\LemmaEntity;
use AppBundle\Repository\LemmaRepository;

class NextPrevLemmaFeature extends LemmaAdminstrationFeatureBase {

    /**
     * @var integer
     */
    private $nextLemmaId;

    /**
     * @var integer
     */
    private $previousLemmaId;

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);

        /* @var $lemmaRepo LemmaRepository */
        $lemmaRepo = $this->getBackendDoctrineManager()->getRepository(LemmaEntity::class);
        $lemmaEntity = $this->getLemmaEntity();

        $status =  $this->getRedirectRequest()->params['filter'];

        $previousLemma = $lemmaRepo->findPrevious($lemmaEntity, $status);
        $this->previousLemmaId = is_null($previousLemma) ? null : $previousLemma->getId();

        $nextLemma = $lemmaRepo->findNext($lemmaEntity, $status);
        $this->nextLemmaId = is_null($nextLemma) ? null : $nextLemma->getId();
    }

	public function getNextLemmaId() {
	    return $this->nextLemmaId;
	}

	public function getPreviousLemmaId() {
	    return $this->previousLemmaId;
	}
}