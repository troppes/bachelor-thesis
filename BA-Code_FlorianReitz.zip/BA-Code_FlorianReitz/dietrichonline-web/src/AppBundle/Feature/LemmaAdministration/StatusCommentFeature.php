<?php

namespace AppBundle\Feature\LemmaAdministration;

use Symfony\Component\HttpFoundation\Request;
use Doctrine\Bundle\DoctrineBundle\Registry;
use AppBundle\Entity\LemmaEntity;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use AppBundle\Entity\LemmabearbeitungsstatusEntity;
use Symfony\Component\Form\FormInterface;
use AppBundle\Controller\RedirectRequest;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\FormView;
use AppBundle\Feature\FeatureBase;

class StatusCommentFeature extends LemmaAdminstrationFeatureBase
{
    /**
     * @var FormInterface
     */
    protected $statusCommentForm;

    /**
     * @var FormView
     */
    public $statusCommentFormView;

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);
        $this->statusCommentForm = $this->buildStatusCommentForm();
        $this->handleRequest();
        $this->statusCommentFormView = $this->statusCommentForm->createView();
    }

    public function handleRequest()
    {
        $this->statusCommentForm->handleRequest($this->getRequest());
        if ($this->statusCommentForm->isSubmitted() && $this->statusCommentForm->isValid()) {
            $this->getBackendDoctrineManager()->flush();

            $this->getRedirectRequest()->shallRedirect = true;
            $this->getRedirectRequest()->params['statusCommentSubmitted'] = 1;
        }
    }

    private function buildStatusCommentForm()
    {
        return $this->getFormFactory()->createNamedBuilder(
            'statusCommentForm',
            FormType::class,
            $this->getLemmaEntity()
        )
            ->add('allgemeinebemerkung', TextareaType::class, [
                'required' => false
            ])
            ->add('lemmabearbeitungsstatusEntity', EntityType::class, [
                'em' => $this->getBackendDoctrineManager(),
                'class' => LemmabearbeitungsstatusEntity::class,
                'choice_label' => 'bezeichnung',
                'placeholder' => false,
                'required' => false
            ])
            ->getForm();
    }
}