<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LemmaAdministration;

use AppBundle\Entity\GndEntity;
use AppBundle\Entity\LemmaGndEntity;
use Symfony\Component\Form\FormInterface;
use Symfony\Component\Form\FormView;

class GndEntityView
{
    /**
     * @var GndEntity
     */
    private $gndEntity;

    /**
     * @var FormInterface
     */
    private $deleteGndForm;

    /**
     * @var FormView
     */
    private $deleteGndFormView;

    public function getDeleteGndFormView() {
        return $this->deleteGndFormView;
    }

    public function getDeleteGndForm() {
        return $this->deleteGndForm;
    }

    public function getGndEntity() {
        return $this->gndEntity;
    }

    public function __construct(LemmaGndEntity $lemmaGndEntity, FormInterface $deleteGndForm)
    {
        $this->gndEntity = $lemmaGndEntity->getGndEntity();
        $this->deleteGndForm = $deleteGndForm;
        $this->deleteGndFormView = $deleteGndForm->createView();
    }
}