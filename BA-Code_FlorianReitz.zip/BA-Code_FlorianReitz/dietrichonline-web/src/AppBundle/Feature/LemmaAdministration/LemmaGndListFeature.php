<?php

namespace AppBundle\Feature\LemmaAdministration;

use Symfony\Component\Form\Extension\Core\Type\FormType;
use AppBundle\Entity\LemmaGndEntity;

class LemmaGndListFeature extends LemmaAdminstrationFeatureBase
{
    /**
     * @var array
     */
    private $gndEntityViews;

    public function getGndEntityViews()
    {
        return $this->gndEntityViews;
    }

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);

        $this->gndEntityViews = $this->buildGndEntityViews();
        $this->handleRequest();
    }

    private function buildDeleteGndForm(LemmaGndEntity $lemmaGndEntityToDelete)
    {
        return $this->getFormFactory()->createNamedBuilder(
            'deleteGndForm' . $lemmaGndEntityToDelete->getId(),
            FormType::class,
            $lemmaGndEntityToDelete
        )->getForm();
    }

    private function handleRequest()
    {
        foreach ($this->gndEntityViews as $gndEntityView) {
            /** @var $gndEntityView GndEntityView */
            $form = $gndEntityView->getDeleteGndForm();
            $form->handleRequest($this->getRequest());
            if ($form->isSubmitted()) {
                $lemmaGndEntityToDelete = $form->getData();
                $this->getBackendDoctrineManager()->remove($lemmaGndEntityToDelete);
                $this->getBackendDoctrineManager()->flush();

                $this->getRedirectRequest()->shallRedirect = true;
            }
        }
    }

    private function buildGndEntityViews()
    {
        $lemmaGndEntities = $this->getLemmaEntity()->getLemmaGNDEntities();

        $gndEntityViews = array();
        foreach ($lemmaGndEntities as $lemmaGndEntity) {
            /** @var $lemmaGndEntity LemmaGndEntity */
            $deleteGndForm = $this->buildDeleteGndForm($lemmaGndEntity);
            $gndEntityViews[] = new GndEntityView($lemmaGndEntity, $deleteGndForm);
        }

        return $gndEntityViews;
    }
}