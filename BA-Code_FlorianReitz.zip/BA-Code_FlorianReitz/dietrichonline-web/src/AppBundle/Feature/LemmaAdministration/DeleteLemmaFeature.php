<?php

namespace AppBundle\Feature\LemmaAdministration;

use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\FormInterface;
use AppBundle\Controller\LemmaAdministration\LemmaListController;
use AppBundle\Repository\LemmaRepository;
use Symfony\Component\Form\FormView;

class DeleteLemmaFeature extends LemmaAdminstrationFeatureBase
{
    /**
     * @var FormInterface
     */
    private $deleteLemmaForm;

    /**
     * @var FormInterface
     */
    private $restoreLemmaForm;

    /**
     * @var FormView
     */
    private $deleteLemmaFormView;

    /**
     * @var FormView
     */
    private $restoreLemmaFormView;

    public function getRestoreLemmaFormView() {
        return $this->restoreLemmaFormView;
    }

    public function getDeleteLemmaFormView() {
        return $this->deleteLemmaFormView;
    }

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);
        $this->deleteLemmaForm = $this->buildDeleteLemmaForm();
        $this->restoreLemmaForm = $this->buildRestoreLemmaForm();
        $this->handleRequest();
        $this->deleteLemmaFormView = $this->deleteLemmaForm->createView();
        $this->restoreLemmaFormView = $this->restoreLemmaForm->createView();
    }

    private function handleRequest()
    {
        $this->handleDeleteLemmaForm();
        $this->handleRestoreLemmaForm();
    }

    private function buildDeleteLemmaForm()
    {
        return $this->getFormFactory()->createNamedBuilder('deleteLemmaForm', FormType::class)->getForm();
    }

    private function handleDeleteLemmaForm()
    {
        $lemmaEntity = $this->getLemmaEntity();
        $this->deleteLemmaForm->handleRequest($this->getRequest());
        if ($this->deleteLemmaForm->isSubmitted()) {
            $this->deleteLemmaEntity();

            $redirectRequest = $this->getRedirectRequest();
            $redirectRequest->route = LemmaListController::LEMMA_LISTE_ROUTE;
            if (preg_match("/^[a-zA-Z]/", $lemmaEntity->getBezeichnung()) === 1) {
                $character = $lemmaEntity->getBezeichnung()[0];
            } else {
                $character = 'not_a-z';
            }
            $redirectRequest->params = [
                'character' => $character,
                'filter' => $this->getLemmaEntity()->getLemmabearbeitungsstatusEntity()->getBezeichnung()
            ];
            $redirectRequest->shallRedirect = true;
        }
    }

    private function buildRestoreLemmaForm()
    {
        return $this->getFormFactory()->createNamedBuilder('restoreLemmaForm', FormType::class)->getForm();
    }

    private function handleRestoreLemmaForm()
    {
        $this->restoreLemmaForm->handleRequest($this->getRequest());
        if ($this->restoreLemmaForm->isSubmitted()) {
            $this->restoreLemmaEntity();
            $this->getRedirectRequest()->shallRedirect = true;
        }
    }

    private function deleteLemmaEntity()
    {
        $this->getLemmaEntity()->setIstGeloescht(true);
        $this->getBackendDoctrineManager()->flush();
    }

    private function restoreLemmaEntity()
    {
        $this->getLemmaEntity()->setIstGeloescht(false);
        $this->getBackendDoctrineManager()->flush();
    }
}
