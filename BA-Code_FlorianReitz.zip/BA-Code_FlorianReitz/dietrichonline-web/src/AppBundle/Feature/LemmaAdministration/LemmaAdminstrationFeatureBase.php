<?php
/**
 * @author Kajetan Weiß weiss@uni-trier.de
 */

namespace AppBundle\Feature\LemmaAdministration;


use AppBundle\Entity\LemmaEntity;
use AppBundle\Feature\FeatureBase;

class LemmaAdminstrationFeatureBase
    extends FeatureBase
{
    /**
     * @var LemmaEntity
     */
    private $lemmaEntity;

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);
        $this->lemmaEntity = $context->getLemmaEntity();
        if ($this->lemmaEntity === null) {
            throw new \InvalidArgumentException('lemmaEntity must not be null.');
        }
    }

    /**
     * @return LemmaEntity|null
     */
    public function getLemmaEntity()
    {
        return $this->lemmaEntity;
    }
}