<?php

namespace AppBundle\Feature\LemmaAdministration;

use AppBundle\Crawler\ConnectionTimeoutException;
use AppBundle\Crawler\DnbGndMarc21;
use AppBundle\Crawler\DnbGndMarc21Result;
use AppBundle\Crawler\WebDeweySearch;
use AppBundle\Entity\DdcEntity;
use AppBundle\Entity\GndDdcEntity;
use AppBundle\Entity\GndEntity;
use AppBundle\Entity\LemmabearbeitungsstatusEntity;
use AppBundle\Entity\LemmaGndEntity;
use AppBundle\Repository\DdcRepository;
use AppBundle\Util\Log;
use Doctrine\Common\Persistence\ObjectManager;
use Doctrine\Common\Persistence\ObjectRepository;
use Psr\Log\LoggerInterface;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormInterface;

class AddGndFeature
    extends LemmaAdminstrationFeatureBase
{

    const GND_NR_FIELD_NAME = 'gndNummer';

    /**
     * @var FormInterface
     */
    private $addGndForm;

    /**
     * @var
     */
    private $addGndFormView;

    /**
     * @var string
     */
    private $errorMessage;

    /**
     * @var DdcRepository
     */
    private $ddcRepository;

    /**
     * @var ObjectRepository
     */
    private $gndDdcRepository;

    /**
     * @var ObjectManager
     */
    private $doctrineManager;

    /**
     * @var ObjectRepository
     */
    private $lemmaGndRepository;

    /** @var LoggerInterface */
    private $logger;

    public function __construct(LemmaAdministrationFeatureContext $context)
    {
        parent::__construct($context);

        $this->doctrineManager = $this->getBackendDoctrineManager();
        $this->ddcRepository = $this->doctrineManager->getRepository(DdcEntity::class);
        $this->gndDdcRepository = $this->doctrineManager->getRepository(GndDdcEntity::class);
        $this->lemmaGndRepository = $this->doctrineManager->getRepository(LemmaGndEntity::class);
        $this->logger = $context->getLogger();

        $this->errorMessage = null;

        $this->addGndForm = $this->createAddGndForm();
        $this->handleAddGndForm();
        $this->addGndFormView = $this->addGndForm->createView();
    }

    public function getAddGndFormView()
    {
        return $this->addGndFormView;
    }

    public function getErrorMessage()
    {
        return $this->errorMessage;
    }

    private function createAddGndForm()
    {
        return $this->getFormFactory()->createNamedBuilder('addGndForm', FormType::class)
            ->add(self::GND_NR_FIELD_NAME, TextType::class)
            ->getForm();
    }

    private function handleAddGndForm()
    {
        try
        {
            $this->addGndForm->handleRequest($this->getRequest());
            if ($this->addGndForm->isSubmitted() && $this->addGndForm->isValid())
            {
                $gndNummer = $this->addGndForm->getData()[self::GND_NR_FIELD_NAME];
                $dnbGndResult = DnbGndMarc21::retrieveGndAndDdcEntitiesByNid($gndNummer);
                if ($dnbGndResult)
                {
                    $this->getRedirectRequest()->shallRedirect = true;
                    $this->getRedirectRequest()->params['addGndSubmitted'] = $gndNummer;

                    $gndEntity = $this->processDnbGndResult($dnbGndResult);
                    $this->connectGndEntityToLemmaEntity($gndEntity);
                    $this->setStatus();
                }
                else
                {
                    $this->errorMessage = 'Kann GND Eintrag mit ID ' . $gndNummer . ' nicht finden.';
                }
            }
        }
        catch (ConnectionTimeoutException $e)
        {
            Log::error($this->logger, 'The DNB services are not available', $e);
            $this->errorMessage = 'Entschuldigung, der Service kann zur Zeit nicht genutzt werden. Es kann keine Verbindung zum Server der DNB aufgebaut werden. Probieren Sie es bitte zu einen späteren Zeitpunkt nochmal. Weitere Informationen finden Sie unter https://www.dnb.de.';
        }
    }

    private function connectGndEntityToLemmaEntity(GndEntity $gndEntity)
    {
        $lemmaEntity = $this->getLemmaEntity();
        $lemmaGndEntity = $this->lemmaGndRepository->findOneBy([
            'lemmaEntity' => $lemmaEntity,
            'gndEntity' => $gndEntity
        ]);
        if (!$lemmaGndEntity) {
            $lemmaGndEntity = new LemmaGndEntity();
            $lemmaGndEntity->setLemmaEntity($lemmaEntity);
            $lemmaGndEntity->setGndEntity($gndEntity);
            $this->doctrineManager->persist($lemmaGndEntity);
            $this->doctrineManager->flush();
        }
    }

    private function processDnbGndResult(DnbGndMarc21Result $result)
    {
        $gndRepo = $this->doctrineManager->getRepository(GndEntity::class);
        /* @var $gndEntity GndEntity */
        $gndEntity = $gndRepo->findOneBy(['nummer' => $result->gndEntity->getNummer()]);
        if (!$gndEntity) {
            $gndEntity = $result->gndEntity;
            $this->doctrineManager->persist($gndEntity);
        } else {
            $gndEntity->setSchlagwort($result->gndEntity->getSchlagwort());
        }
        $this->doctrineManager->flush();

        $this->processDnbDdcResult($result, $gndEntity);

        return $gndEntity;
    }

    private function processDnbDdcResult(DnbGndMarc21Result $result, GndEntity $gndEntity)
    {
        /* @var $resultDdcEntity DdcEntity */
        foreach ($result->ddcEntities as $resultDdcEntity) {
            $ddcEntity = $this->ddcRepository->findOneBy(['notation' => $resultDdcEntity->getNotation()]);
            if (!$ddcEntity) {
                $ddcEntity = $this->persistDdcEntity($resultDdcEntity);
            }
            $gndDdcEntity = $this->gndDdcRepository->findOneBy(['gndEntity' => $gndEntity, 'ddcEntity' => $ddcEntity]);
            if (!$gndDdcEntity) {
                $gndDdcEntity = new GndDdcEntity();
                $gndDdcEntity->setGndEntity($gndEntity);
                $gndDdcEntity->setDdcEntity($ddcEntity);
                $this->doctrineManager->persist($gndDdcEntity);
                $this->doctrineManager->flush();
            }
        }
    }

    private function persistDdcEntity(DdcEntity $ddcEntity)
    {
        $ddcEntity->setSchlagwort(WebDeweySearch::crawlDdcThema($ddcEntity->getNotation()));
        $ddcEntity->setWebdeweyIsChecked(true);
        $this->doctrineManager->persist($ddcEntity);

        $this->linkAndPersistAncestors($ddcEntity);

        $this->doctrineManager->flush();
        return $ddcEntity;
    }

    private function linkAndPersistAncestors(DdcEntity $ddcEntity)
    {
        $undiscoveredAncestorMayExist = true;
        while ($undiscoveredAncestorMayExist) {
            $isFoundInDatabase_outArg = null;
            $parent = $this->findOrCreateParent($ddcEntity, $isFoundInDatabase_outArg);
            $ddcEntity->setParent($parent);
            $ddcEntity = $parent;

            $undiscoveredAncestorMayExist = !$isFoundInDatabase_outArg && $parent !== null;
        }
    }

    private function findOrCreateParent(DdcEntity $ddc, &$isFoundInDatabase_outArg)
    {
        $parentNotation = self::parentDdcNotation($ddc->getNotation());
        while ($parentNotation !== null) {
            $parent = $this->ddcRepository->findOneBy(["notation" => $parentNotation]);
            if ($parent) {
                $isFoundInDatabase_outArg = true;
                return $parent;
            }

            $thema = WebDeweySearch::crawlDdcThema($parentNotation);
            if ($thema) {
                $parent = new DdcEntity();
                $parent->setNotation($parentNotation);
                $parent->setSchlagwort($thema);
                $parent->setWebdeweyIsChecked(true);
                $this->doctrineManager->persist($parent);

                $isFoundInDatabase_outArg = false;
                return $parent;
            }

            $parentNotation = self::parentDdcNotation($parentNotation);
        }
        return null;
    }

    private static function parentDdcNotation($notation)
    {
        if (strlen($notation) < 1) {
            throw new \InvalidArgumentException();
        }

        $currentNotation = $notation;
        do {
            $parentNotation = substr($currentNotation, 0, strlen($currentNotation) - 1);
            if (self::isValidDdcNotation($parentNotation)) {
                return $parentNotation;
            }
            $currentNotation = $parentNotation;
        } while (strlen($currentNotation) > 1);
        return null;
    }

    private static function isValidDdcNotation($notation)
    {
        // use https://regex101.com/ to test regular expression
        return preg_match(
                '/^(?:T[1-6]--[0-9]+)$|^(?:[0-9]{1,3})$|^[0-9][0-9][0-9]\.[0-9]+$|^(?:T3[A-C]--[0-9]+)$/',
                $notation
            ) === 1;
    }

    private function setStatus()
    {
        $lemmaEntity = $this->getLemmaEntity();
        if ($lemmaEntity->getLemmabearbeitungsstatusEntity()->getBezeichnung() != 'klar') {
            $this->getRedirectRequest()->params['statusCommentSubmitted'] = 1;
            $lemmaStatusRepo = $this->doctrineManager->getRepository(LemmabearbeitungsstatusEntity::class);
            /** @var LemmabearbeitungsstatusEntity $statusKlarEntity */
            $statusKlarEntity = $lemmaStatusRepo->findOneBy(['bezeichnung' => 'klar']);
            $lemmaEntity->setLemmabearbeitungsstatusEntity($statusKlarEntity);
            $this->doctrineManager->flush();
        }
    }
}
