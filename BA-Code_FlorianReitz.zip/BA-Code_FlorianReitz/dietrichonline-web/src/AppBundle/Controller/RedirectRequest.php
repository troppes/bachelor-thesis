<?php

namespace AppBundle\Controller;

class RedirectRequest
{
    /**
     * @var string
     */
    public $route;

    /**
     * @var array
     */
    public $params;

    /**
     * @var bool
     */
    public $shallRedirect = false;

    public function __construct($route = null, $params = array())
    {
        $this->route = $route;
        $this->params = $params;
    }

    /**
     * @return string|null
     */
    public function getRoute()
    {
        return $this->route;
    }

    /**
     * @param string $route
     * @return self
     */
    public function setRoute(string $route): self
    {
        $this->route = $route;

        return $this;
    }

    /**
     * @return array
     */
    public function getParams(): array
    {
        return $this->params;
    }

    /**
     * @param array $params
     * @return self
     */
    public function setParams(array $params): self
    {
        $this->params = $params;

        return $this;
    }

    /**
     * @param string $key
     * @param string $value
     * @return self
     */
    public function addParam(string $key, string $value): self
    {
        $this->params[$key] = $value;

        return $this;
    }

    /**
     * @return bool
     */
    public function getShallRedirect(): bool
    {
        return $this->shallRedirect;
    }

    /**
     * @param bool $shallRedirect
     * @return self
     */
    public function setShallRedirect(bool $shallRedirect): self
    {
        $this->shallRedirect = $shallRedirect;

        return $this;
    }
}