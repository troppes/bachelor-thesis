<?php
namespace AppBundle\Controller\Bookmarks;

use AppBundle\Entity\ArtikelEntity;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Controller\SimpleSiteController;


class BookmarksController extends SimpleSiteController {
  const BOOKMARKS_COOKIE_NAME = "bookmarks";
  
  /**
   * @Route("/bookmarks", name="bookmark_list")
   */
  public function showBookmarkList(Request $request) {
    $viewTemplate = 'UserSearchFrontend/Bookmarks/bookmarksPage.html.twig';    
        
    $doctrine = $this->getDoctrine();
    $repo = $doctrine->getRepository(ArtikelEntity::class);
    
    // Get all elements that are listed in the cookie (separated by comma)
    $bookmarkIDs = array();
    if (array_key_exists(self::BOOKMARKS_COOKIE_NAME, $_COOKIE)){
      $bookmarkIDs = explode(",", $_COOKIE[self::BOOKMARKS_COOKIE_NAME]);
    }
    
    // Find an article to each element, which should be an existing id. If not, it is simply ignored.
    $bookmarkedArticles = array();
    foreach ($bookmarkIDs as $id) {
      $foundArticle = $repo->find($id);
      if ($foundArticle != null)
        array_push($bookmarkedArticles, $foundArticle);
    }
    
    $viewParameters = [
      'bookmarkedArticles' => $bookmarkedArticles
    ];
    
    return $this->baseAction($viewTemplate, $viewParameters);
  }
}