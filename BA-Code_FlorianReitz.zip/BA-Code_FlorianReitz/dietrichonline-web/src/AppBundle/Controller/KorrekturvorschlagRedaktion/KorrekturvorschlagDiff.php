<?php
namespace AppBundle\Controller\KorrekturvorschlagRedaktion;

use AppBundle\Entity\KorrekturvorschlagEntity;

class KorrekturvorschlagDiff {
    public function __construct(KorrekturvorschlagEntity $korrekturvorschlagEntity) {
        $this->korrekturvorschlagEntity = $korrekturvorschlagEntity;
        
        $originalTitel = $korrekturvorschlagEntity->getArtikelEntity()->getTitel();
        $changedTitel = $korrekturvorschlagEntity->getTitel();
        
        $originalTitel = htmlspecialchars($originalTitel);
        $changedTitel = htmlspecialchars($changedTitel);
        
        $this->titelDiff = new CharDiff($originalTitel, $changedTitel);
        
        $originalAutor = $korrekturvorschlagEntity->getArtikelEntity()->getAutor();
        $changedAutor = $korrekturvorschlagEntity->getAutor();
        
        $originalAutor = htmlspecialchars($originalAutor);
        $changedAutor = htmlspecialchars($changedAutor);
        
        $this->autorDiff = new CharDiff($originalAutor, $changedAutor);
    }
    
    public function getKorrekturvorschlagEntity() {
        return $this->korrekturvorschlagEntity;
    }
    
    public function produceMarkedOriginalTitel($startMark, $endMark) {
        $this->titelDiff->setDeletedMarker($startMark, $endMark);
        return $this->titelDiff->produceMarkedOriginal();
    }
    
    public function produceMarkedCorrectedTitel($startMark, $endMark) {
        $this->titelDiff->setAddedMarker($startMark, $endMark);
        return $this->titelDiff->produceMarkedChanged();
    }
    
    public function produceMarkedOriginalAutor($startMark, $endMark) {
        $this->autorDiff->setDeletedMarker($startMark, $endMark);
        return $this->autorDiff->produceMarkedOriginal();
    }
    
    public function produceMarkedCorrectedAutor($startMark, $endMark) {
        $this->autorDiff->setAddedMarker($startMark, $endMark);
        return $this->autorDiff->produceMarkedChanged();
    }
    
    protected $korrekturvorschlagEntity;
    protected $titelDiff;
    protected $autorDiff;
}
