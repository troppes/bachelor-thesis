<?php
namespace AppBundle\Controller\KorrekturvorschlagRedaktion;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\KorrekturvorschlagEntity;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Feature\FeatureBase;

class BandUebersichtController extends Controller
{
    /**
     * @Route("/korrekturvorschlagRedaktion", name="korrektur_redaktion_banduebersicht")
     * @Route("/korrekturvorschlagRedaktion/banduebersicht", name="korrektur_redaktion_banduebersicht_long")
     */
    function banduebersicht(Request $request)
    {
        $krktrRepo = $this->getDoctrine()->getRepository(
          KorrekturvorschlagEntity::class,
          FeatureBase::DB_BACKEND
        );
        $bndSts = $krktrRepo->findBandStates();
        
        return $this->render(
            'KorrekturvorschlagRedaktion/banduebersicht.html.twig',
            ['bandStates' => $bndSts]
        );
    }
}

