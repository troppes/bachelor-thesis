<?php
namespace AppBundle\Controller\KorrekturvorschlagRedaktion;

use Eloquent\Lcs\LcsSolver;

class CharDiff {

    /**
     * CharDiff constructor.
     * @param string $original the original string
     * @param string $changed the changed string
     */
    public function __construct($original, $changed) {
        // Transform strings into arrays where each element is a character of the respective string.
        // The LcsSolver can only work with arrays, not strings.
        $this->org = preg_split('/(?!^)(?!$)/u', $original);
        $this->chgd = preg_split('/(?!^)(?!$)/u', $changed);
        $solver = new LcsSolver();
        $this->lcs = $solver->longestCommonSubsequence($this->org, $this->chgd);
    }

    /**
     * @param string $start prefix to mark a deleted sequence in the original string
     * @param string $end suffix to mark a deleted sequence in the original string
     */
    public function setDeletedMarker($start, $end) {
        $this->delStart = $start;
        $this->delEnd = $end;
    }

    /**
     * @param string $start prefix to mark an added sequence in the original string
     * @param string $end suffix to mark an added sequence in the original string
     */
    public function setAddedMarker($start, $end) {
        $this->addStart = $start;
        $this->addEnd = $end;
    }

    /**
     * @return string the original string with marked sequences, which were changed or deleted.
     */
    public function produceMarkedOriginal() {
        return $this->produceMarked($this->org, $this->delStart, $this->delEnd);
    }

    /**
     * @return string the changed string with marked sequences, which were changed or added.
     */
    public function produceMarkedChanged() {
        return $this->produceMarked($this->chgd, $this->addStart, $this->addEnd);
    }

    /**
     * Analyzes a sequence with the help of the LCS $this->rslt .
     *
     * If you try to understand its functionality, run the method through a debugger. The debugger may help you
     * understanding the problem and the algorithm.
     *
     * @param array $seq the sequence which will be analyzed
     * @param string $markStart $markStart a string which marks the *beginning* of a differential sequence
     * @param string $markEnd $markStart a string which marks the *end* of a differential sequence
     * @return string the same sequence $seq where differential partial sequences are marked with $markStart and $markEnd
     */
    private function produceMarked($seq, $markStart, $markEnd) {
        $mrkdStr = '';
        $isMarkingChange = false;

        // loop over every char of $seq
        for($seq_i = 0, $lcs_i = 0, $seq_len = count($seq), $lcs_len = count($this->lcs); $seq_i < $seq_len;) {
            // check if all LCS chars have been matched. If not try to match.
            if ($lcs_i < $lcs_len && $seq[$seq_i] === $this->lcs[$lcs_i]) {
                // If-constraint asserted: there are unmatched LCS chars (because $lcs_i < count($this->>rslt))
                // and the current char from $seq is the same as the current char from $lcs.
                // Because of this fact, the current char from $seq was not changed.

                if ($isMarkingChange) {
                    // If-constraint asserted: We were marking a change.
                    // Because we know from the constraint above, that the current char from $seq was not changed,
                    // we append the $markEnd to our result $mrkdStr and are no longer marking a change.
                    $mrkdStr .= $markEnd;
                    $isMarkingChange = false;
                }
                // matched the current char from $seq against the current char of $lcs,
                // so jump to next char index of $lcs
                ++$lcs_i;
            } else if (!$isMarkingChange) {
                // Else-constraint asserted: all LCS chars have been matched
                // or the current $lcs char cannot be matched against the current $seq char.
                // Because of this fact, we know that the current char from $seq was changed or added.
                // If-constraint asserted: we are currently not marking a change.
                // Because we discovered a change, we must append $markStart
                // and remember via $isMarkingChange
                // that we are considering changes from now on until we find a match again.
                $mrkdStr .= $markStart;
                $isMarkingChange = true;
            }
            // always append char of given $seq and increment $seq index
            $mrkdStr .= $seq[$seq_i];
            ++$seq_i;
        }

        if ($isMarkingChange) {
            // End-of-loop-constraint asserted: we analysed every char from $seq.
            // If-constraint asserted: we are in change marking state,
            // so we must append the $markEnd string to match $markStart syntactically.
            $mrkdStr .= $markEnd;
        }

        return $mrkdStr;
    }

    /**
     * @var array the original sequence
     */
    private $org;

    /**
     * @var array the changed sequence
     */
    private $chgd;

    /**
     * @var array the longest common subsequence of $org and $chgd
     */
    private $lcs;

    /**
     * @var string used to mark the *start* of a deleted sequence in $org
     */
    private $delStart = '(';

    /**
     * @var string used to mark the *end* of a deleted sequence in $org
     */
    private $delEnd = ')';

    /**
     * @var string used to mark the *start* of an added sequence in $chgd
     */
    private $addStart = '[';

    /**
     * @var string used to mark the *end* of an added sequence in $chgd
     */
    private $addEnd = ']';
}
