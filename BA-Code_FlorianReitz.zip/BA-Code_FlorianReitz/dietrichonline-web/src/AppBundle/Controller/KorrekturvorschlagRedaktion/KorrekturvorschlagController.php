<?php
namespace AppBundle\Controller\KorrekturvorschlagRedaktion;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\KorrekturvorschlagEntity;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Repository\KorrekturVorschlagRepository;
use AppBundle\Feature\KorrekturvorschlagRedaktion\StatusFeature;
use AppBundle\Feature\FeatureContext;
use AppBundle\Controller\RedirectRequest;
use AppBundle\Feature\KorrekturvorschlagRedaktion\ArtikelUrlFeature;
use AppBundle\Entity\ArtikelUrlEntity;
use AppBundle\Feature\FeatureBase;

class KorrekturvorschlagController extends Controller {
    const KORREKTURVORSCHLAG_ROUTE = 'korrektur_redaktion_detail';
    
    /**
     * @Route("/korrekturvorschlagRedaktion/korrekturvorschlag/{id}/filter_next_prev/{filter_next_prev}", name="korrektur_redaktion_detail")
     */
    function detail(Request $request, $id, $filter_next_prev) {
        /* @var $korrekturRepo KorrekturVorschlagRepository */
        $korrekturRepo = $this->getDoctrine()->getRepository(
          KorrekturvorschlagEntity::class,
          FeatureBase::DB_BACKEND
        );
        /* @var $korrekturvorschlag KorrekturvorschlagEntity */
        $korrekturvorschlag = $korrekturRepo->find($id);
        $korrekturvorschlagDiff = new KorrekturvorschlagDiff($korrekturvorschlag);
        
        $redirectRequest = new RedirectRequest();
        $redirectRequest->route = self::KORREKTURVORSCHLAG_ROUTE;
        $redirectRequest->params = [
            'id' => $id,
            'filter_next_prev' => $filter_next_prev
        ];

        /* @var $formFactory FormFactory */
        $formFactory = $this->get('form.factory');
        $featureContext = new FeatureContext($request, $this->getDoctrine(), $formFactory, $redirectRequest);
        
        $statusFeature = new StatusFeature($korrekturvorschlag, $featureContext);
        
        $urlFeature = new ArtikelUrlFeature($korrekturvorschlag, $featureContext);
        
        if ($redirectRequest->shallRedirect) {
            return $this->redirectToRoute($redirectRequest->route, $redirectRequest->params);
        }
        
        return $this->render(
            'KorrekturvorschlagRedaktion/korrekturvorschlag.html.twig',
            [
                'korrekturvorschlagDiff' => $korrekturvorschlagDiff,
                'statusFeature' => $statusFeature,
                'korrekturvorschlagRepository' => $korrekturRepo,
                'filter_next_prev' => $filter_next_prev,
                'urlFeature' => $urlFeature,
                'artikelUrlRepo' => $this->getDoctrine()->getRepository(
                  ArtikelUrlEntity::class,
                  FeatureBase::DB_BACKEND
                )
            ]
        );
    }
}
