<?php
namespace AppBundle\Controller\KorrekturvorschlagRedaktion;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\KorrekturvorschlagEntity;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Repository\KorrekturVorschlagRepository;
use AppBundle\Entity\KorrekturvorschlagstatusEntity;
use AppBundle\Feature\FeatureBase;

class KorrekturvorschlagListController extends Controller {
    /**
     * @Route("/korrekturvorschlagRedaktion/liste_band/{bandkuerzel}/filter/{statusFilter}", name="korrektur_redaktion_list")
     */
    function list(Request $request, $bandkuerzel, $statusFilter) {
        $doctrineManager = $this->getDoctrine()->getManager(FeatureBase::DB_BACKEND);
        /* @var $korrekturRepo KorrekturVorschlagRepository */
        $korrekturRepo = $doctrineManager->getRepository(KorrekturvorschlagEntity::class);
        $korrekturList = $korrekturRepo->findByBandkuerzelAndFilter($bandkuerzel, $statusFilter);
        
        $statusList = $doctrineManager->getRepository(KorrekturvorschlagstatusEntity::class)->findAll();
        
        $korrekturvorschlagDiffList = array_map(
            function($korrekturvorschlagEntity) { return new KorrekturvorschlagDiff($korrekturvorschlagEntity); }, 
            $korrekturList
        );
        
        return $this->render(
            'KorrekturvorschlagRedaktion/list.html.twig',
            [
                'korrekturvorschlagDiffList' => $korrekturvorschlagDiffList,
                'bandkuerzel' => $bandkuerzel,
                'statusFilter' => $statusFilter,
                'statusList' => $statusList
            ]
        );
    }
}
