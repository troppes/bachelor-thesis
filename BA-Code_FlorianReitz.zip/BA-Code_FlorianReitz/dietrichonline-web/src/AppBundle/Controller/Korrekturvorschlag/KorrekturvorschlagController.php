<?php
namespace AppBundle\Controller\Korrekturvorschlag;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Entity\ArtikelEntity;
use AppBundle\Entity\KorrektorEntity;
use AppBundle\Entity\KorrekturvorschlagEntity;
use AppBundle\Entity\KorrekturvorschlagstatusEntity;
use AppBundle\Feature\Korrekturvorschlag\KorrekturvorschlagType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Cookie;
use AppBundle\Feature\Korrekturvorschlag\DankesMailFeature;

class KorrekturvorschlagController extends Controller {
    
    /**
     * @Route("/correction_proposal_form/{artikelId}", name="correction_proposal_form")
     */
    function correctionProposal(Request $request, $artikelId) {
        $doctrine = $this->getDoctrine();
        $korrektorRepo = $doctrine->getRepository(KorrektorEntity::class);
        
        $artikelRepo = $doctrine->getRepository(ArtikelEntity::class);
        /* @var $artikel ArtikelEntity */
        $artikel = $artikelRepo->find($artikelId);
        if (is_null($artikel)) {
            throw $this->createNotFoundException('Es existiert kein Artikel mit id '.$artikelId.'.');
        }
        
        $statusNeu = $doctrine->getRepository(KorrekturvorschlagstatusEntity::class)->findOneByBezeichnung('neu');
        if (is_null($statusNeu)) {
            throw new \Exception('Cannot find Status "neu". Is the database initialized properly?');
        }
        
        $korrektor = null;
        $korrektorEmail = $request->cookies->get('korrektorEmail', null);
        if ($korrektorEmail !== null) {
            $korrektor = $korrektorRepo->findOneByEmail($korrektorEmail);
            if($korrektor !== null) {
                // We just want the data of the object for default form initialization.
                // The object itself shall not automatically be updated
                $doctrine->getManager()->detach($korrektor);
            }
        }
        if ($korrektor === null) {
            $korrektor = new KorrektorEntity();
        }
        
        $korrekturvorschlag = new KorrekturvorschlagEntity();
        $korrekturvorschlag->setArtikelEntity($artikel)
        ->setTitel($artikel->getTitel())
        ->setAutor($artikel->getAutor())
        ->setKorrekturvorschlagstatusEntity($statusNeu)
        ->setKorrektorEntity($korrektor);
        $form = $this->createForm(KorrekturvorschlagType::class, $korrekturvorschlag);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $korrektorEmail = $korrekturvorschlag->getKorrektorEntity()->getEmail();
            if ($korrektorEmail === null) {
                $korrekturvorschlag->setKorrektorEntity(null);
            } else {
                /* @var $korrektor KorrektorEntity */
                $korrektor = $korrektorRepo->findOneBy(['email' => $korrektorEmail]);
                if ($korrektor !== null) {
                    $korrektor->update($korrekturvorschlag->getKorrektorEntity());
                    $korrekturvorschlag->setKorrektorEntity($korrektor);
                }
            }

            $korrekturvorschlag->setTimestamp(time());
            
            $doctrine->getManager()->persist($korrekturvorschlag);
            $doctrine->getManager()->flush();
            return $this->redirectToRoute('correction_proposal_submission_success', ['korrektorEmail' => $korrektorEmail]);
        }
        
        return $this->render('Korrekturvorschlag/korrekturvorschlag.html.twig', [
            'artikel' => $artikel,
            'form' => $form->createView()
        ]);
    }

    /**
     * @Route("/correction_proposal_submission_success/{korrektorEmail}", name="correction_proposal_submission_success")
     */
    function submissionSuccess(Request $request, $korrektorEmail=null) {
        $response = new Response();
        $currentTime = time();
        $dayInSec = 24*60*60;
        $yearInSec = 365 * $dayInSec;

        $korrektor = $this->getDoctrine()->getRepository(KorrektorEntity::class)->findOneBy(['email' => $korrektorEmail]);
        $lastContribution = $request->cookies->get('lastContribution', 0);
        $cookieLifetime = $currentTime + $dayInSec;
        $response->headers->setCookie(new Cookie('lastContribution', $currentTime, $cookieLifetime));
        if($korrektor && $currentTime > ($lastContribution + $dayInSec)) {
            DankesMailFeature::send($korrektor, $this->get('mailer'), $this->get('twig'));
        }
        
        $cookieLifetime = $currentTime + 10 * $yearInSec;
        $response->headers->setCookie(new Cookie('korrektorEmail', $korrektorEmail, $cookieLifetime));
        return $this->render('Korrekturvorschlag/success.html.twig', [], $response);
    }
}
