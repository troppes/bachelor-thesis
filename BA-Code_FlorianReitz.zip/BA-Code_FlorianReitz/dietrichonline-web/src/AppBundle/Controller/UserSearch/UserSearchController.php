<?php

namespace AppBundle\Controller\UserSearch;

use Exception;
use InvalidArgumentException;
use PagerBundle\ElasticSearchPager;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Form\UserSearchFrontend\UserSearchType;
use AppBundle\NativeSql\UserSearchItem;
use AppBundle\Entity\ArtikelEntity;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use AppBundle\Repository\ArtikelRepository;
use AppBundle\Entity\BandEntity;
use Symfony\Component\HttpFoundation\Response;

class UserSearchController
    extends Controller
{

    /**
     * @var UserSearchItem[]
     */
    private $userSearchItemArray;

    /**
     * @param Request $request
     *
     * @Route("/suche", name="user_search")
     *
     * @return Response
     *
     * @throws Exception
     */
    public function suche(Request $request)
    {
        $queryPager                       = null;
        $lowerQuickNavigationPageNumbers  = null;
        $higherQuickNavigationPageNumbers = null;
        $searchResultPageNumber           = null;
        $displaySearchResults             = null;
        $countSearchResults               = null;
        $bestAuthors                      = null;
        $searchUrlQuery                   = null;

        $searchResultsPerPage = 30;

        $doctrine              = $this->getDoctrine();
        $defaultUserSearchData = [];

        /* @var $formFactory FormFactory */
        $formFactory          = $this->get('form.factory');
        $simpleUserSearchForm = $formFactory->createNamedBuilder(
            'simpleUserSearch',
            FormType::class,
            null,
            [
                'method' => 'GET',
                'csrf_protection' => false,
            ]
        )
            ->add('begriff', TextType::class)
            ->getForm();
        $simpleUserSearchForm->handleRequest($request);

        if ($simpleUserSearchForm->isSubmitted() && $simpleUserSearchForm->isValid()) {
            $suchBegriff                 = $simpleUserSearchForm->getData()['begriff'];
            $this->userSearchItemArray   = [
                new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_FULL_SEARCH, $suchBegriff),
            ];
            $defaultUserSearchData['k1'] = UserSearchItem::TYPE_FULL_SEARCH;
            $defaultUserSearchData['b1'] = $suchBegriff;
        }

        $searchForm = $this->createForm(
            UserSearchType::class,
            $defaultUserSearchData,
            [
                'method' => 'GET',
                'csrf_protection' => false,
            ]
        );
        $searchForm->handleRequest($request);

        if ($searchForm->isSubmitted() && $searchForm->isValid()) {
            $searchFormData            = $searchForm->getData();
            $this->userSearchItemArray = [];
            for ($i = 1; array_key_exists('b'.$i, $searchFormData); ++$i) {
                $suchBegriff = $searchFormData['b'.$i];
                if ($suchBegriff !== null) {
                    $junktor       = isset($searchFormData['j'.($i - 1)]) ? $searchFormData['j'.($i - 1)] : UserSearchItem::JUNKTOR_NO;
                    $suchKategorie = $searchFormData['k'.$i];
                    try {
                        $userSearchItem              = new UserSearchItem($junktor, $suchKategorie, $suchBegriff);
                        $this->userSearchItemArray[] = $userSearchItem;
                    } catch (InvalidArgumentException $e) {
                        throw new Exception('Übertragene Daten können leider nicht verarbeitet werden.');
                    }
                }
            }
            if ($searchFormData['vonJahr']) {
                $this->userSearchItemArray[] = new UserSearchItem(
                    UserSearchItem::JUNKTOR_AND,
                    UserSearchItem::TYPE_VON_JAHR,
                    $searchFormData['vonJahr']
                );
            }
            if ($searchFormData['bisJahr']) {
                $this->userSearchItemArray[] = new UserSearchItem(
                    UserSearchItem::JUNKTOR_AND,
                    UserSearchItem::TYPE_BIS_JAHR,
                    $searchFormData['bisJahr']
                );
            }

            $this->normalizeSearchItems();
        }

        if ($this->userSearchItemArray !== null && count($this->userSearchItemArray) > 0) {
            /* @var $repo ArtikelRepository */
            $repo = $doctrine->getRepository(ArtikelEntity::class);
            $repo->setLogger($this->get('logger'));


            $result = $repo->findUserSearchResult(
                $this->userSearchItemArray,
                ($request->query->getInt('pageNumber', 1) * 30 - 30)
            );

            $queryPager         = new ElasticSearchPager($result['count'], $searchResultsPerPage);
            $countSearchResults = $result['count'];

            $searchResultPageNumber = $request->query->getInt('pageNumber', 1);
            $displaySearchResults   = $result['results'];
            $bestAuthors            = $result['bestAuthors'];

            $lowerQuickNavigationPageNumbers  = $queryPager->getLowerQuickNavigationPageNumbers(
                $searchResultPageNumber
            );
            $higherQuickNavigationPageNumbers = $queryPager->getHigherQuickNavigationPageNumbers(
                $searchResultPageNumber
            );
        }

        $httpGetQueryWithoutPageNr = preg_replace('/&?pageNumber=\d+&?/', '', $request->getQueryString());

        $viewTemplate   = 'UserSearchFrontend/userSearchFrontend.html.twig';
        $viewParameters = [
            'simpleSearchForm' => $simpleUserSearchForm->createView(),
            'searchForm' => $searchForm->createView(),
            'queryPager' => $queryPager,
            'displaySearchResults' => $displaySearchResults,
            'searchResultPageNumber' => $searchResultPageNumber,
            'searchResultsPerPage' => $searchResultsPerPage,
            'lowerQuickNavigationPageNumbers' => $lowerQuickNavigationPageNumbers,
            'higherQuickNavigationPageNumbers' => $higherQuickNavigationPageNumbers,
            'countSearchResults' => $countSearchResults,
            'httpGetQueryWithoutPageNr' => $httpGetQueryWithoutPageNr,
            'bestAuthors' => $bestAuthors,
            'bandRepository' => $doctrine->getRepository(BandEntity::class),
        ];

        return $this->render($viewTemplate, $viewParameters);
    }

    /**
     * Normalizes the order of the UserSearchItem junktors.
     * <p>
     * If we have multiple search categories but the first one is empty,
     * the search will break, because all items (til 2nd) have an AND junktor.
     * So we must guarantee that the first item has <code>UserSearchItem::NO_JUNKTOR</code> set!
     * -> Because, first WHERE clause in SQL have not to start with AND.
     */
    private function normalizeSearchItems()
    {
        if (count($this->userSearchItemArray) > 0) {
            /** @var UserSearchItem $usi */
            $usi = $this->userSearchItemArray[0];
            $usi->setJunktor(UserSearchItem::JUNKTOR_NO);
        }
    }
}
