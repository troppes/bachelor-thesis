<?php

namespace AppBundle\Controller\UserSearch;

use AppBundle\Entity\ArtikelEntity;
use AppBundle\Repository\ArtikelRepository;
use AppBundle\Util\Log;
use InvalidArgumentException;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\NativeSql\UserSearchItem;
use AppBundle\Repository\AutocompletableRepository;

/**
 * @author Florian Reitz <reitz@uni-trier.de>
 * @author Milan Rüll (milanruell@gmail.com)
 * @author Martin Kock <kock@uni-trier.de>
 */
class SearchAutocompletionController
    extends Controller
{
    const MAX_MATCHES_COUNT = 10;

    const NO_MATCHES_FOUND_TEXT = [
        'title' => '',
        'description' => 'Es konnten keine passenden Einträge ermittelt werden.',
    ];

    const NO_SUGGESTIONS_AVAILABLE_TEXT = [
        'title' => '',
        'description' => 'Zur gewählten Kategorie sind keine Vorschläge verfügbar.',
    ];

    const INTERNAL_GET_SUGGESTIONS_LIST_THROWS_ERROR_TEXT = [
        'title' => '',
        'description' =>
            'Die Vorschau-Funktion steht zur Zeit nicht zur Verfügung. Durch das Anhängen von * an den Suchbegriff können Sie weitere Vorschläge erhalten.',
    ];

    /**
     * Associates the category indices with table columns, where autocomplete suggestions are retrieved from.
     * CategoryIndex => [EntityName, ColumnName1, ColumnName2]
     */
    const AUTOCOMPLETE_COLUMNS = [
        UserSearchItem::TYPE_LEMMA => 'lemma_bezeichnung.suggest',
        UserSearchItem::TYPE_GND => 'gnd_entries.gnd_schlagwort.suggest',
        UserSearchItem::TYPE_AUTOR => 'artikel_autor.suggest',
        UserSearchItem::TYPE_SIGLE => 'artikel_sigle.suggest',
        UserSearchItem::TYPE_ARTIKEL => 'artikel_titel_suggest',
        UserSearchItem::TYPE_NORMLITERATURREFERENZ => 'kvk_zdb_suggest',
        UserSearchItem::TYPE_FULL_SEARCH => 'full_search_suggest',
    ];


    /**
     * @Route("/getsuggestions")
     */
    public function getAutocompleteSuggestions(Request $request)
    {

        $typedQuery    = $request->query->get(AutocompletableRepository::SEARCH_TERM_PARAM_KEY);
        $doQuicksearch = $request->query->get('quicksearch');
        $categoryIndex = intval($request->query->get('category'));

        if (!$doQuicksearch) {
            if (array_key_exists($categoryIndex, self::AUTOCOMPLETE_COLUMNS)) {
                $jsonArray = self::createResponseArray($typedQuery, $categoryIndex, self::MAX_MATCHES_COUNT);
            } else /* if array key doesn't exist */ {
                $jsonArray = [self::NO_SUGGESTIONS_AVAILABLE_TEXT];
            }
        } else /* if quicksearch */ {
            $jsonArray = self::createResponseArray($typedQuery, UserSearchItem::TYPE_FULL_SEARCH, self::MAX_MATCHES_COUNT);
        }

        return $this->json(['results' => $jsonArray]);
    }

    private function createResponseArray($typedQuery, $categoryIndex, $matchesCount)
    {
        $jsonArray = [];

        /* @var $repo ArtikelRepository */
        $repo = $this->getDoctrine()->getRepository(ArtikelEntity::class);

        try {
            $results = $repo->getSuggestionsList($typedQuery, $categoryIndex, $matchesCount);

            if (empty(count($results))) {
                $jsonArray = [self::NO_MATCHES_FOUND_TEXT];
            } else {
                foreach ($results as $result) {
                    $jsonArray[] = ['title' => $result['text'], 'description' => ''];
                }
            }
        } catch (InvalidArgumentException $e) {
            Log::error($this->get('logger'), "The UserSearchItem wasn't correctly called.", $e);
            $jsonArray = [self::INTERNAL_GET_SUGGESTIONS_LIST_THROWS_ERROR_TEXT];
        }

        return $jsonArray;
    }
}
