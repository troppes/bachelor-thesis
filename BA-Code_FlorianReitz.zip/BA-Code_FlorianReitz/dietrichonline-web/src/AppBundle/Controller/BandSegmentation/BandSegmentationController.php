<?php

namespace AppBundle\Controller\BandSegmentation;

use AppBundle\Controller\RedirectRequest;
use AppBundle\Entity\SegmentationsFehlerEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Feature\FeatureContext;
use AppBundle\Feature\BandSegmentation\GotoEid;
use AppBundle\Repository\BandSegmentationRepository;
use PagerBundle\DoctrineQueryPager;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class BandSegmentationController
    extends Controller
{

    const DEFAULT_ITEMS_PER_PAGE = 100;
    const DEFAULT_PAGE_INDEX     = 1;


    /**
     * Shows the list of errors
     *
     * @param Request $request
     * @param string $bandkuerzel
     *
     * @return RedirectResponse|Response
     *
     * @Route("/fehler_liste/band/{bandkuerzel}", name="band_segmentation")
     */
    public function listeTextFehlerAction(Request $request, string $bandkuerzel)
    {

        $itemsPerPage = self::DEFAULT_ITEMS_PER_PAGE;

        $pageNumber = $request->get('pageNumber', '1');
        $filter     = $request->get('filter', 'NONE');
        $noPagination = $request->get('noPagination') !== null;

        if ($noPagination) {
            $itemsPerPage = PHP_INT_MAX;
        }

        $doctrineManager = $this->getDoctrine()->getManager(FeatureBase::DB_BACKEND);

        /* @var $korrekturRepo BandSegmentationRepository */
        $errorListRepo = $doctrineManager->getRepository(SegmentationsFehlerEntity::class);


        if ($filter === 'NONE') {
            $query = $errorListRepo->getAllErrorsQueryByBand($bandkuerzel);
        } else {
            $query = $errorListRepo->getAllErrorsQueryByBandWithFilter($filter, $bandkuerzel);
        }
        $pager = new DoctrineQueryPager($query, $itemsPerPage, $fetchJoinCollection = false);

        $redirectRequest                       = new RedirectRequest();
        $redirectRequest->route                = 'fehler_liste';
        $redirectRequest->params['pageNumber'] = $pageNumber;

        $doctrine = $this->getDoctrine();

        /* @var $formFactory FormFactory */
        $formFactory = $this->get('form.factory');
        $logger      = $this->get('logger');

        $context = new FeatureContext(
            $request,
            $doctrine,
            $formFactory,
            $redirectRequest,
            $logger
        );


        $gotoEidFeature = new GotoEid($context);

        $errorsForPage                    = $pager->getPageByNumber($pageNumber);
        $errorListCount                   = $pager->countItems();
        $numberOfPages                    = $pager->countPages();
        $lowerQuickNavigationPageNumbers  = $pager->getLowerQuickNavigationPageNumbers($pageNumber);
        $higherQuickNavigationPageNumbers = $pager->getHigherQuickNavigationPageNumbers($pageNumber);

        if ($redirectRequest->shallRedirect) {
            return $this->redirectToRoute($redirectRequest->route, $redirectRequest->params);
        }

        return $this->render(
            ':BandSegmentation:bandSegmentation.html.twig',
            [
                'bandkuerzel' => $bandkuerzel,
                'pageNumber' => $pageNumber,
                'noPagination' => $noPagination,
                'errorList' => $errorsForPage,
                'errorCounter' => $errorListCount,
                'numberOfPages' => $numberOfPages,
                'lowerQuickNavigationPageNumbers' => $lowerQuickNavigationPageNumbers,
                'higherQuickNavigationPageNumbers' => $higherQuickNavigationPageNumbers,
                'gotoEidFeature' => $gotoEidFeature,
            ]
        );
    }

}
