<?php

namespace AppBundle\Controller\BandSegmentation;

use AppBundle\Entity\SegmentationsFehlerEntity;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class BandSegmentationOverviewController
    extends Controller
{
    /**
     * @Route("/eier_web", name="band_segmentation_eier")
     * @Route("/fehler_liste", name="band_segmentation_overview")
     * @Route("/textfehlerliste", name="band_segmentation_long")
     */
    public function dietrichBandUebersichtAction()
    {
        $doctrineManager = $this->getDoctrine()->getManager('backend');

        $textErrorRepo    = $doctrineManager->getRepository(SegmentationsFehlerEntity::class);
        $baendeWithErrors = $textErrorRepo->getBandWithErrors();

        return $this->render(
            ':BandSegmentation:bandSegmentationOverview.html.twig',
            [
                'baendeWithErrors' => $baendeWithErrors,
            ]
        );
    }
}
