<?php

namespace AppBundle\Controller\Literaturreferenzadministration;

use AppBundle\Controller\RedirectRequest;
use AppBundle\Feature\LiteraturreferenzAdministration\GoToSigle\GoToSigleFeature;
use AppBundle\Feature\FeatureContext;
use AppBundle\Feature\LiteraturreferenzAdministration\NewDietrichLitrefFeature;
use AppBundle\Repository\DietrichliteraturreferenzRepository;
use AppBundle\Util\Preconditions;
use RuntimeException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use PagerBundle\DoctrineQueryPager;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class LiteraturreferenzListeController extends Controller
{
    /** @var int */
    const DEFAULT_ITEMS_PER_PAGE = 10;
    /**
     * High count to provide a list of all items on one page.
     *
     * @var int
     */
    const LIST_ALL_ITEMS_PER_PAGE = 1000000000;

    const DEFAULT_PAGE_INDEX = 1;

    private function getDoctrineManager()
    {
        return $this->getDoctrine()->getManager('backend');
    }

    const ROUTE_LIST_ALL_LITERATURREFERENZEN = 'liste_literaturreferenzen';

    private function getDietrichLitrefRepo() : DietrichliteraturreferenzRepository
    {
        return $this->getDoctrineManager()->getRepository(DietrichliteraturreferenzEntity::class);
    }

    /**
     * Lists all DietrichLitrefs of Band identified by $bandkuerzel. List is paginated.
     *
     * @Route("/band/{bandkuerzel}/seite/{pageNumber}", name="liste_literaturreferenzen")
     *
     * Legacy Links to support old saved Links
     *
     * @Route("/alle_literaturreferenzen/band/{bandkuerzel}/seite/{pageNumber}", defaults={"filter"=DietrichliteraturreferenzRepository::STATUS_FILTER_ALL_PAGED}, name="liste_alle_literaturreferenzen")
     * @Route("/alle_literaturreferenzen_auf_einer_seite/band/{bandkuerzel}",defaults={"pageNumber"="1", "filter"=DietrichliteraturreferenzRepository::STATUS_FILTER_ALL},name="liste_alle_literaturreferenzen_auf_einer_seite")
     * @Route("/neue_literaturreferenzen/band/{bandkuerzel}/seite/{pageNumber}", defaults={"filter"=DietrichliteraturreferenzRepository::STATUS_FILTER_NEW}, name="liste_neue_literaturreferenzen")
     * @Route("/unklare_literaturreferenzen/band/{bandkuerzel}/seite/{pageNumber}", defaults={"filter"=DietrichliteraturreferenzRepository::STATUS_FILTER_UNCLEAR}, name="liste_unklare_literaturreferenzen")
     *
     * @param Request $request
     * @param string $bandkuerzel
     * @param string $pageNumber for pagination
     * @return RedirectResponse|Response
     */
    public function listeLiteraturreferenzenAction(Request $request, string $bandkuerzel, string $pageNumber)
    {
        $filter = $request->get('filter', 'all_paged');

        if($filter === DietrichliteraturreferenzRepository::STATUS_FILTER_NEW){
            $query = $this->getDietrichLitrefRepo()->getNewSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel);
        }else if($filter === DietrichliteraturreferenzRepository::STATUS_FILTER_UNCLEAR){
            $query = $this->getDietrichLitrefRepo()->getUnclearSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel);
        }else{
            $query = $this->getDietrichLitrefRepo()->getAllSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel);
        }

        $listRouteName = 'liste_literaturreferenzen';
        $templatePath = 'listeLiteraturreferenzen.html.twig';
        $maximumItemsPerPage = self::DEFAULT_ITEMS_PER_PAGE;

        Preconditions::notEmpty($templatePath, 'templatePath');
        Preconditions::notEmpty($listRouteName, 'listRouteName');
        Preconditions::notEmpty($bandkuerzel, 'bandkuerzel');
        Preconditions::notEmpty($pageNumber, 'pageNumber');
        Preconditions::isGreaterThan($maximumItemsPerPage, 'maxItemsPerPage');

        /* @var $formFactory FormFactory */
        $formFactory = $this->get('form.factory');

        $redirectRequest = new RedirectRequest();
        $featureContext = new FeatureContext($request, $this->getDoctrine(), $formFactory, $redirectRequest);

        $viewParameters = [];

        $pageResultsCount = $maximumItemsPerPage;

        if($filter === DietrichliteraturreferenzRepository::STATUS_FILTER_ALL){
            $pageNumber = 1;
            $pageResultsCount = self::LIST_ALL_ITEMS_PER_PAGE;
        }
        $pager = new DoctrineQueryPager($query, $pageResultsCount, $fetchJoinCollection = false);

        $displayDietrichliteraturreferenzen = $pager->getPageByNumber($pageNumber);
        $countDietrichliteraturreferenzen = $pager->countItems();
        $numberOfPages = $pager->countPages();
        $lowerQuickNavigationPageNumbers = $pager->getLowerQuickNavigationPageNumbers($pageNumber);
        $higherQuickNavigationPageNumbers = $pager->getHigherQuickNavigationPageNumbers($pageNumber);

        /** @var BandEntity $bandEntity */
        $bandEntity = $this->getDoctrineManager()->getRepository(BandEntity::class)
            ->findOneBy(['bandkuerzel' => $bandkuerzel]);

        if ($bandEntity === null)
        {
            throw new RuntimeException('Cannot find BandEntity by bandkuerzel "' . $bandkuerzel . '".');
        }

        $viewParameters['goToSigleFeature'] = new GoToSigleFeature($featureContext, $bandEntity);
        $viewParameters['newDietrichLitrefFeature'] = new NewDietrichLitrefFeature($featureContext, $bandEntity);

        if ($redirectRequest->shallRedirect)
        {
            return $this->redirectToRoute($redirectRequest->route, $redirectRequest->params);
        }

        $viewTemplate = 'Literaturreferenzadministration/' . $templatePath;
        $viewParameters = array_merge($viewParameters, [
            'bandkuerzel' => $bandkuerzel,
            'dietrichliteraturreferenzen' => $displayDietrichliteraturreferenzen,
            'countDietrichliteraturreferenzen' => $countDietrichliteraturreferenzen,
            'numberOfPages' => $numberOfPages,
            'pageNumber' => $pageNumber,
            'lowerQuickNavigationPageNumbers' => $lowerQuickNavigationPageNumbers,
            'higherQuickNavigationPageNumbers' => $higherQuickNavigationPageNumbers,
            'listRouteName' => $listRouteName,
            'filter' => $filter
        ]);

        return $this->render($viewTemplate, $viewParameters);
    }
}
