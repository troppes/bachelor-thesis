<?php
namespace AppBundle\Controller\Literaturreferenzadministration;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;

class DietrichBandUebersichtController extends Controller
{
	/**
     * @Route("/", name="dietrichbanduebersicht")
	 * @Route("/dietrichbanduebersicht", name="dietrichbanduebersicht_long")
	 */
	public function dietrichBandUebersichtAction()
    {
	  $doctrineManager = $this->getDoctrine()->getManager('backend');

		/* @var $bandRepository \AppBundle\Repository\BandRepository */
		$bandRepository = $doctrineManager->getRepository(BandEntity::class);
		$baende = $bandRepository->findAll();
		
		$dietrichLitrefRepo = $doctrineManager->getRepository(DietrichliteraturreferenzEntity::class);
		$bandStates = $dietrichLitrefRepo->findBandStates();
		return $this->render(
			'Literaturreferenzadministration/dietrichbanduebersicht.html.twig',
			array(
				'baende' => $baende,
				'bandStates' => $bandStates
			)
		);
	}
}