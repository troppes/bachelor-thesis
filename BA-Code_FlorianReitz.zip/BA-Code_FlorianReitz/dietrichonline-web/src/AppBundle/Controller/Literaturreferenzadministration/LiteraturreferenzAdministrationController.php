<?php

namespace AppBundle\Controller\Literaturreferenzadministration;

use AppBundle\Feature\LiteraturreferenzAdministration\AddZdbLitrefFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\ArticleLinkFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\BackToListFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\LinkToZdbKatalogFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\SieheSigleFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\AddKvkLitrefFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\DeleteDietrichLitrefFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\EditDietLitNormLitFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\EditDietrichLitrefFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\GoToSigle\GoToSigleFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\LitrefAdminFeatureContext;
use AppBundle\Feature\LiteraturreferenzAdministration\NewDietrichLitrefFeature;
use AppBundle\Feature\LiteraturreferenzAdministration\NextPrevDietLitrefFeature;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use AppBundle\Controller\RedirectRequest;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use \Psr\Log\LoggerInterface;

class LiteraturreferenzAdministrationController extends Controller
{
    const LITERATURREFERENZADMINISTRATION_ROUTE = 'literaturreferenzadministration';

    /**
     * constant for route parameter name
     */
    const BANDKUERZEL = 'bandkuerzel';

    /**
     * constant for route parameter name
     */
    const SIGLE = 'sigle';

    /**
     * Generates user interface to manipulate the DietrichLiteraturreferenzEntity identified by $bandkuerzel and $sigle
     *
     * @param Request $request
     * @param string $bandkuerzel BandEntity->bandkuerzel
     * @param string $sigle DietrichLiteraturreferenzEntity->sigle
     * @return RedirectResponse|Response
     *
     * @Route("/literaturreferenz/band/{bandkuerzel}/sigle/{sigle}", name="literaturreferenzadministration")
     */
    public function sigledLiteraturreferenzAdministrationAction(Request $request, string $bandkuerzel, string $sigle)
    {
        /* @var $formFactory FormFactory */
        $formFactory = $this->get('form.factory');

        /* @var $logger LoggerInterface */
        $logger = $this->get('logger');

        $redirectRequest = new RedirectRequest(
            self::LITERATURREFERENZADMINISTRATION_ROUTE,
            ['bandkuerzel' => $bandkuerzel, 'sigle' => $sigle]
        );

        $featureContext = new LitrefAdminFeatureContext(
            $request,
            $this->getDoctrine(),
            $formFactory,
            $logger,
            $redirectRequest,
            $bandkuerzel,
            urldecode($sigle)
        );

        $viewParameters = [];

        $viewParameters['articleLinkFeature'] = new ArticleLinkFeature($featureContext);

        $viewParameters['backToListFeature'] = new BackToListFeature($featureContext);

        $viewParameters['addZdbLitrefByIdFeature'] = new AddZdbLitrefFeature($featureContext);

        $viewParameters['goToSigleFeature'] = new GoToSigleFeature(
            $featureContext,
            $featureContext->dietrichLitref->getBandEntity()
        );

        $viewParameters['editDietrichLitrefFeature'] = new EditDietrichLitrefFeature($featureContext);

        $viewParameters['editDietLitNormLitFeatures'] = EditDietLitNormLitFeature::constructList(
            $featureContext,
            $featureContext->dietrichLitref->getDietrichlitrefNormlitrefEntities()
        );

        $viewParameters['addKvkLitrefFeature'] = new AddKvkLitrefFeature($featureContext);

        $viewParameters['nextPrevDietLitrefFeature'] = new NextPrevDietLitrefFeature($featureContext);

        $viewParameters['newDietrichLitrefFeature'] = new NewDietrichLitrefFeature($featureContext, $featureContext->dietrichLitref->getBandEntity());

        $viewParameters['deleteDietrichLitrefFeature'] = new DeleteDietrichLitrefFeature($featureContext);

        $viewParameters['linkToZdbKatalogFeature'] = new LinkToZdbKatalogFeature($this->getDoctrine());

        $viewParameters['sieheSigleFeature'] = new SieheSigleFeature($featureContext);

        if ($redirectRequest->shallRedirect) {
            return $this->redirectToRoute($redirectRequest->route, $redirectRequest->params);
        }

        $viewTemplate = 'Literaturreferenzadministration/sigledLiteraturreferenzAdministration.html.twig';
        return $this->render($viewTemplate, $viewParameters);
    }
}
