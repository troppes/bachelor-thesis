<?php
namespace AppBundle\Controller\LemmaAdministration;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Repository\LemmaRepository;
use AppBundle\Feature\FeatureBase;
use Symfony\Component\HttpFoundation\Response;

class LemmaListController extends AbstractController {
    const LEMMA_LISTE_ROUTE = 'liste_alle_lemmas';

    /**
     * @param Request $request
     * @param $character string list all lemmas starting with $character
     * @param $filter string filter the list by specified $filter
     *
     * @Route("/lemma_administration/lemma_liste", name="liste_alle_lemmas_default")
     * @Route("/lemma_administration/lemma_liste/{character}/filter/{filter}", name="liste_alle_lemmas")
     *
     * @see LemmaRepository::findByCharacter()
     * @return Response
     */
	public function listLemma(Request $request, $character, $filter): Response
    {
		$doctrineManager = $this->getDoctrine()->getManager(FeatureBase::DB_BACKEND);
		/* @var $lemmaRepository LemmaRepository */
		$lemmaRepository = $doctrineManager->getRepository(LemmaEntity::class);
		$lemmaList = $lemmaRepository->findByCharacter($character, $filter);

		$viewTemplate = 'lemmaAdministration/lemmaList.twig';
		$viewParameters = [
			'lemmaList' => $lemmaList,
			'currentCharacter' => $character,
			'currentFilter' => $filter,
			'lemmaStatusFilterList' => LemmaRepository::STATUS_FILTER_LIST,
            'groupLemmasRoute' => LemmaGroupController::GROUP_LEMMAS_ROUTE,
        ];

		return $this->render($viewTemplate, $viewParameters);
	}

    /**
     * @param Request $request
     *
     * @Route("/lemma_administration/lemma_liste", name="liste_alle_lemmas_default")

     * @see LemmaRepository::findByCharacter()
     * @return Response
     */
    public function listLemmaDefault(Request $request): Response
    {
        return $this->listLemma($request, 'A', 'alle');
    }
}
