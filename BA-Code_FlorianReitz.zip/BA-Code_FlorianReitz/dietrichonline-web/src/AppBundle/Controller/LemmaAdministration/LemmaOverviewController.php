<?php
namespace AppBundle\Controller\LemmaAdministration;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Repository\LemmaRepository;
use AppBundle\Feature\FeatureBase;
use Symfony\Component\HttpFoundation\Response;

class LemmaOverviewController extends Controller {
    const LEMMA_OVERVIEW_ROUTE = 'lemma_administration/lemmauebersicht';

    /**
     * @Route("/lemma_administration/lemmauebersicht/{filter}", defaults={"filter"="alle"}, name="lemma_administration_overview_long")
     * @Route("/lemma_administration",  name="lemma_administration_overview")
     *
     * @param Request $request
     * @return Response
     */
    public function lemmaOverview(Request $request)
    {
        $viewTemplate = 'lemmaAdministration/lemmaList.twig';
        $viewParameters = [
            'currentFilter' => 'alle',
            'lemmaStatusFilterList' => LemmaRepository::STATUS_FILTER_LIST,
            'groupLemmasRoute' => LemmaGroupController::GROUP_LEMMAS_ROUTE,
        ];

        return $this->render($viewTemplate, $viewParameters);
    }
}
