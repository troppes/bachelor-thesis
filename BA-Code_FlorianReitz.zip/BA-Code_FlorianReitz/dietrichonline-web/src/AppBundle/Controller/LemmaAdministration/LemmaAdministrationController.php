<?php

namespace AppBundle\Controller\LemmaAdministration;

use AppBundle\Entity\LemmaEntity;
use AppBundle\Feature\LemmaAdministration\LemmaAdministrationFeatureContext;
use AppBundle\Feature\LemmaAdministration\LemmaAdminstrationFeatureBase;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Feature\LemmaAdministration\AddGndFeature;
use AppBundle\Feature\LemmaAdministration\LemmaDisplayEditFeature;
use AppBundle\Feature\LemmaAdministration\NextPrevLemmaFeature;
use AppBundle\Controller\RedirectRequest;
use AppBundle\Feature\LemmaAdministration\LemmaGndListFeature;
use AppBundle\Feature\LemmaAdministration\LemmaBandFeature;
use AppBundle\Feature\LemmaAdministration\StatusCommentFeature;
use AppBundle\Feature\LemmaAdministration\DeleteLemmaFeature;
use AppBundle\Feature\LemmaAdministration\HomonymenListeFeature;
use Symfony\Component\HttpFoundation\Response;

class LemmaAdministrationController extends Controller
{
    const LEMMA_ADMINISTRATION_ROUTE = 'lemma_administration';

    /**
     * @Route("/lemma_administration/lemma/{lemmaId}/{filter}", defaults={"filter"="alle"} ,name="lemma_administration")
     *
     * @param Request $request
     * @param $lemmaId lemmaEntity.id
     * @param string $filter The Filter is specified either by the Link or by the default "Alle"
     * @return Response
     */
    public function lemmaAdministration(Request $request, $lemmaId, $filter)
    {
        $viewParameters = [];

        $redirectRequest = new RedirectRequest();
        $redirectRequest->route = self::LEMMA_ADMINISTRATION_ROUTE;
        $redirectRequest->params["lemmaId"] = $lemmaId;
        $redirectRequest->params["filter"] = $filter;

        $doctrine = $this->getDoctrine();

        /* @var $formFactory FormFactory */
        $formFactory = $this->get('form.factory');
        $logger = $this->get('logger');

        $context = new LemmaAdministrationFeatureContext(
            $request,
            $doctrine,
            $formFactory,
            $redirectRequest,
            $lemmaId,
            $logger
        );

        // used for Artikel-Liste, LemmaListLink, lemmaAdministration.twig
        $viewParameters['lemmaOnlyFeature'] = new LemmaAdminstrationFeatureBase($context);

        $viewParameters['addGndFeature'] = new AddGndFeature($context);

        $viewParameters['lemmaDisplayEditFeature'] = new LemmaDisplayEditFeature($context);

        $viewParameters['nextPrevLemmaFeature'] = new nextPrevLemmaFeature($context);

        $viewParameters['lemmaGndListFeature'] = new LemmaGndListFeature($context);

        $viewParameters['lemmaBandFeature'] = new LemmaBandFeature($context);

        $viewParameters['statusCommentFeature'] = new StatusCommentFeature($context);

        $viewParameters['deleteLemmaFeature'] = new DeleteLemmaFeature($context);

        $viewParameters['homonymenListeFeature'] = new HomonymenListeFeature($context);

        $viewParameters['filter'] = $filter;

        if ($redirectRequest->shallRedirect) {
            return $this->redirectToRoute($redirectRequest->route, $redirectRequest->params);
        }


        $viewTemplate = 'lemmaAdministration/lemmaAdministration.twig';
        $response = $this->render($viewTemplate, $viewParameters);
        return $response;
    }
}