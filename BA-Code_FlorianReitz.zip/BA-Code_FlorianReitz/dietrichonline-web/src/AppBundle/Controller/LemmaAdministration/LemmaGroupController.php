<?php

namespace AppBundle\Controller\LemmaAdministration;

use AppBundle\Entity\LemmaEntity;
use AppBundle\Repository\LemmaRepository;
use Doctrine\Common\Persistence\ObjectManager;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

class LemmaGroupController
    extends Controller
{
    const LEMMA_IDS_KEY       = 'lemma_ids';
    const MASTER_LEMMA_ID_KEY = 'master_lemma_id';

    const GROUP_LEMMAS_ROUTE = 'group_lemmas';

    private function getDoctrineManager(): ObjectManager
    {
        return $this->getDoctrine()->getManager('backend');
    }

    /**
     * @param Request $request
     *
     * @Route("/lemma_administration/group_lemmas", name="group_lemmas")
     *
     * @return Response
     */
    public function groupLemmasAction(Request $request): Response
    {
        $lemmaIds = $request->query->get(self::LEMMA_IDS_KEY, '');
        if (preg_match('/^\d+(,\d+)*$/', $lemmaIds) === 0) {
            throw new BadRequestHttpException('Kann lemma ids nicht parsen.');
        }

        $masterLemmaId = $request->query->get(self::MASTER_LEMMA_ID_KEY, '');
        if (preg_match('/^\d+$/', $masterLemmaId) === 0) {
            throw new BadRequestHttpException('Kann master lemma id nicht parsen.');
        }

        /** @var LemmaRepository $lemmaRepo */
        $lemmaRepo = $this->getDoctrine()->getRepository(LemmaEntity::class);

        $lemmas = $lemmaRepo->findByCommaSeperatedIds($lemmaIds);

        /** @var LemmaEntity $masterLemma */
        $masterLemma = $lemmaRepo->find($masterLemmaId);

        $viewTemplate = 'lemmaAdministration/MasterLemma.twig';
        $viewParameters = [
            'lemmas' => $lemmas,
            'masterLemma' => $masterLemma,
            'masterLemmaIdKey' => self::MASTER_LEMMA_ID_KEY,
            'lemmaIdsKey' => self::LEMMA_IDS_KEY,
        ];

        return $this->render($viewTemplate, $viewParameters);
    }

    /**
     * @param Request $request
     *
     * @Route("lemma_administration/master_lemma_administration/ungroup/{subLemmaId}", name="ungroup_lemma_action")
     *
     * @return RedirectResponse
     */
    public function ungroupLemmaAction(Request $request, $subLemmaId): RedirectResponse
    {
        $doctrineManager = $this->getDoctrineManager();
        /** @var LemmaRepository $lemmaRepo */
        $lemmaRepo = $doctrineManager->getRepository(LemmaEntity::class);
        /** @var LemmaEntity $subLemma */
        $subLemma = $lemmaRepo->find($subLemmaId);
        if ($subLemma === null) {
            throw new UnprocessableEntityHttpException('Cannot find sub lemma.');
        }

        if ($subLemma->isMasterLemma()) {
            throw new UnprocessableEntityHttpException('master lemma cannot be ungrouped.');
        }

        $masterLemma = $subLemma->getMasterLemma();
        if ($masterLemma === null) {
            throw new UnprocessableEntityHttpException('Cannot find master lemma.');
        }

        $subLemma->setMasterLemma(null);
        $doctrineManager->flush();

        // a master lemma which only references itself shall be an ungrouped lemma
        $doctrineManager->refresh($masterLemma);
        if ($masterLemma->getGroupedLemmas()->count() < 2) {
            $masterLemma->setMasterLemma(null);
            $doctrineManager->flush();
        }

        $redirectUrl = $this->generateRedirectUrlToLemmaList($masterLemma);

        return $this->redirect($redirectUrl);
    }

    public function prepareMasterLemmaSubmitAction(Request $request): LemmaEntity
    {
        $noLemmaId = '';
        $masterLemmaId = $request->request->get(self::MASTER_LEMMA_ID_KEY, $noLemmaId);
        if ($masterLemmaId === $noLemmaId) {
            throw new BadRequestHttpException('No master lemma id given.');
        }
        if (preg_match('/^\d+$/', $masterLemmaId) === 0) {
            throw new BadRequestHttpException('Cannot parse master lemma id: '.$masterLemmaId);
        }

        $lemmaIds = $request->request->get(self::LEMMA_IDS_KEY, []);
        if (count($lemmaIds) === 0) {
            throw new BadRequestHttpException('No lemma ids given.');
        }
        foreach ($lemmaIds as $lemmaId) {
            if (preg_match('/\d+/', $lemmaId) === 0) {
                throw new BadRequestHttpException('Cannot parse lemma id: '.$lemmaId);
            }
        }

        /** @var ObjectManager $doctrineManager */
        $doctrineManager = $this->getDoctrineManager();

        /** @var LemmaRepository $lemmaRepo */
        $lemmaRepo = $doctrineManager->getRepository(LemmaEntity::class);
        /** @var LemmaEntity $masterLemma */
        $masterLemma = $lemmaRepo->find($masterLemmaId);
        $lemmas = $lemmaRepo->findByIds($lemmaIds);

        /** @var LemmaEntity $lemma */
        foreach ($lemmas as $lemma) {
            // let the master lemma point to itself. This way, we know it is a master lemma (^_^)
            $lemma->setMasterLemma($masterLemma);
        }

        return $masterLemma;
    }

    /**
     * @param Request $request
     *
     * @Route("/lemma_administration/master_lemma_administration/preview", name="master_lemma_preview")
     *
     * @return Response
     */
    public function masterLemmaPreviewAction(Request $request): Response
    {
        $masterLemma = $this->prepareMasterLemmaSubmitAction($request);

        $viewTemplate = 'lemmaAdministration/MasterLemmaPreview.twig';
        $viewParameters = [
            'masterLemma' => $masterLemma,
            'masterLemmaIdKey' => self::MASTER_LEMMA_ID_KEY,
            'lemmaIdsKey' => self::LEMMA_IDS_KEY,
        ];

        return $this->render($viewTemplate, $viewParameters);
    }

    const MASTER_LEMMA_SUBMIT_ROUTE = 'master_lemma_submit';

    /**
     * @param Request $request
     *
     * @Route("/lemma_administration/master_lemma_administration/submit", name="master_lemma_submit")
     *
     * @return RedirectResponse
     */
    public function masterLemmaSubmitAction(Request $request): RedirectResponse
    {
        $masterLemma = $this->prepareMasterLemmaSubmitAction($request);
        $this->getDoctrineManager()->flush();

        $redirectUrl = $this->generateRedirectUrlToLemmaList($masterLemma);

        return $this->redirect($redirectUrl);
    }

    private function generateRedirectUrlToLemmaList(LemmaEntity $lemmaEntity): string
    {
        $character = mb_substr($lemmaEntity->getBezeichnung(), 0, 1);
        if (preg_match('/^[a-zA-Z]$/', $character) === 0) {
            $character = LemmaEntity::NOT_A_TO_Z_CHARACTER;
        }

        return $this->generateUrl(
            LemmaListController::LEMMA_LISTE_ROUTE,
            ['character' => $character, 'filter' => 'alle']
        ).'#'.$lemmaEntity->getId();
    }
}