<?php

namespace AppBundle\Controller;

use AppBundle\Repository\BandRepository;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\FormFactory;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use AppBundle\Entity\BandEntity;

class SimpleSiteController extends Controller {
    /**
     * @Route("/", name="projektseite")
     */
    public function projektAction(Request $request) {
    	return $this->baseAction('UserSearchFrontend/projektSeite.html.twig');
    }

    /**
     * @Route("/dietrichbaende", name="dietrichbaende")
     */
    public function dietrichbaendeAction(Request $request)
    {
        /** @var BandRepository $bandRepository */
        $bandRepository = $this->getDoctrine()->getRepository(BandEntity::class);
        /** @var BandEntity[] $dietrichbaende */
        $dietrichbaende = $bandRepository->findAll();
        /** @var BandEntity[] $idsOfSearchableBaende */
        $idsOfSearchableBaende = $bandRepository->findIdsOfSearchableBaende();

        return $this->baseAction('UserSearchFrontend/dietrichbaende.html.twig',
            [
                'dietrichbaende' => $dietrichbaende,
                'idsOfSearchableBaende' => $idsOfSearchableBaende
            ]);
    }

    /**
     * @Route("/hilfe", name="hilfe")
     */
    public function hilfeAction(Request $request) {
        return $this->baseAction('UserSearchFrontend/hilfeseite.html.twig');
    }

    /**
     * @Route("/kontakt", name="kontakt")
     */
    public function kontaktAction(Request $request) {
    	return $this->baseAction('UserSearchFrontend/kontaktseite.html.twig');
    }
    
    protected function baseAction($templatePath, $viewParameters = array()) {
    	/* @var $formFactory FormFactory */;
    	$formFactory = $this->get('form.factory');
    	$simpleUserSearchForm = $formFactory->createNamedBuilder('simpleUserSearch', FormType::class, null, [
    			'method' => 'GET',
    			'action' => $this->generateUrl('user_search'),
    			'csrf_protection' => false
    	])
    	->add('begriff', TextType::class)
    	->getForm();
    	$viewParameters['simpleSearchForm'] = $simpleUserSearchForm->createView();
    	return $this->render($templatePath, $viewParameters);
    }
}
