<?php

namespace AppBundle\Controller;

use AppBundle\Feature\FeatureContext;
use AppBundle\Feature\SimpleUserSearchFeature;
use AppBundle\Util\Log;
use Symfony\Bundle\TwigBundle\Controller\ExceptionController;
use Symfony\Component\Debug\Exception\FlattenException;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Log\DebugLoggerInterface;

/**
 * Class DietrichOnlineExceptionController is a custom ExceptionController to implement error logging and display of
 * usual navigation, header and footer content.
 *
 * It is registered as a service in app/config/services.yml. The Service is registered as exception controller in
 * app/config/config.yml->twig.exception_controller.
 *
 * @package AppBundle\Controller
 */
class DietrichOnlineExceptionController extends ExceptionController implements ContainerAwareInterface
{
    /**
     * @var ContainerInterface|null
     */
    private $container;

    public function showAction(Request $request, FlattenException $exception, DebugLoggerInterface $logger = null)
    {
        $currentContent = $this->getAndCleanOutputBuffering($request->headers->get('X-Php-Ob-Level', -1));
        $showException = $request->attributes->get('showException', $this->debug); // As opposed to an additional parameter, this maintains BC

        $code = $exception->getStatusCode();

        // own code begin; code above and below from Symfony\Bundle\TwigBundle\Controller\ExceptionController:showAction()
        if ($code === '500' || $code === 500) {
            $msg = sprintf(
                'HTTP Error Code %s on request URL "%s": %s',
                $code,
                $request->getRequestUri(),
                $exception->getMessage()
            );
            Log::httpRequestError($this->container->get('logger'), $msg, $exception);
        }

        $featureContext = new FeatureContext(
            $request,
            $this->container->get('doctrine'),
            $this->container->get('form.factory'),
            new RedirectRequest(),
            null,
            $this->container->get('router')
        );

        $simpleUserSearchFeature = new SimpleUserSearchFeature($featureContext);
        // own code end

        return new Response($this->twig->render(
            (string)$this->findTemplate($request, $request->getRequestFormat(), $code, $showException),
            array(
                'status_code' => $code,
                'status_text' => isset(Response::$statusTexts[$code]) ? Response::$statusTexts[$code] : '',
                'exception' => $exception,
                'logger' => $logger,
                'currentContent' => $currentContent,
                // supply simpleSearchForm for twig template
                'simpleSearchForm' => $simpleUserSearchFeature->getSimpleUserSearchFormView(),
            )
        ), $code, array('Content-Type' => $request->getMimeType($request->getRequestFormat()) ?: 'text/html'));
    }

    /**
     * Sets the container.
     *
     * @param ContainerInterface|null $container A ContainerInterface instance or null
     */
    public function setContainer(ContainerInterface $container = null)
    {
        $this->container = $container;
    }
}