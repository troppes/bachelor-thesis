<?php

namespace AppBundle\Controller\EmployeeOverview;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormFactory;

class EmployeeOverviewController
    extends Controller
{
    /**
     * @Route("/employee-overview", name="employee_overview")
     * @Route("/employee-homepage", name="employee_homgepage")
     * @Route("/mitarbeiter-uebersicht", name="employee_uebersicht_ger")
     * @Route("/mitarbeiter-startseite", name="employee_startseite_ger")
     */
    public function employeeOverviewAction()
    {
        /* @var $formFactory FormFactory */;
        $formFactory = $this->get('form.factory');
        $simpleUserSearchForm = $formFactory->createNamedBuilder('simpleUserSearch', FormType::class, null, [
            'method' => 'GET',
            'action' => $this->generateUrl('user_search'),
            'csrf_protection' => false
        ])->add('begriff', TextType::class)->getForm();

        $viewParameters['simpleSearchForm'] = $simpleUserSearchForm->createView();

        return $this->render(
            ':EmployeeOverview:employeeOverview.html.twig',
            $viewParameters
        );
    }
}
