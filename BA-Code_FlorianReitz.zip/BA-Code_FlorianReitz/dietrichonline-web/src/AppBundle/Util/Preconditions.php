<?php
/**
 * Created by PhpStorm.
 * User: kock
 * Date: 11.10.2018
 * Time: 15:00
 */

namespace AppBundle\Util;


/**
 * This class Preconditions consists of <code>static</code> utility methods for operation on objects.
 * These utilities are generally convenience methods that help a method or constructor to check if it was invoked correctly.
 * When an illegal argument was passed instead, the <code>Preconditions</code> method throws an exception, that will help to inform the caller directly
 * <p>
 * Example:
 * <code>
 * public function get_name_of_user_object(user): string
 * {
 *     Preconditions.notNull(user, "user");
 *
 *     return user.get_name();
 * }
 * </code>
 *
 * Bad caller:
 * <code>
 * user_name = get_name_of_user_object(null);
 * </code>
 *
 * @package AppBundle\Util
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class Preconditions
{
    /**
     * Ensure that the given object reference is not <code>null</code> and a human readable valueName is set (for better messages).
     *
     * @param mixed $value The parameter to validate
     * @param string $valueName The name of the parameter (human readable)
     * @throws \InvalidArgumentException if one or both given parameters are <code>null</code>
     * @throws \InvalidArgumentException if $valueName is empty
     */
    public static function notNull($value, $valueName)
    {
        if ($valueName === null)
        {
            throw new \InvalidArgumentException('ValueName must not be null.');
        }

        if (empty($valueName))
        {
            throw new \InvalidArgumentException('ValueName must not be empty.');
        }

        if ($value === null)
        {
            throw new \InvalidArgumentException(sprintf("Passed value '%s' must not be null.", $valueName));
        }
    }

    /**
     * Ensure that the given parameter is not empty (includes <code>null</code>).
     * <p>
     * To validate that the values are not empty the method uses <code>empty()</code> of standard PHP.
     * Note, that this includes some extra <strong>empty</strong> cases.
     *
     * @see https://php.net/manual/de/function.empty.php
     *
     * @param mixed $value The value to validate
     * @param string $valueName The name of the parameter (human readable)
     * @throws \InvalidArgumentException if one or both given parameters are <code>null</code> or <code>empty</code>.
     */
    public static function notEmpty($value, $valueName)
    {
        self::notNull($valueName, 'valueName');
        self::notNull($value, $valueName);

        if (empty($value))
        {
            throw new \InvalidArgumentException(sprintf("Passed value '%s' must not be empty.", $valueName));
        }
    }

    /**
     * Ensure that the given integer value is greater that the gtValue.
     * <p>
     * Default check is that the given value is positive (> 0).
     *
     * @param int $value The value to validate
     * @param string $valueName The name of the parameter (human readable)
     * @param int $gtValue The value to check against.
     */
    public static function isGreaterThan(int $value, string $valueName, int $gtValue = 0)
    {
        self::notNull($valueName, 'valueName');

        if ($value <= $gtValue)
        {
            throw new \InvalidArgumentException(sprintf("Passed value for '%s' <%d> must be greater than <%d>.", $valueName, $value, $gtValue));
        }
    }

    /**
     * Ensures that the given integer value is in range of numbers.
     * <p>
     * We validate that:
     * <ol>
     *   <li>maxValue > minValue
     *   <li>value >= minValue
     *   <li>value <= maxValue
     * </ol>
     *
     * @param int $value
     * @param string $valueName
     * @param int $minValue
     * @param int $maxValue
     *
     * @throws \InvalidArgumentException if the value is not in range
     */
    public static function checkIsInRange(int $value,
                                          string $valueName,
                                          int $minValue = 0,
                                          int $maxValue = 1)
    {
        self::notNull($valueName, 'valueName');
        self::isGreaterThan($maxValue, 'maxValue', $minValue);

        if ($value < $minValue || $value > $maxValue)
        {
            throw new \InvalidArgumentException(sprintf("Passed value '%s' <%d> is not in Range of <%d> and <%d>.", $valueName, $value, $minValue, $maxValue));
        }
    }

    /**
     * Ensures that the length of the given string is within the border of $length.
     *
     * @param string $value The value to ensure length.
     * @param string $valueName The name of the value.
     * @param int $maxLength The max length to ensure (DEFAULT is 1);
     */
    public static function checkMaxLength(string $value, string $valueName, int $maxLength = 1)
    {
        self::notNull($valueName, 'valueName');

        if (strlen($value) > $maxLength) {
            throw new \InvalidArgumentException(sprintf("Length of passed value '%s' <%s> is greater than check length <%d> ",
                $valueName, $value, $maxLength));
        }
    }
}