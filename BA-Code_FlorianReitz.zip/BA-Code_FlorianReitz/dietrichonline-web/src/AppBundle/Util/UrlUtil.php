<?php

namespace AppBundle\Util;

use InvalidArgumentException;
use phpDocumentor\Reflection\Types\Boolean;

class UrlUtil
{
    const LITERAL_ERROR_MSG = 'Bitte prüfen Sie ob die folgende URL (Sonderzeichen ersetzt) zum gewünschten Ziel führt:';
    const MINIMAL_DOMAIN_LENGTH = 7;
    const WWW_PREFIX = 'www';
    const TLD_SEPARATOR = '.';
    const PARSE_URL_HOST_KEY = 'host';

    /**
     * Returns a domain special ASCII url representation of the given URL.
     * <p>
     * Tries to fix the given `$url` by replacing each `$character` other than ':', '/', '?', '=', '&', '#', '%' with
     * `urlencode($character)`
     *
     * @param string $url
     * @return string The transformed URL
     * @throws \InvalidArgumentException If the transformed string is not a valid URL
     */
    public static function getSpecialEncodedUrl(string $url): string
    {
        $chars = str_split($url);
        foreach ($chars as $key => $char) {
            if ($char !== ':'
                && $char !== '/'
                && $char !== '?'
                && $char !== '='
                && $char !== '&'
                && $char !== '#'
                && $char !== '%'
            ) {
                $chars[$key] = urlencode($char);
            }
        }

        $repairedUrl = implode($chars);

        if (filter_var($repairedUrl, FILTER_VALIDATE_URL) === false) {
            throw new InvalidArgumentException(sprintf('Given URL <%s> will become <%s>, which is not a valid URL.', $url, $repairedUrl));
        }

        return $repairedUrl;
    }

    /**
     * Returns the extracted domain of the given url.
     * <p>
     * For further naming conventions
     * @see https://www.sistrix.de/frag-sistrix/onpage-optimierung/was-ist-der-unterschied-zwischen-einer-url-domain-subdomain-hostnamen-usw/ URL definitions
     *
     * @param string $url The url to check.
     * @return string Returns the extracted domain (name + tld) of the given url.
     *
     * @throws InvalidArgumentException when the given url is not really an url.
     */
    public static function getDomainName(string $url): string
    {
        // check domain (with tld) exists
        if (!self::isValidUrl($url)) {
            throw new InvalidArgumentException(sprintf('Given input <%s> is not a valid URL.', $url));
        }

        $tldIndex = 0;
        $domainNameIndex = 1;
        $subDomainIndex = 2;

        $domain = array_reverse(explode('.', parse_url($url)['host']));

        $tldDomain = $domain[$domainNameIndex].'.'.$domain[$tldIndex];

        if (strlen($tldDomain) < self::MINIMAL_DOMAIN_LENGTH
            // check domain (with tld) and subdomain exists
            && count($domain) >= $domainNameIndex + 1
            // check subdomain is not www
            && strtolower($domain[$subDomainIndex]) !== self::WWW_PREFIX
        ) {
            $tldDomain = $domain[$subDomainIndex].'.'.$tldDomain;
        }

        return $tldDomain;
    }

    /**
     * Returns if the given url is really an url.
     *
     * @param string $url An input url
     * @return bool <code>true</code> if the given url is really an url, otherwise <code>false</code>
     */
    public static function isValidUrl(string $url): bool
    {
        $validUrl = false;

        // Remove all illegal characters from a url
        $sanitizedUrl = filter_var($url, FILTER_SANITIZE_URL);

        if (filter_var($sanitizedUrl, FILTER_VALIDATE_URL)) {
            $validUrl = true;
        }

        return $validUrl && self::isHostWithSeparatorDots($url);
    }

    /**
     * Returns the state of dots in the given host part of the url.
     * <p>
     * Tests for a minimum of one dot.
     * <p>
     * Example:
     * domain -> dots 0 --> false
     * domain.tld -> dots 1 --> true
     * domain.tld.bla -> dots 2 --> true
     * 192.168.0.1 -> dots 3 --> true
     *
     * @param string $url The url to test.
     * @return bool <code>true</code> if the given url contains a minimum of one dot, otherwise <code>false</code>.
     */
    private static function isHostWithSeparatorDots(string $url): bool
    {
        $domainWithTld = false;

        $urlTokens = parse_url($url);
        if (array_key_exists(self::PARSE_URL_HOST_KEY, $urlTokens)) {
            $host = $urlTokens[self::PARSE_URL_HOST_KEY];
            $dotCount = substr_count($host, self::TLD_SEPARATOR);
            // has host a minimum of one dot (dot between domain and tld: domain.tld)?
            if ($dotCount >= 1) {
                $domainWithTld = true;
            }
        }

        return $domainWithTld;
    }
}