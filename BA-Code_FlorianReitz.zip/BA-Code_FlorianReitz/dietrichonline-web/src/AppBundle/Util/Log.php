<?php

namespace AppBundle\Util;

use Exception;
use Psr\Log\LoggerInterface;
use Symfony\Component\Debug\Exception\FlattenException;

/**
 * This Class Log consists of <code>static</code> utility methods for operation with log messages.
 * These utilities are generally convenience methods that helps to log message with thrown exceptions uniform.
 * <p>
 * Example:
 * <code>
 * Log::error($this->get('logger'), "An error occured", $error);
 * </code>
 * For further informations about logging see <a href='https://symfony.com/doc/3.1/logging.html'>Symfony: Logging with Monolog</a>.
 *
 * @package AppBundle\Util
 * @author Martin Kock <kock@uni-trier.de>
 */
class Log
{
    /**
     * Logs an error with message and the original thrown exception as 'cause'.
     *
     * @param LoggerInterface $logger The logger from the container
     * @param string $message The message to log
     * @param Exception $exception The original thrown exception
     */
    public static function error($logger, $message, $exception)
    {
        Preconditions::notNull($logger, 'logger');
        Preconditions::notEmpty($message, 'message');
        Preconditions::notNull($exception, 'exception');

        $details = [
            'cause' => $exception
        ];

        $logger->error($message, $details);
    }

    /**
     * @param LoggerInterface $logger the logger from the container
     * @param string $message the message to log
     * @param FlattenException $flattenException the FlattenException given from the Symfony ExceptionController
     */
    public static function httpRequestError(LoggerInterface $logger, string $message, FlattenException $flattenException)
    {
        Preconditions::notNull($logger, 'logger');
        Preconditions::notEmpty($message, 'message');
        Preconditions::notNull($flattenException, 'flattenException');

        $details = [
            'cause' => $flattenException
        ];

        $logger->error($message, $details);
    }
}
