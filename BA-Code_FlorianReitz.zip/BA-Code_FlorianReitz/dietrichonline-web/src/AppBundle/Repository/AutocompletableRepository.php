<?php

namespace AppBundle\Repository;

use AppBundle\Controller\UserSearch\SearchAutocompletionController;
use Doctrine\ORM\EntityRepository;
use Elasticsearch\ClientBuilder;

/**
 * @author Florian Reitz <reitz@uni-trier.de>
 * @author Milan Rüll (milanruell@gmail.com)
 */
class AutocompletableRepository
    extends EntityRepository
{
    const SEARCH_TERM_PARAM_KEY = 'query';

    /**
     * Returns a list of strings, containing autocomplete suggestions.
     *
     * @param string $matchAgainst The string to autocomplete.
     * @param int $categoryIndex The column of the table to get autocomplete suggestions from.
     * @param int $maxMatches
     *
     * @return array() in the form of [{$columnName1 => data, $columnName2 => data}, ..
     */
    public function getSuggestionsList(string $matchAgainst, int $categoryIndex, int $maxMatches = 10)
    {

        $myCert = 'certs/ca.crt';

        $clientBuilder = ClientBuilder::create()->setHosts(
            ['https://bib55.uni-trier.de:9200', 'https://bib55.uni-trier.de:9201']
        );
        $client        = $clientBuilder->setSSLVerification($myCert)->setApiKey(
            'gPQyZ28BZIqHlxQHP_3u',
            'dMouSGTHQBmkRyx9mBZoBg'
        )->build();

        $params = [
            'index' => 'dietrich_frontend',
            'body' => [
                '_source' => '', //Empty Source since we need only the String
                'suggest' => [
                    'auto_complete' => [
                        'prefix' => $matchAgainst,
                        'completion' => [
                            'field' => SearchAutocompletionController::AUTOCOMPLETE_COLUMNS[$categoryIndex],
                            'size' => $maxMatches,
                            'skip_duplicates' => true,
                        ],
                    ],
                ],
            ],
        ];

        $allResults = $client->search($params);

        return $allResults['suggest']['auto_complete'][0]['options'];
    }
}