<?php
namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use Doctrine\ORM\Query;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;

/**
 * Custom repository class for DietrichlitrefNormlitrefEnties
 * 
 * @author Kajetan Weiß (weiss@uni-trier.de)
 */
class DietrichlitrefNormlitrefRepository extends EntityRepository {
	public function findByDietrichliteraturreferenz(DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity) {
		$entityManager = $this->_em;
		$query = $entityManager->createQuery(
			'SELECT dietrichlitrefNormlitref
			FROM '.DietrichlitrefNormlitrefEntity::class.' dietrichlitrefNormlitref
			JOIN dietrichlitrefNormlitref.dietrichliteraturreferenzEntity dietrichlitref
			WHERE dietrichlitref = ?1'
		)->setParameter(1, $dietrichliteraturreferenzEntity);
		return $query->getResult();
	}
}
