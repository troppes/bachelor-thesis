<?php

namespace AppBundle\Repository;

use AppBundle\NativeSql\UserSearchSqlBuilder;
use Elasticsearch\ClientBuilder;
use Psr\Log\LoggerInterface;

/**
 * Custom repository class for ArtikelEntities
 * <p>
 * This class extends <code>AutocompletableRepository</code> because there is a dependency.
 * Without there is no search suggestion for the user.
 *
 * @package AppBundle\Repository
 *
 * @author Kajetan Weiß <weiss@uni-trier.de>
 * @author Martin Kock <kock@uni-trier.de>
 */
class ArtikelRepository
    extends AutocompletableRepository
{
    /** @var LoggerInterface */
    private $logger;

    /**
     * Sets the logger from the calling container.
     *
     * @param LoggerInterface $logger
     */
    public function setLogger(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Returns a list of matched ArtikelEntities to the user search terms.
     *
     * @param array $userSearchItemArray
     * @param int $nextResultNumber
     *
     * @return array The list of matching articles, otherwise the array is empty.
     */
    public function findUserSearchResult(array $userSearchItemArray, int $nextResult): array
    {
        $result = [];

        if (count($userSearchItemArray) > 0) {
            $myCert = 'certs/ca.crt';

            $clientBuilder = ClientBuilder::create()->setHosts(
                ['https://bib55.uni-trier.de:9200', 'https://bib55.uni-trier.de:9201']
            );
            $client        = $clientBuilder->setSSLVerification($myCert)->setApiKey(
                'gPQyZ28BZIqHlxQHP_3u',
                'dMouSGTHQBmkRyx9mBZoBg'
            )->build();

            $params = [
                'index' => 'dietrich_frontend',
                'body' => [
                    'from' => $nextResult,
                    'size' => 30,
                    'sort' => [
                        [
                            'artikel_erstmoegliches_erscheinungsjahr' => ['order' => 'asc', 'unmapped_type' => 'long'],
                        ],
                        [
                            'artikel_letztmoegliches_erscheinungsjahr' => ['order' => 'asc', 'unmapped_type' => 'long'],
                        ],
                    ],
                    'aggs' => [
                        'best_authors' => [
                            'terms' => [
                                'field' => 'artikel_autor.keyword',
                            ],
                        ],
                    ],
                ],
            ];

            $countParams = [
                'index' => 'dietrich_frontend',
            ];

            $userSearchSqlBuilder = new UserSearchSqlBuilder($userSearchItemArray);
            $query                = $userSearchSqlBuilder->getFullQuery();

            $params['body']['query']      = $query;
            $countParams['body']['query'] = $query;

            $allResults = $client->search($params);

            $result['results']     = $allResults['hits']['hits'];
            $result['bestAuthors'] = $allResults['aggregations']['best_authors']['buckets'];
            $result['count']       = $client->count($countParams)['count'];
        }

        return $result;
    }

}
