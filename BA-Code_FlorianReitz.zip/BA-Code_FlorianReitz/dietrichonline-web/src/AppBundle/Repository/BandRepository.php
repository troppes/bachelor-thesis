<?php
namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\ORM\Query\ResultSetMappingBuilder;
use AppBundle\Entity\BandEntity;
use Doctrine\ORM\AbstractQuery;
use Ds\Set;

/**
 * Custom repository class for ArtikelEntities
 * 
 * @author Kajetan Weiß (weiss@uni-trier.de)
 */
class BandRepository extends EntityRepository{
    const COL_BAND_ID = 'band_id';
    const COL_BANDKUERZEL = 'bandkuerzel';
    const COL_IS_EMPTY = 'is_empty';
    const COL_HAS_MIN_ONE_NEW = 'has_min_one_new';
    const COL_HAS_MIN_ONE_CLEAR = 'has_min_one_clear';
    const COL_HAS_MIN_ONE_UNCLEAR = 'has_min_one_unclear';
    
    public function findByLemmaId($lemmaId) {
        $queryString = '
            select
                band.id,
                band.bandkuerzel,
                band.bandbezeichnung,
                band.erfassungszeitraum,
                band.jahr_von,
                band.jahr_bis,
                band.scan_id
            from band
            join artikel on artikel.fk_band = band.id
            join lemma on artikel.fk_lemma = lemma.id
            where lemma.id = ?
            order by band.bandkuerzel
        ';
        
        $rsltmpng = new ResultSetMappingBuilder($this->_em);
        $rsltmpng->addRootEntityFromClassMetadata(BandEntity::class, 'band');
        
        $query = $this->_em->createNativeQuery($queryString, $rsltmpng);
        $query->setParameter(1, $lemmaId);
        $result = $query->execute();
        return $result;
    }

    /**
     * Returns the count of searchable Dietrich-Bände.
     *
     * @return mixed
     * @throws \Doctrine\ORM\NoResultException
     * @throws \Doctrine\ORM\NonUniqueResultException
     */
    public function countSearchableBaende()
    {
        $sql = 'SELECT
                  COUNT(DISTINCT fk_band) AS cnt
                FROM artikel a';

        $resultSetMapping = new ResultSetMapping();
        $resultSetMapping->addScalarResult('cnt', 'cnt');
        $query = $this->_em->createNativeQuery($sql, $resultSetMapping);

        return $query->getSingleScalarResult();
    }

    /**
     * Returns the ids of the searchable Dietrich-Bände.
     *
     * @return Set of ids
     */
    public function findIdsOfSearchableBaende(): Set
    {
        $sql = 'SELECT
                  DISTINCT b.id
                FROM artikel a
                JOIN band b
                ON a.fk_band = b.id';

        $resultSetMapping = new ResultSetMapping();
        $resultSetMapping->addScalarResult('id', 'id');
        $query = $this->_em->createNativeQuery($sql, $resultSetMapping);

        // $result has the structure [['id'=>'101'], ['id'=>'102'], ['id'=>'103']]
        $result = $query->getScalarResult();

        $idSet = new Set();
        foreach ($result as $row)
        {
            $idSet->add((int) $row['id']);
        }

        return $idSet;
    }
    
	public function findBandStates($queryString) {
		$enttmngr = $this->_em;
		
		$rsltmpng = new ResultSetMapping();
		$rsltmpng->addScalarResult(self::COL_BAND_ID, self::COL_BAND_ID, 'integer');
		$rsltmpng->addScalarResult(self::COL_BANDKUERZEL, self::COL_BANDKUERZEL, 'string');
		$rsltmpng->addScalarResult(self::COL_IS_EMPTY, self::COL_IS_EMPTY, 'boolean');
		$rsltmpng->addScalarResult(self::COL_HAS_MIN_ONE_NEW, self::COL_HAS_MIN_ONE_NEW, 'boolean');
		$rsltmpng->addScalarResult(self::COL_HAS_MIN_ONE_CLEAR, self::COL_HAS_MIN_ONE_CLEAR, 'boolean');
		$rsltmpng->addScalarResult(self::COL_HAS_MIN_ONE_UNCLEAR, self::COL_HAS_MIN_ONE_UNCLEAR, 'boolean');
		
		$query = $enttmngr->createNativeQuery($queryString, $rsltmpng);
		$rawResults = $query->execute();
		
		$bandStates = array();
		foreach ($rawResults as $rawResult) {
			$bandId = $rawResult[self::COL_BAND_ID];
			$bandStates[$bandId] = [
			    'bandkuerzel' => $rawResult[self::COL_BANDKUERZEL],
				'isEmpty' => $rawResult[self::COL_IS_EMPTY],
				// worked_on_and_something_unclear, d.h. in Bearbeitung und min ein Eintrag unklar [min_one_new and min_one_unclear] 
			    'isWorkedOnAndSomethingUnclear' => $rawResult[self::COL_HAS_MIN_ONE_NEW] && $rawResult[self::COL_HAS_MIN_ONE_UNCLEAR],
				// worked_on_and_everything_clear, d.h. in Bearbeitung und kein Eintrag unklar [min_one_new and not min_one_unclear]
			    'isWorkedOnAndEverythingClear' => $rawResult[self::COL_HAS_MIN_ONE_NEW] && !$rawResult[self::COL_HAS_MIN_ONE_UNCLEAR],
				// almost_final, d.h. kein Eintrag neu und min einer unklar [not min_one_new and min_one_unclear]
			    'isAlmostFinal' => !$rawResult[self::COL_HAS_MIN_ONE_NEW] && $rawResult[self::COL_HAS_MIN_ONE_UNCLEAR],
				// final, d.h. kein Eintrag neu und kein Eintrag unklar; gleichbedeutend mit alle Einträge klar
				// [not empty and (not min_one_new or not min_one_unclear)]
			    'isFinal' => !$rawResult[self::COL_IS_EMPTY] && !$rawResult[self::COL_HAS_MIN_ONE_NEW] && !$rawResult[self::COL_HAS_MIN_ONE_UNCLEAR],
			];
		}
		return $bandStates;
	}
}
