<?php

namespace AppBundle\Repository;

use AppBundle\Controller\Literaturreferenzadministration\LiteraturreferenzListeController;
use AppBundle\Util\Preconditions;
use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\Query;
use AppBundle\Entity\ArtikelEntity;
use AppBundle\Entity\BandEntity;
use Exception;
use InvalidArgumentException;

/**
 * Custom repository class for DietrichliteraturreferenzEntitys
 *
 * @author Kajetan Weiß (weiss@uni-trier.de)
 */
class DietrichliteraturreferenzRepository extends EntityRepository
{
    const EMPTY_STRING_LITERAL = "''";

    const PREV = 0;
    const NEXT = 1;

    const STATUS_FILTER_ALL         = "all";
    const STATUS_FILTER_ALL_PAGED   = "all_paged";
    const STATUS_FILTER_NEW         = "new";
    const STATUS_FILTER_UNCLEAR     = "unclear";

    /*
        1	neu	    Literaturreferenzen, die neu eingetragen wurden und deren Bearbeitung nicht abgeschlossen wurde, haben den Status "neu".
        2	klar	Literaturreferenzen, die bearbeitet wurden und deren Bearbeitung vollständig abgeschlossen wurde, haben den Status "klar".
        3	unklar	Literaturreferenzen, die bearbeitet wurden und deren Bearbeitung bisher ungeklärte Fragen offen lässt, haben den Status "unklar".
     */
    const BEARBEITUNGSSTATUS_NEU = 1;
    const BEARBEITUNGSSTATUS_KLAR = 2;
    const BEARBEITUNGSSTATUS_UNKLAR = 3;


    /**
     * Returns the PageNumber of given Entry with given Filter
     *
     * @param DietrichliteraturreferenzEntity $entry : Entry to find the PageNumber
     * @param string $filter : PagenumberFilter
     *
     * @return int PageNumber of Entry
     */

    public function getPageNumberByEntry(DietrichliteraturreferenzEntity $entry, string $filter) : int
    {

        Preconditions::isGreaterThan(LiteraturreferenzListeController::DEFAULT_ITEMS_PER_PAGE, 'DEFAULT_ITEMS');

        $qb = $this->createQueryBuilder('dietrichliteraturreferenz');

        $qb->select("count(dietrichliteraturreferenz.sortableSigle)");
        $qb->where('dietrichliteraturreferenz.bandEntity = (:bandEntity)');
        $qb->andWhere('dietrichliteraturreferenz.sortableSigle != (:empty)');
        $qb->andWhere('dietrichliteraturreferenz.sortableSigle < (:sortableSigle)');

        switch ($filter){
            case self::STATUS_FILTER_UNCLEAR:
                $qb->andWhere('dietrichliteraturreferenz.literaturreferenzbearbeitungsstatusEntity = '.self::BEARBEITUNGSSTATUS_UNKLAR);
                break;

            case self::STATUS_FILTER_NEW:
                $qb->andWhere('dietrichliteraturreferenz.literaturreferenzbearbeitungsstatusEntity = '.self::BEARBEITUNGSSTATUS_NEU);
                break;
        }

        $qb->orderBy('dietrichliteraturreferenz.sortableSigle');
        $qb->setParameter('bandEntity', $entry->getBandEntity()->getId());
        $qb->setParameter('sortableSigle', $entry->getSortableSigle());
        $qb->setParameter('empty', self::EMPTY_STRING_LITERAL);

        try {
            // +1 for it-index (starts with 0)
            return ceil(($qb->getQuery()->getSingleScalarResult()+1) / LiteraturreferenzListeController::DEFAULT_ITEMS_PER_PAGE);
        } catch (Exception $e) {
            return LiteraturreferenzListeController::DEFAULT_PAGE_INDEX;
        }
    }

    /**
     * Returns a doctrine Query object which retrieves, when executed, all DietrichliteraturreferenzEntity objects
     * of the BandEntity, with the given filter, which are identified by its bandkuerzel. The Query can then be used by a paginator to split
     * the query in usable page chunks.
     *
     * @param string $bandkuerzel
     * @param string $filter
     * @return Query
     */
    private function getSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel, $filter=''){

        $qb = $this->createQueryBuilder('dietrichliteraturreferenz');

        $qb->select("dietrichliteraturreferenz");
        $qb->join('dietrichliteraturreferenz.bandEntity', 'band');
        $qb->AndWhere('dietrichliteraturreferenz.sigle != (:empty)');
        $qb->AndWhere('band.bandkuerzel = (:kuerzel)');

        switch ($filter){
            case self::STATUS_FILTER_UNCLEAR:
                $qb->andWhere('dietrichliteraturreferenz.literaturreferenzbearbeitungsstatusEntity = '.self::BEARBEITUNGSSTATUS_UNKLAR);
                break;

            case self::STATUS_FILTER_NEW:
                $qb->andWhere('dietrichliteraturreferenz.literaturreferenzbearbeitungsstatusEntity = '.self::BEARBEITUNGSSTATUS_NEU);
                break;
        }

        $qb->orderBy('dietrichliteraturreferenz.sortableSigle');
        $qb->setParameter('empty', self::EMPTY_STRING_LITERAL);
        $qb->setParameter('kuerzel', $bandkuerzel);

        return $qb->getQuery();

    }

    /**
     * Returns a doctrine Query object which retrieves, when executed, all DietrichliteraturreferenzEntity objects
     * of the BandEntity which is identified by its bandkuerzel. The Query can then be used by a paginator to split
     * the query in usable page chunks.
     *
     * @param string $bandkuerzel
     * @return Query
     */
    public function getAllSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel)
    {
        return $this->getSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel);
    }

    /**
     * Returns a doctrine Query object which retrieves, when executed, DietrichliteraturreferenzEntity objects which
     * have their status set to 'neu' of the BandEntity which is identified by its bandkuerzel. The Query can then be
     * used by a paginator to split the query in usable page chunks.
     *
     * @param string $bandkuerzel
     * @return Query
     */
    public function getNewSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel)
    {
        return $this->getSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel, self::STATUS_FILTER_NEW);
    }


    /**
     * Returns a doctrine Query object which retrieves, when executed, DietrichliteraturreferenzEntity objects which
     * have their status set to 'unklar' of the BandEntity which is identified by its bandkuerzel. The Query can then be
     * used by a paginator to split the query in usable page chunks.
     *
     * @param string $bandkuerzel
     * @return Query
     */
    public function getUnclearSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel)
    {
        return $this->getSigledLiteraturreferenzenByBandkuerzelQuery($bandkuerzel, self::STATUS_FILTER_UNCLEAR);
    }

    /**
     * Tries to find the DietrichliteraturreferenzEntity, which is identified by the BandEntity it is contained in and
     * its sigle. The used BandEntity is identified by its bandkuerzel. If no DietrichliteraturreferenzEntity can be
     * found with the given parameters <code>null</code> is returned.
     *
     * @param string $bandkuerzel
     * @param string $sigle
     * @return DietrichliteraturreferenzEntity
     */
    public function findDietrichliteraturreferenzByBandkuerzelAndSigle($bandkuerzel, $sigle)
    {
        $entityManager = $this->_em;
        $query = $entityManager->createQuery(
            ' SELECT litref '
            .' FROM '.DietrichliteraturreferenzEntity::class.' litref '
            .' JOIN litref.bandEntity band'
            ." WHERE band.bandkuerzel = ?1"
            .' AND litref.sigle = ?2'
        )
            ->setParameter(1, $bandkuerzel)
            ->setParameter(2, $sigle)
            ->setMaxResults(1);

        try {
            return $query->getOneOrNullResult();
        } catch (NonUniqueResultException $e) {
            return null;
        }
    }

    /**
     * @param ArtikelEntity $artikel
     * @return NULL|DietrichliteraturreferenzEntity
     * @deprecated use Artikel.getDietrichliteraturreferenz() instead
     */
    public function findByArtikel(ArtikelEntity $artikel)
    {
        Preconditions::notNull($artikel->getBandEntity(), 'BandEntity');

        if ($artikel->getSigle() === null) {
            return null;
        }
        $bandkuerzel = $artikel->getBandEntity()->getBandkuerzel();
        $sigle = $artikel->getSigle();

        return $this->findDietrichliteraturreferenzByBandkuerzelAndSigle($bandkuerzel, $sigle);
    }

    /**
     * Tries to find the DietrichliteraturreferenzEntity, which is the next DietrichliteraturreferenzEntity after the given one,
     * where the ordering of the DietrichliteraturreferenzEntities is the dictionary ordering of the sortableSigle attribute.
     *
     * @param DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity
     * @param string $filter
     * @return DietrichliteraturreferenzEntity
     *
     */
    public function findNextDietrichliteraturreferenzOf(DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity, string $filter = self::STATUS_FILTER_ALL_PAGED) {
        return $this->findNextPrevDietrichliteraturreferenzOf($dietrichliteraturreferenzEntity, $filter, self::NEXT);
    }

    /**
     * Tries to find the DietrichliteraturreferenzEntity, which is the previous DietrichliteraturreferenzEntity after the given one,
     * where the ordering of the DietrichliteraturreferenzEntities is the dictionary ordering of the sortableSigle attribute.
     *
     * @param DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity
     * @param string $filter
     * @return DietrichliteraturreferenzEntity
     */
    public function findPreviousDietrichliteraturreferenzOf(DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity, string $filter = self::STATUS_FILTER_ALL_PAGED) {
        return $this->findNextPrevDietrichliteraturreferenzOf($dietrichliteraturreferenzEntity, $filter, self::PREV);
    }


    /**
     * A query Builder function to find either the next or previous LitRef Entry with given Filter.
     *
     * @param DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity
     * @param string $filter
     * @param int $nextPrev
     *
     * @return DietrichliteraturreferenzEntity
     */
    private function findNextPrevDietrichliteraturreferenzOf(DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity, string $filter, int $nextPrev)
    {

        $subQb = $this->createQueryBuilder('dietrichlitref_subquery');

        if ($nextPrev === self::NEXT) {
            $subQb->select('MIN(dietrichlitref_subquery.sortableSigle)');
            $subQb->where('dietrichlitref_subquery.sortableSigle > (:sortableSigle)');
        } elseif ($nextPrev === self::PREV) {
            $subQb->select('MAX(dietrichlitref_subquery.sortableSigle)');
            $subQb->where('dietrichlitref_subquery.sortableSigle < (:sortableSigle)');
        } else {
            throw new InvalidArgumentException('Neither NEXT nor PREV Constant used.');
        }

        $subQb->andWhere('dietrichlitref_subquery.bandEntity = (:bandEntity)');
        $subQb->andWhere('dietrichlitref_subquery.sortableSigle != (:empty)');

        switch ($filter) {
            case self::STATUS_FILTER_UNCLEAR:
                $subQb->andWhere('dietrichlitref_subquery.literaturreferenzbearbeitungsstatusEntity = '.self::BEARBEITUNGSSTATUS_UNKLAR);
                break;

            case self::STATUS_FILTER_NEW:
                $subQb->andWhere('dietrichlitref_subquery.literaturreferenzbearbeitungsstatusEntity = '.self::BEARBEITUNGSSTATUS_NEU);
                break;
        }

        $subQb->setMaxResults(1);

        $qb = $this->createQueryBuilder('dietrichliteraturreferenz');
        $qb->where('dietrichliteraturreferenz.bandEntity = (:bandEntity)');

        // The Brackets are needed since Doctrine doesnt set them automatically and the code breaks without them.
        $qb->andWhere($qb->expr()->eq('dietrichliteraturreferenz.sortableSigle', '('.$subQb->getDQL().')'));
        $qb->setParameter('bandEntity', $dietrichliteraturreferenzEntity->getBandEntity());
        $qb->setParameter('sortableSigle', $dietrichliteraturreferenzEntity->getSortableSigle());
        $qb->setParameter('empty', self::EMPTY_STRING_LITERAL);

        try {
            return $qb->getQuery()->getResult()[0];
        } catch (Exception $e) {
            return null;
        }
    }



    public function hasArticles(DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity)
    {
        $entityManager = $this->_em;
        $witness = $entityManager->getRepository(ArtikelEntity::class)
            ->findOneBy(['dietrichliteraturreferenzEntity' => $dietrichliteraturreferenzEntity]);

        return $witness !== null;
    }

    public function getArticleCount(DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity)
    {
        $entityManager = $this->_em;
        $qb = $entityManager->getRepository(ArtikelEntity::class)->findBy(
            ['dietrichliteraturreferenzEntity' => $dietrichliteraturreferenzEntity]
        );

        return count($qb);

    }

    public function findBandStates()
    {
        $queryString = "
			select
			band_origin.id as ".BandRepository::COL_BAND_ID.",
            band_origin.bandkuerzel as ".BandRepository::COL_BANDKUERZEL.",
			(not exists (
			  select * from band
				join dietrichliteraturreferenz
			    	on dietrichliteraturreferenz.fk_band = band.id
				where band.id = band_origin.id
				limit 1
			)) as ".BandRepository::COL_IS_EMPTY.",
			(exists (
			  select * from band
				join dietrichliteraturreferenz
			  	on dietrichliteraturreferenz.fk_band = band.id
			  join literaturreferenzbearbeitungsstatus
			  	on literaturreferenzbearbeitungsstatus.id = dietrichliteraturreferenz.fk_literaturreferenzbearbeitungsstatus
				where band.id = band_origin.id
					and literaturreferenzbearbeitungsstatus.bezeichnung = 'neu'
				limit 1
			)) as ".BandRepository::COL_HAS_MIN_ONE_NEW.",
			(exists (
			  select * from band
				join dietrichliteraturreferenz
			  	on dietrichliteraturreferenz.fk_band = band.id
			  join literaturreferenzbearbeitungsstatus
			  	on literaturreferenzbearbeitungsstatus.id = dietrichliteraturreferenz.fk_literaturreferenzbearbeitungsstatus
				where band.id = band_origin.id
					and literaturreferenzbearbeitungsstatus.bezeichnung = 'klar'
				limit 1
			)) as ".BandRepository::COL_HAS_MIN_ONE_CLEAR.",
			(exists (
			  select * from band
				join dietrichliteraturreferenz
			  	on dietrichliteraturreferenz.fk_band = band.id
			  join literaturreferenzbearbeitungsstatus
			  	on literaturreferenzbearbeitungsstatus.id = dietrichliteraturreferenz.fk_literaturreferenzbearbeitungsstatus
				where band.id = band_origin.id
					and literaturreferenzbearbeitungsstatus.bezeichnung = 'unklar'
				limit 1
			)) as ".BandRepository::COL_HAS_MIN_ONE_UNCLEAR."
			from band as band_origin
			order by band_origin.id
			limit 200
		";

        return $this->_em->getRepository(BandEntity::class)->findBandStates($queryString);
    }
}
