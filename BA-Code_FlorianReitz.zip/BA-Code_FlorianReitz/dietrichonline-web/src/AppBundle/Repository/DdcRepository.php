<?php
namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\DdcEntity;
use Doctrine\Common\Collections\Criteria;

/**
 * Custom repository class for ArtikelEntities
 * 
 * @author Kajetan Weiß (weiss@uni-trier.de)
 */
class DdcRepository extends EntityRepository {
    public function hasChildren(DdcEntity $ddc) {
        /* return true if we find a ddc which has given $ddc as parent */
        return $this->findOneBy(['parent' => $ddc]) !== null;
    }
    
    public function findRoots() {
        return $this->_em->createQuery('select ddc from '.DdcEntity::class.' ddc where ddc.parent is null')->execute();
    }
}
