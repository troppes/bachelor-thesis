<?php
namespace AppBundle\Repository;

use Doctrine\ORM\EntityRepository;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\KorrekturvorschlagstatusEntity;
use Doctrine\ORM\Query\ResultSetMapping;
use AppBundle\Entity\ArtikelEntity;
use AppBundle\Entity\KorrekturvorschlagEntity;
use AppBundle\Entity\LemmaEntity;

class KorrekturVorschlagRepository extends EntityRepository {
    const NEXT = 1;
    const PREV = -1;

    const CORRECTION_STATE_NEW = "neu";
    const CORRECTION_STATE_BLURRY = "unklar";
    const CORRECTION_STATE_CLEAR = "klar";
    
    protected function findNextPrevKorrekturvorschlagOf(KorrekturvorschlagEntity $korrekturvorschlag, $statusfilter, $nextPrevFlag) {
        switch ($nextPrevFlag) {
            case self::NEXT: {
                $operator = '>';
                $sort = 'asc';
            } break;
            
            case self::PREV: {
                $operator = '<';
                $sort = 'desc';
            } break;
            
            default: {
                throw new \Exception("undefined nextPrevFlag!");
            }
        }
        /* first check if we find entities with the same timestamp. 
         * If so, we return the entity with the consecutive greater/lesser id if present.
         * Else, see else Block. */
        $query = $this->_em->createQuery('
            select korrekturvorschlag 
            from '.KorrekturvorschlagEntity::class.' korrekturvorschlag
            join korrekturvorschlag.korrekturvorschlagstatusEntity korrekturvorschlagstatus
            join korrekturvorschlag.artikelEntity artikel
            join artikel.bandEntity band
            where korrekturvorschlag.timestamp = :currentKorVorTimestamp
            and korrekturvorschlag.id '.$operator.' :currentKorVorId
            and korrekturvorschlagstatus.bezeichnung = :statusfilter
            and band = :band
            order by korrekturvorschlag.id '.$sort
        )
        ->setParameter(':currentKorVorTimestamp', $korrekturvorschlag->getTimestamp())
        ->setParameter(':currentKorVorId', $korrekturvorschlag->getId())
        ->setParameter(':statusfilter', $statusfilter)
        ->setParameter(':band', $korrekturvorschlag->getArtikelEntity()->getBandEntity())
        ->setMaxResults(1);
        $result = $query->getOneOrNullResult();
        if ($result) { 
            return $result; 
        } else {
            // return the entity with the consecutive greater/lesser timestamp.
            $query = $this->_em->createQuery('
                select korrekturvorschlag
                from '.KorrekturvorschlagEntity::class.' korrekturvorschlag
                join korrekturvorschlag.korrekturvorschlagstatusEntity korrekturvorschlagstatus
                join korrekturvorschlag.artikelEntity artikel
                join artikel.bandEntity band
                where korrekturvorschlag.timestamp '.$operator.' :currentKorVorTimestamp
                and korrekturvorschlagstatus.bezeichnung = :statusfilter
                and band = :band
                order by korrekturvorschlag.timestamp '.$sort.', korrekturvorschlag.id '.$sort
            )
            ->setParameter(':currentKorVorTimestamp', $korrekturvorschlag->getTimestamp())
            ->setParameter(':statusfilter', $statusfilter)
            ->setParameter(':band', $korrekturvorschlag->getArtikelEntity()->getBandEntity())
            ->setMaxResults(1);
            return $query->getOneOrNullResult();
        }
    }
    
    public function findPreviousKorrekturvorschlagOf(KorrekturvorschlagEntity $korrekturvorschlag, $statusfilter) {
        return $this->findNextPrevKorrekturvorschlagOf($korrekturvorschlag, $statusfilter, self::PREV);
    }
    
    public function findNextKorrekturvorschlagOf(KorrekturvorschlagEntity $korrekturvorschlag, $statusfilter) {
        return $this->findNextPrevKorrekturvorschlagOf($korrekturvorschlag, $statusfilter, self::NEXT);
    }
    
    public function findByBandkuerzelAndFilter($bandkuerzel, $statusFilter) {
        $queryString = "
            select 
                korrekturvorschlag.id as korrekturvorschlag_id,
                korrekturvorschlag.titel as korrekturvorschlag_titel,
                korrekturvorschlag.autor as korrekturvorschlag_autor,
                korrekturvorschlag.timestamp as korrekturvorschlag_timestamp,
                artikel.id as artikel_id,
                artikel.titel as artikel_titel,
                artikel.titel_mit_lemma as artikel_titel_mit_lemma,
                artikel.autor as artikel_autor,
                lemma.id as lemma_id,
                lemma.original_bezeichnung as lemma_original_bezeichnung,
                lemma.erweiterung as lemma_erweiterung,
                lemma.original_homonym_zusatz as lemma_original_homonym_zusatz,
                lemma.neuer_homonym_zusatz as lemma_neuer_homonym_zusatz,
                korrekturvorschlagstatus.id as korrekturvorschlagstatus_id,
                korrekturvorschlagstatus.bezeichnung as korrekturvorschlagstatus_bezeichnung
            from korrekturvorschlag
                join artikel on artikel.id = korrekturvorschlag.fk_artikel 
                join band on band.id = artikel.fk_band
                join lemma on lemma.id = artikel.fk_lemma
                join korrekturvorschlagstatus on korrekturvorschlagstatus.id = korrekturvorschlag.fk_korrekturvorschlagstatus
            where
                band.bandkuerzel = :bandkuerzel
                and korrekturvorschlagstatus.bezeichnung = :statusFilter
            order by timestamp asc
        ";
        
        $rsltmpng = new ResultSetMapping();
        $rsltmpng->addEntityResult(KorrekturvorschlagEntity::class, 'korrekturvorschlag')
            ->addFieldResult('korrekturvorschlag', 'korrekturvorschlag_id', 'id')
            ->addFieldResult('korrekturvorschlag', 'korrekturvorschlag_titel', 'titel')
            ->addFieldResult('korrekturvorschlag', 'korrekturvorschlag_autor', 'autor')
            ->addFieldResult('korrekturvorschlag', 'korrekturvorschlag_timestamp', 'timestamp')
        ->addJoinedEntityResult(ArtikelEntity::class, 'artikel', 'korrekturvorschlag', 'artikelEntity')
            ->addFieldResult('artikel', 'artikel_id', 'id')
            ->addFieldResult('artikel', 'artikel_titel', 'titel')
            ->addFieldResult('artikel', 'artikel_titel_mit_lemma', 'titelMitLemma')
            ->addFieldResult('artikel', 'artikel_autor', 'autor')
        ->addJoinedEntityResult(LemmaEntity::class, 'lemma', 'artikel', 'lemmaEntity')
            ->addFieldResult('lemma', 'lemma_id', 'id')
            ->addFieldResult('lemma', 'lemma_original_bezeichnung', 'originalBezeichnung')
            ->addFieldResult('lemma', 'lemma_erweiterung', 'erweiterung')
            ->addFieldResult('lemma', 'lemma_original_homonym_zusatz', 'originalHomonymZusatz')
            ->addFieldResult('lemma', 'lemma_neuer_homonym_zusatz', 'neuerHomonymZusatz')
        ->addJoinedEntityResult(KorrekturvorschlagstatusEntity::class, 'korrekturvorschlagstatus', 'korrekturvorschlag', 'korrekturvorschlagstatusEntity')
            ->addFieldResult('korrekturvorschlagstatus', 'korrekturvorschlagstatus_id', 'id')
            ->addFieldResult('korrekturvorschlagstatus', 'korrekturvorschlagstatus_bezeichnung', 'bezeichnung');
        ;
        
        $query = $this->_em->createNativeQuery($queryString, $rsltmpng);
        $query->setParameter('bandkuerzel', $bandkuerzel);
        $query->setParameter('statusFilter', $statusFilter);
        
        return $query->getResult();
    }
    
    public function findBandStates() {
        $queryString = "
			select
			band_origin.id as ".BandRepository::COL_BAND_ID.",
            band_origin.bandkuerzel as ".BandRepository::COL_BANDKUERZEL.",
			(not exists (
			  select * from band
				join artikel
			    	on artikel.fk_band = band.id
                join korrekturvorschlag
                    on korrekturvorschlag.fk_artikel = artikel.id
				where band.id = band_origin.id
				limit 1
			)) as ".BandRepository::COL_IS_EMPTY.",
			(exists (
			  select * from band
				join artikel
			    	on artikel.fk_band = band.id
                join korrekturvorschlag
                    on korrekturvorschlag.fk_artikel = artikel.id
    			join korrekturvorschlagstatus
    			  	on korrekturvorschlagstatus.id = korrekturvorschlag.fk_korrekturvorschlagstatus
				where band.id = band_origin.id
					and korrekturvorschlagstatus.bezeichnung = '" . self::CORRECTION_STATE_NEW . "'
				limit 1
			)) as ".BandRepository::COL_HAS_MIN_ONE_NEW.",
			(exists (
			  select * from band
				join artikel
			    	on artikel.fk_band = band.id
                join korrekturvorschlag
                    on korrekturvorschlag.fk_artikel = artikel.id
    			join korrekturvorschlagstatus
    			  	on korrekturvorschlagstatus.id = korrekturvorschlag.fk_korrekturvorschlagstatus
				where band.id = band_origin.id
					and korrekturvorschlagstatus.bezeichnung = '" . self::CORRECTION_STATE_CLEAR . "'
				limit 1
			)) as ".BandRepository::COL_HAS_MIN_ONE_CLEAR.",
			(exists (
			  select * from band
				join artikel
			    	on artikel.fk_band = band.id
                join korrekturvorschlag
                    on korrekturvorschlag.fk_artikel = artikel.id
    			join korrekturvorschlagstatus
    			  	on korrekturvorschlagstatus.id = korrekturvorschlag.fk_korrekturvorschlagstatus
				where band.id = band_origin.id
					and korrekturvorschlagstatus.bezeichnung = '" . self::CORRECTION_STATE_BLURRY . "'
				limit 1
			)) as ".BandRepository::COL_HAS_MIN_ONE_UNCLEAR."
			from band as band_origin
			order by band_origin.id
			limit 200
		";
        
        return $this->_em->getRepository(BandEntity::class)->findBandStates($queryString);
    }

    public function findToDoKorrekturvorschlaege()
    {
        $statusRepo =
            $this
            ->_em
            ->getRepository(KorrekturvorschlagstatusEntity::class);

        $query =
            $this
            ->_em
            ->createQuery(
                "SELECT krrvrschlg
                FROM " . KorrekturvorschlagEntity::class . " krrvrschlg
                JOIN krrvrschlg.korrekturvorschlagstatusEntity status
                WHERE status.bezeichnung IN ('" . self::CORRECTION_STATE_NEW . "', '" . self::CORRECTION_STATE_BLURRY . "')"
            );

        return $query->getResult();
    }
}

