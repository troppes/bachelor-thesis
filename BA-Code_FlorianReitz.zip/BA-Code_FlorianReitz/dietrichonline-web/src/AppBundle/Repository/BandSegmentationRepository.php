<?php

namespace AppBundle\Repository;

use AppBundle\Controller\BandSegmentation\BandSegmentationController;
use AppBundle\Entity\SegmentationsFehlerEntity;
use AppBundle\Util\Preconditions;
use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\Query;
use Doctrine\ORM\Query\Expr\Join;
use Exception;

class BandSegmentationRepository
    extends EntityRepository
{

    /**
     * A function to get a Query with all the Errors from a specific Band
     *
     * @param string $bandNr
     *
     * @return Query
     */
    public function getAllErrorsQueryByBand(string $bandNr)
    {

        $queryBuilder = $this->createQueryBuilder('errorList');

        $queryBuilder->addSelect('rptMap');
        $queryBuilder->leftJoin('errorList.fehlerRPTMapsEntities', 'rptMap', Join::ON);

        $queryBuilder->andWhere('errorList.band = (:bandNr)');
        $queryBuilder->andWhere('errorList.severity > 3');
        $queryBuilder->setParameter('bandNr', $bandNr);
        $queryBuilder->orderBy('errorList.eid');

        return $queryBuilder->getQuery();
    }


    /**
     * A function to get a Query with all the Errors from a specific Band with a specific error Code
     *
     * @param string $filter
     * @param $bandNr
     *
     * @return Query
     */
    public function getAllErrorsQueryByBandWithFilter(string $filter, string $bandNr)
    {
        $queryBuilder = $this->createQueryBuilder('errorList');
        $queryBuilder->join('errorList.fehlerRPTMapsEntities', 'rptMap', Join::LEFT_JOIN);
        $queryBuilder->andWhere('errorList.band = (:bandNr)');
        $queryBuilder->andWhere('errorList.severity > 3');
        $queryBuilder->andWhere('rptMap.id = (:errorCode)');
        $queryBuilder->setParameter('bandNr', $bandNr);
        $queryBuilder->setParameter('errorCode', $filter);
        $queryBuilder->orderBy('errorList.eid');


        return $queryBuilder->getQuery();
    }

    /**
     * A function to get the Page where the specific entry is found
     *
     * @param string $eid
     *
     * @return int
     * @throws NonUniqueResultException
     */
    public function getPageNumberByEntry(string $eid): int
    {
        $queryBuilder = $this->createQueryBuilder('getEntity');

        $queryBuilder->where('getEntity.eid = (:eid)');
        $queryBuilder->setParameter('eid', $eid);


        /** @var SegmentationsFehlerEntity $entity */
        $entity = $queryBuilder->getQuery()->getOneOrNullResult();

        Preconditions::notNull($entity, 'ErrorListEntity');

        $qb = $this->createQueryBuilder('errorList');

        $qb->select("count(errorList.eid)");
        $qb->where('errorList.band = (:band)');
        $qb->andWhere('errorList.severity > 3');
        $qb->andWhere('errorList.eid < (:eid)');
        $qb->setParameter('band', $entity->getBand());
        $qb->setParameter('eid', $entity->getEid());


        try {
            // +1 for it-index (starts with 0)
            return ceil(
                ($qb->getQuery()->getSingleScalarResult() + 1) / BandSegmentationController::DEFAULT_ITEMS_PER_PAGE
            );
        } catch (Exception $e) {
            return BandSegmentationController::DEFAULT_PAGE_INDEX;
        }
    }

    /**
     * A function to get all the Bands with errors
     *
     * @return array
     */
    public function getBandWithErrors()
    {
        $queryBuilder = $this->createQueryBuilder('errorList');
        $queryBuilder->select('errorList.band');
        $queryBuilder->distinct(true);
        $queryBuilder->orderBy('errorList.band');

        return $queryBuilder->getQuery()->getResult();
    }

}
