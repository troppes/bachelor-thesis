<?php

namespace AppBundle\Repository;

use AppBundle\Entity\LemmaEntity;
use Doctrine\ORM\AbstractQuery;
use Doctrine\ORM\Query\Expr\Join;
use Doctrine\ORM\QueryBuilder;
use Elasticsearch\ClientBuilder;
use InvalidArgumentException;

class LemmaRepository
    extends AutocompletableRepository
{
    const STATUS_FILTER_ALLE   = 'alle';
    const STATUS_FILTER_KLAR   = 'klar';
    const STATUS_FILTER_UNKLAR = 'unklar';
    const STATUS_FILTER_NEU    = 'neu';
    const STATUS_FILTER_NO_DDC = 'kein DDC';

    const STATUS_FILTER_LIST = [
        self::STATUS_FILTER_ALLE,
        self::STATUS_FILTER_KLAR,
        self::STATUS_FILTER_UNKLAR,
        self::STATUS_FILTER_NEU,
        self::STATUS_FILTER_NO_DDC,
    ];

    /** @var int Get previous Lemma API code */
    const PREV = 0;
    /** @var int Get next Lemma API code */
    const NEXT = 1;

    const FIND_NEXT_PREVIOUS_LIMIT = 100;

    /**
     * Method for generating an SQL Statement to find the previous or next ID with a filter in Place
     *
     * @param int $prevOrNext See the constants for Values
     * @param LemmaEntity $lemmaEntity Lemma Entity to get the Data from.
     * @param string $status The Status of the Entity
     *
     * @return LemmaEntity|null Returns either the LemmaEntity or NULL if none was found
     * @see self::PREV
     * @see self::Next
     */
    public function findNextPrevious(int $prevOrNext, LemmaEntity $lemmaEntity, string $status)
    {
        $queryBuilder = $this->createQueryBuilder('lemma');

        if ($prevOrNext === self::PREV) {
            $queryBuilder->andWhere('lemma.originalBezeichnung <= (:lemmaOriginalBezeichnung)');
        } elseif ($prevOrNext === self::NEXT) {
            $queryBuilder->andWhere('lemma.originalBezeichnung >= (:lemmaOriginalBezeichnung)');
        } else {
            throw new InvalidArgumentException(sprintf('Unknown value for prevOrNext type <%d>.', $prevOrNext));
        }

        $originalBezeichnung = $lemmaEntity->getOriginalBezeichnung();
        $queryBuilder->setParameter('lemmaOriginalBezeichnung', $originalBezeichnung);

        $queryBuilder->andWhere('lemma.originalBezeichnung is not null');

        $queryBuilder->andWhere('lemma.ist_geloescht = false');

        $this->produceFilterSql($status, $queryBuilder);

        if ($prevOrNext === self::PREV) {
            $queryBuilder->orderBy('lemma.bezeichnung', 'DESC');
            $queryBuilder->addOrderBy('lemma.id', 'DESC');
        } elseif ($prevOrNext === self::NEXT) {
            $queryBuilder->orderBy('lemma.bezeichnung', 'ASC');
            $queryBuilder->addOrderBy('lemma.id', 'ASC');
        }

        $queryBuilder->setMaxResults(self::FIND_NEXT_PREVIOUS_LIMIT);

        $results = $queryBuilder->getQuery()->getResult();

        $resultsSize = count($results);

        /** @var LemmaEntity[] $results */
        for ($i = 0; $i < ($resultsSize - 1); ++$i) {
            if ($results[$i]->getId() === $lemmaEntity->getId()) {
                $nextLemmaEntity = $results[$i + 1];

                return $nextLemmaEntity;
            }
        }

        return null;
    }

    /**
     * Finds the next lemma entity to a given lemma entity (alphabetically ordered)
     *
     * @param LemmaEntity $lemmaEntity
     * @param string $status The String of the status
     *
     * @return NULL|LemmaEntity
     */
    public function findNext(LemmaEntity $lemmaEntity, string $status)
    {
        return $this->findNextPrevious(self::NEXT, $lemmaEntity, $status);
    }

    /**
     * Finds the previous lemma entity to a given lemma entity (alphabetically ordered)
     *
     * @param LemmaEntity $lemmaEntity
     * @param string $status The String of the status
     *
     * @return NULL|LemmaEntity
     */
    public function findPrevious(LemmaEntity $lemmaEntity, string $status)
    {
        return $this->findNextPrevious(self::PREV, $lemmaEntity, $status);
    }

    /**
     * @param string $filter a STATUS_FILTER_... value
     * @param QueryBuilder $queryBuilder The QueryBuilder to add the Value to !IMPORTANT! The Lemma Table needs to be
     *                      called lemma
     *
     * @see self::STATUS_FILTER_KLAR
     * @see self::STATUS_FILTER_UNKLAR
     * @see self::STATUS_FILTER_NEU
     * @see self::STATUS_FILTER_ALLE
     * @see self::STATUS_FILTER_NO_DDC
     */
    protected function produceFilterSql(string $filter, QueryBuilder $queryBuilder)
    {
        switch ($filter) {
            case self::STATUS_FILTER_KLAR:
                $queryBuilder->join('lemma.lemmabearbeitungsstatusEntity', 'lemmabearbeitungsstatus', Join::ON)
                    ->andWhere("lemmabearbeitungsstatus.bezeichnung = 'klar'");
                break;

            case self::STATUS_FILTER_UNKLAR:
                $queryBuilder->join('lemma.lemmabearbeitungsstatusEntity', 'lemmabearbeitungsstatus', Join::ON)
                    ->andWhere("lemmabearbeitungsstatus.bezeichnung = 'unklar'");
                break;

            case self::STATUS_FILTER_NEU:
                $queryBuilder->join('lemma.lemmabearbeitungsstatusEntity', 'lemmabearbeitungsstatus', Join::ON)
                    ->andWhere("lemmabearbeitungsstatus.bezeichnung = 'neu'");
                break;

            case self::STATUS_FILTER_NO_DDC:
                $subQ = $this->createQueryBuilder('sub_lemma');
                $subQ->select('sub_lemma.id');
                $subQ->join('sub_lemma.lemmaGNDEntities', 'sub_lemma_gnd', JOIN::ON);
                $subQ->join('sub_lemma_gnd.gndEntity', 'sub_gnd', JOIN::ON);
                $subQ->join('sub_gnd.gndDdcEntities', 'sub_gnd_ddc', JOIN::ON);

                $queryBuilder->andWhere($queryBuilder->expr()->notIn('lemma.id', $subQ->getDQL()));

                break;

            case self::STATUS_FILTER_ALLE:
                // no need to set filter
                break;

            default:
                throw new InvalidArgumentException('Unknown filter with id :'.$filter);
        }
    }


    /**
     * @param string $character desired alphabetic prefix character or 'not_a - z' for others
     * @param string $filter desired filter
     *
     * @return array
     * @see self::produceFilterSql()
     */
    public function findByCharacter(string $character, string $filter)
    {
        $myCert = 'certs/ca.crt';

        $clientBuilder = ClientBuilder::create()->setHosts(
            ['https://bib55.uni-trier.de:9200', 'https://bib55.uni-trier.de:9201']
        );
        $client        = $clientBuilder->setSSLVerification($myCert)->setApiKey(
            'gPQyZ28BZIqHlxQHP_3u',
            'dMouSGTHQBmkRyx9mBZoBg'
        )->build();

        $params = [
            'index' => 'dietrich_lemma',
            'body' => [
                'size' => 50000, // Max Value, check Wiki for more information
                'sort' => ['bezeichnung.keyword' => 'asc'],
            ],

        ];

        $mustNotQueries = [];
        $filters        = [];
        $mustQueries    = [];

        if ($character === LemmaEntity::NOT_A_TO_Z_CHARACTER) {
            $mustQueries[] = ['regexp' => ['bezeichnung.keyword' => ['value' => '@&~(^[a-zA-Z].+)', 'flags' => 'ALL']]];
            $filters[]     = ['term' => ['ist_geloescht' => false]];
        } elseif ($character === LemmaEntity::DELETED) {
            $filters[] = ['term' => ['ist_geloescht' => true]];
        } else {
            $mustQueries = ['prefix' => ['bezeichnung.keyword' => "$character"]];
            $filters[]   = ['term' => ['ist_geloescht' => false]];
        }

        switch ($filter) {
            case self::STATUS_FILTER_KLAR:
                $filters[] = ['term' => ['bstatusbezeichnung' => 'klar']];
                break;

            case self::STATUS_FILTER_UNKLAR:
                $filters[] = ['term' => ['bstatusbezeichnung' => 'unklar']];
                break;

            case self::STATUS_FILTER_NEU:
                $filters[] = ['term' => ['bstatusbezeichnung' => 'neu']];
                break;

            case self::STATUS_FILTER_NO_DDC:
                $mustNotQueries = ['exists' => ['field' => "ddc_entries"]];
                break;

            case self::STATUS_FILTER_ALLE:
                // no need to set filter
                break;

            default:
                throw new InvalidArgumentException('Unknown filter with id :'.$filter);
        }

        $params['body']['query']['bool']['must']     = $mustQueries;
        $params['body']['query']['bool']['must_not'] = $mustNotQueries;
        $params['body']['query']['bool']['filter']   = $filters;

        return $client->search($params)['hits']['hits'];
    }

    public function findHomonymList(LemmaEntity $lemma)
    {

        $queryBuilder = $this->createQueryBuilder('lemma');
        $queryBuilder->where('lemma.originalBezeichnung = (:originalBezeichnung)');
        $queryBuilder->andWhere('lemma.ist_geloescht = false');
        $queryBuilder->setParameter('originalBezeichnung', $lemma->getOriginalBezeichnung());

        return $queryBuilder->getQuery()->getResult();
    }

    public function findByIds(array $ids)
    {
        return $this->findByCommaSeperatedIds(implode(',', $ids));
    }

    public function findByCommaSeperatedIds(string $lemmaIdsCommaSeperated)
    {
        $queryBuilder = $this->createQueryBuilder('lemma')
            ->where('lemma.id in ('.$lemmaIdsCommaSeperated.')');

        return $queryBuilder->getQuery()->getResult();
    }
}
