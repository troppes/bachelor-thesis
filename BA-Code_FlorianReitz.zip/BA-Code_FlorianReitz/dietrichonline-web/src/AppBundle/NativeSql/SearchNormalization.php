<?php

namespace AppBundle\NativeSql;

/**
 * Class SearchNormalization
 *
 * @package AppBundle\NativeSql
 * @author Martin Kock <kock@uni-trier.de>
 */
class SearchNormalization
{
    const SUPPORTED_SYMBOL_ASTERISK = '*';
    const SUPPORTED_SYMBOL_DOUBLE_QUOTE = '"';
    const SYMBOLS_TO_CLEAN = '/[!$%^&()+|~=`{}\[\]:     ;\'<>?,.\\/]/';
    const SPACE = ' ';
    const NO_SPACE = '';

    /**
     * Returns the string where all consecutive * characters are replaced by only one * character.
     *
     * @param string $string The string to clean
     *
     * @return string The cleaned string
     */
    public static function getConsecutiveAsteriskCleanedString($string): string
    {
        $string = self::getEmptyNullString($string);

        return trim(preg_replace('/\*{2,}/u', '*', $string));
    }

    /**
     * Returns the given string with one space after every symbol.
     *
     * @param string $string The string to add the spaces.
     *
     * @return string The string with one space after every symbol.
     */
    public static function getStringWithSpaceAfterEverySearchSymbol($string): string
    {
        $string = self::getConsecutiveAsteriskCleanedString($string);

        $maybeMultiSpacesString = trim(preg_replace(self::SYMBOLS_TO_CLEAN, '$0 ', $string));
        $cleanedString = preg_replace('!\s+!', self::SPACE, $maybeMultiSpacesString);

        return trim($cleanedString);
    }

    /**
     * Returns a <code>null</code> cleaned string.
     *
     * @param string $string The given string.
     *
     * @return string An empty string if the given string is <code>null</code>, otherwise the given string.
     */
    private static function getEmptyNullString($string): string
    {
        if ($string === null) {
            $string = '';
        }

        return $string;
    }

    /**
     * Returns the given string trimmed and with the replacement of multi inline spaces by one space.
     *
     * @param string $string The string to search for multiple spaces
     *
     * @return string The cleaned string.
     */
    private static function getSpaceReducedString(string $string): string
    {
        return trim(preg_replace('/\s+/', self::SPACE, $string));
    }
}
