<?php

namespace AppBundle\NativeSql;

use InvalidArgumentException;

class UserSearchSqlBuilder
{

    private $fullQuery = [];

    /**
     * UserSearchSqlBuilder constructor.
     * <p>
     * <strong>Note!</strong>
     * The argument <code>$query</code> has some dependencies to
     * <code>AutocompletableRepository::SEARCH_TERM_PARAM_KEY</code>. If you change the name of the argument, the user
     * suggestion won't work anymore. We have to spot all dependencies first before we can rework it.
     *
     * @param array $query An array of UserSearchItems
     */
    public function __construct(array $query)
    {
        foreach ($query as $userSearchItem) { //reverse array for building the junktors right
            /* @var $userSearchItem UserSearchItem */
            $this->addJunktor($userSearchItem);
        }
    }

    /**
     * @return array
     */
    public function getFullQuery(): array
    {
        return $this->fullQuery;
    }

    private function addDdc(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "ddc_entries.ddc_notation",
                ],
                "lenient" => true,
            ],
        ];
    }


    private function addGnd(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "gnd_entries.gnd_schlagwort",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addDietrichliteraturreferenz(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "litref_dietrichbezeichnung",
                ],
                "lenient" => true,
            ],
        ];
    }


    private function addNormliteraturreferenz(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "normlitref_entries.normlitref_kvk_bezeichnung",
                    "normlitref_entries.normlitref_zdb_bezeichnung",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addLemma(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "lemma_bezeichnung",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addArtikel(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "artikel_titel",
                    "lemma_bezeichnung",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addSigle(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "artikel_sigle",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addTypeID(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'match' => [
                'artikel_id' => [
                    'query' => $userSearchItem->getValue(),
                    "lenient" => true,
                ],
            ],
        ];
    }


    private function addAutor(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "artikel_autor",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addBand(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'match' => [
                'band_bandkuerzel' => [
                    'query' => $userSearchItem->getValue(),
                    "lenient" => true,
                ],
            ],
        ];
    }

    private function addFullSearch(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'query_string' => [
                'query' => $userSearchItem->getValue(),
                'fields' => [
                    "artikel_titel",
                    "lemma_bezeichnung",
                    "artikel_autor",
                    "artikel_id",
                    "artikel_sigle",
                    "ddc_entries.ddc_notation",
                    "ddc_entries.ddc_schlagwort",
                    "gnd_entries.gnd_nummer",
                    "gnd_entries.gnd_schlagwort",
                    "normlitref_entries.normlitref_zdb_bezeichnung",
                    "normlitref_entries.normlitref_kvk_bezeichnung",
                ],
                "lenient" => true,
            ],
        ];
    }

    private function addVonJahr(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'range' => [
                'artikel_erstmoegliches_erscheinungsjahr' => [
                    "gte" => $userSearchItem->getValue(),
                ],
            ],
        ];
    }

    private function addBisJahr(UserSearchItem $userSearchItem)
    {
        return $subQuery = [
            'range' => [
                'artikel_letztmoegliches_erscheinungsjahr' => [
                    "lte" => $userSearchItem->getValue(),
                ],
            ],
        ];
    }


    private function addTypeValue(UserSearchItem $userSearchItem)
    {
        switch ($userSearchItem->getType()) {
            case UserSearchItem::TYPE_ID:
                return $this->addTypeID($userSearchItem);
                break;

            case UserSearchItem::TYPE_ARTIKEL:
                return $this->addArtikel($userSearchItem);
                break;

            case UserSearchItem::TYPE_AUTOR:
                return $this->addAutor($userSearchItem);
                break;

            case UserSearchItem::TYPE_BAND:
                return $this->addBand($userSearchItem);
                break;

            case UserSearchItem::TYPE_DDC:
                return $this->addDdc($userSearchItem);
                break;

            case UserSearchItem::TYPE_GND:
                return $this->addGnd($userSearchItem);
                break;

            case UserSearchItem::TYPE_LEMMA:
                return $this->addLemma($userSearchItem);
                break;

            case UserSearchItem::TYPE_SIGLE:
                return $this->addSigle($userSearchItem);
                break;

            case UserSearchItem::TYPE_DIETRICHLITERATURREFERENZ:
                return $this->addDietrichliteraturreferenz($userSearchItem);
                break;

            case UserSearchItem::TYPE_NORMLITERATURREFERENZ:
                return $this->addNormliteraturreferenz($userSearchItem);
                break;

            case UserSearchItem::TYPE_VON_JAHR:
                return $this->addVonJahr($userSearchItem);
                break;

            case UserSearchItem::TYPE_BIS_JAHR:
                return $this->addBisJahr($userSearchItem);
                break;
            case UserSearchItem::TYPE_FULL_SEARCH:
                return $this->addFullSearch($userSearchItem);
                break;

            default:
                throw new InvalidArgumentException(
                    'Suchtyp mit id "'.$userSearchItem->getType().'" ist nicht definiert.'
                );
        }
    }

    private function addJunktor(UserSearchItem $userSearchItem)
    {
        switch ($userSearchItem->getJunktor()) {
            case UserSearchItem::JUNKTOR_NO:
                $this->fullQuery = [
                    'bool' => [
                        'must' => [
                            $this->addTypeValue($userSearchItem),
                        ],
                    ],
                ];
                break;
            case UserSearchItem:: JUNKTOR_AND:
                $this->fullQuery = [
                    'bool' => [
                        'must' => [
                            $this->addTypeValue($userSearchItem),
                            $this->fullQuery,
                        ],
                    ],
                ];
                break;
            case UserSearchItem:: JUNKTOR_OR:
                $this->fullQuery = [
                    'bool' => [
                        'should' => [
                            $this->addTypeValue($userSearchItem),
                            $this->fullQuery,
                        ],
                    ],
                ];
                break;
            case UserSearchItem::JUNKTOR_AND_NOT:
                $this->fullQuery = [
                    'bool' => [
                        'must_not' => [
                            $this->addTypeValue($userSearchItem),
                            $this->fullQuery,
                        ],
                    ],
                ];
                break;
            default:
                throw new InvalidArgumentException(
                    'Junktor mit id "'.$userSearchItem->getJunktor().'" ist nicht definiert.'
                );
        }
    }
}
