<?php

namespace AppBundle\NativeSql;

use AppBundle\Util\Preconditions;
use InvalidArgumentException;

/**
 * Class UserSearchItem represents an item for basic search input of an user.
 *
 * @package AppBundle\NativeSql
 */
class UserSearchItem
{
    // Type constants
    const TYPE_ID                        = 13;
    const TYPE_NONE                      = -1;
    const TYPE_LEMMA                     = 1;
    const TYPE_GND                       = 2;
    const TYPE_ARTIKEL                   = 3;
    const TYPE_AUTOR                     = 4;
    const TYPE_DDC                       = 5;
    const TYPE_SIGLE                     = 6;
    const TYPE_BAND                      = 7;
    const TYPE_DIETRICHLITERATURREFERENZ = 8;
    const TYPE_NORMLITERATURREFERENZ     = 9;
    const TYPE_VON_JAHR                  = 10;
    const TYPE_BIS_JAHR                  = 11;
    const TYPE_FULL_SEARCH               = 12;


    // Junktor constants
    const JUNKTOR_NONE    = -1;
    const JUNKTOR_NO      = 1;
    const JUNKTOR_AND     = 2;
    const JUNKTOR_OR      = 3;
    const JUNKTOR_AND_NOT = 4;

    protected $junktor;
    protected $type;
    protected $value;

    /**
     * UserSearchItem constructor.
     *
     * @param int $junktor
     * @param int $type
     * @param mixed $value
     *
     * @throws InvalidArgumentException if the junktor is null, empty or not valid
     * @throws InvalidArgumentException if the type is null, empty or not valid
     */
    public function __construct($junktor = self::JUNKTOR_NO, $type = null, $value = null)
    {
        Preconditions::notEmpty($junktor, 'junktor');
        Preconditions::notEmpty($type, 'type');

        if (!$this->isValidJunktor($junktor)) {
            throw new InvalidArgumentException(sprintf("Given junktor '%s' is unknown.", $junktor));
        }

        if (!$this->isValidType($type)) {
            throw new InvalidArgumentException(sprintf("Given type '%s' is unknown.", $type));
        }

        $this->junktor = (int)$junktor;
        $this->type    = (int)$type;
        $this->value   = $value;
    }

    public function getJunktor(): int
    {
        return $this->junktor;
    }

    /**
     * Sets the given junktor.
     *
     * @param int $junktor
     *
     * @throws InvalidArgumentException If the given junktor is unknown.
     */
    public function setJunktor(int $junktor)
    {
        if (!$this->isValidJunktor($junktor)) {
            throw new InvalidArgumentException(sprintf("Given junktor '%s' is unknown.", $junktor));
        }

        $this->junktor = $junktor;
    }

    public function getType(): int
    {
        return $this->type;
    }

    public function getValue()
    {
        return $this->value;
    }

    /**
     * Returns the validated state of <code>$this->value</code>.
     *
     * @return bool Returns <code>true</code> if <code>$this->value</code> is <code>null</code>, otherwise
     *     <code>false</code>.
     */
    public function isEmpty(): bool
    {
        return $this->value === null;
    }

    public function isValid(): bool
    {
        $typeIsValid    = $this->isValidType($this->type);
        $junktorIsValid = $this->isValidJunktor($this->junktor);

        return $typeIsValid && $junktorIsValid;
    }

    private function isValidType($type): bool
    {
        return $type !== null
            && ($type === self::TYPE_NONE
                || $type === self::TYPE_ID
                || $type === self::TYPE_LEMMA
                || $type === self::TYPE_GND
                || $type === self::TYPE_ARTIKEL
                || $type === self::TYPE_AUTOR
                || $type === self::TYPE_DDC
                || $type === self::TYPE_SIGLE
                || $type === self::TYPE_BAND
                || $type === self::TYPE_DIETRICHLITERATURREFERENZ
                || $type === self::TYPE_NORMLITERATURREFERENZ
                || $type === self::TYPE_VON_JAHR
                || $type === self::TYPE_BIS_JAHR
                || $type === self::TYPE_FULL_SEARCH);
    }

    private function isValidJunktor($junktor): bool
    {
        return $junktor !== null
            && ($junktor === self::JUNKTOR_NONE
                || $junktor === self::JUNKTOR_NO
                || $junktor === self::JUNKTOR_AND
                || $junktor === self::JUNKTOR_OR
                || $junktor === self::JUNKTOR_AND_NOT);
    }
}
