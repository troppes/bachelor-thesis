<?php
/**
 * Kajetan Weiss
 */

namespace AppBundle\Command;


use AppBundle\Entity\KorrekturvorschlagBenachrichtigungsadresse;
use AppBundle\Entity\KorrekturvorschlagEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\KorrekturVorschlagRepository;
use Doctrine\Bundle\DoctrineBundle\Registry;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class NotifyCorrectionProposalsCommand extends ContainerAwareCommand {
    const FROM = 'korrekturvorschlag.redaktion@dietrich.uni-trier.de';
    const SUBJECT = 'Korrekturvorschläge stehen zur Bearbeitung bereit';
    const DIETRICH_ONLINE_URL = 'http://dietrich.uni-trier.de';

    protected function configure() {
        $this
            ->setName('app:notify-correction-proposals')
            ->setDescription('notifies employees about current correction proposals')
            ->setHelp('sends employees an email if there are correction proposals which need to be further processed.')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output) {
        /** @var $doctrine Registry */
        $doctrine = $this->getContainer()->get('doctrine');
        $doctrineManager = $doctrine->getManager(FeatureBase::DB_BACKEND);

        /** @var KorrekturVorschlagRepository $krrvschlgRepo */
        $krrvschlgRepo = $doctrineManager->getRepository(KorrekturvorschlagEntity::class);
        $toDos = $krrvschlgRepo->findToDoKorrekturvorschlaege();

        if (count($toDos) == 0) {
            return;
        }

        $this->notifyEmployees($toDos, $doctrineManager);
    }

    protected function notifyEmployees($toDos, ObjectManager $doctrineManager) {
        $emailAddressRepo = $doctrineManager->getRepository(
            KorrekturvorschlagBenachrichtigungsadresse::class
        );

        $notificationAddressEntities = $emailAddressRepo->findAll();
        $to = array_map(function ($addressEntity) {
            /** @var KorrekturvorschlagBenachrichtigungsadresse $addressEntity */
            return $addressEntity->getEmail();
        }, $notificationAddressEntities);

        $msg = new \Swift_Message();
        $msg
            ->setFrom(self::FROM)
            ->setTo($to)
            ->setSubject(self::SUBJECT)
            ->setBody($this->buildMessageBody($toDos))
            ->setContentType('text/html')
        ;

        /** @var \Swift_Mailer $mailer */
        $mailer = $this->getContainer()->get('mailer');
        $mailer->send($msg);
    }

    protected function buildMessageBody($toDos) {
        /** @var \Twig_Environment $twig */
        $twig = $this->getContainer()->get('twig');
        return $twig->render(
            'KorrekturvorschlagRedaktion/toDoNotifyMail.twig',
            [
                'toDos' => $toDos,
                'dietrichOnlineUrl' => self::DIETRICH_ONLINE_URL
            ]
        );
    }
}
