<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\DietrichliteraturreferenzRepository")
 * @ORM\Table(name="dietrichliteraturreferenz")
 */
class DietrichliteraturreferenzEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer $id
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=31)
     * @var string $sigle
     * @Assert\NotBlank(message="Bitte geben Sie eine Sigle ein.")
     */
    private $sigle;
    const SIGLE = 'sigle';

    /**
     * @ORM\Column(type="string")
     * @var string|null
     */
    private $sortableSigle;

    /**
     * @ORM\Column(type="string", length=31)
     * @var string $zeitungskuerzel
     */
    private $zeitungskuerzel;

    /**
     * @ORM\Column(type="string", length=255)
     * @var string $dietrichkollation
     * @Assert\Length(
     *      max = 255,
     *      maxMessage = "Die von Ihnen eingegebene Dietrich-Kollation ist zu lang (maximal sind 255 Zeichen erlaubt). Möglicherweise können Sie Bände zusammenfassen."
     * )
     */
    private $dietrichkollation;
    const DIETRICHKOLLATION = 'dietrichkollation';

    /**
     * @ORM\Column(type="text")
     * @var string $dietrichbezeichnung
     * @Assert\NotBlank(message="Bitte geben Sie den Titel bzw. die Bezeichnung der Literaturreferenz ein.")
     */
    private $dietrichbezeichnung;
    const DIETRICHBEZEICHNUNG = 'dietrichbezeichnung';

    /**
     * @ORM\ManyToOne(targetEntity="LiteraturreferenzbearbeitungsstatusEntity")
     * @ORM\JoinColumn(name="fk_literaturreferenzbearbeitungsstatus", referencedColumnName="id", nullable=false)
     * @var LiteraturreferenzbearbeitungsstatusEntity
     */
    private $literaturreferenzbearbeitungsstatusEntity;
    const LITERATURREFERENZBEARBEITUNGSSTATUS_ENTITY = 'literaturreferenzbearbeitungsstatusEntity';

    /**
     * @ORM\Column(type="text")
     * @var string $allgemeinebemerkung
     */
    private $allgemeinebemerkung;
    const ALLGEMEINEBEMERKUNG = 'allgemeinebemerkung';

    /**
     * @ORM\ManyToOne(targetEntity="BandEntity", inversedBy="dietrichliteraturreferenzen")
     * @ORM\JoinColumn(name="fk_band", referencedColumnName="id")
     * @var BandEntity
     */
    private $bandEntity;
    const BAND_ENTITY = 'bandEntity';

    /**
     * @ORM\OneToMany(targetEntity="DietrichlitrefNormlitrefEntity", mappedBy="dietrichliteraturreferenzEntity", fetch="EXTRA_LAZY")
     * @var Collection
     */
    private $dietrichlitrefNormlitrefEntities;

    /**
     * @ORM\ManyToOne(targetEntity="DietrichliteraturreferenzEntity")
     * @ORM\JoinColumn(name="fk_dietrichliteraturreferenz", referencedColumnName="id")
     * @var DietrichliteraturreferenzEntity
     */
    private $dietrichliteraturreferenzEntity;
    const DIETRICHLITERATURREFERENZ_ENTITY = 'dietrichliteraturreferenzEntity';

    /**
     * DietrichliteraturreferenzEntity constructor.
     */
    public function __construct()
    {
        $this->dietrichlitrefNormlitrefEntities = new ArrayCollection();
    }

    /**
     * @return DietrichliteraturreferenzEntity
     */
    public function getDietrichliteraturreferenzEntity()
    {
        return $this->dietrichliteraturreferenzEntity;
    }

    /**
     * @param $dietLitEntity DietrichliteraturreferenzEntity
     * @return DietrichliteraturreferenzEntity
     */
    public function setDietrichliteraturreferenzEntity($dietLitEntity): self
    {
        $this->dietrichliteraturreferenzEntity = $dietLitEntity;

        return $this;
    }

    /**
     * @return Collection
     */
    public function getDietrichlitrefNormlitrefEntities(): Collection
    {
        return $this->dietrichlitrefNormlitrefEntities;
    }

    /**
     * Get id
     *
    /**
     * @return integer|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set sigle
     *
     * @param string $sigle
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setSigle(string $sigle): self
    {
        $this->sigle = self::addPointToSigleIfNecessary($sigle);

        return $this;
    }

    /**
     * Get sigle
     *
     * @return string|null
     */
    public function getSigle()
    {
        return $this->sigle;
    }

    /**
     * Set zeitungskuerzel
     *
     * @param string $zeitungskuerzel
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setZeitungskuerzel(string $zeitungskuerzel): self
    {
        $this->zeitungskuerzel = $zeitungskuerzel;

        return $this;
    }

    /**
     * Get zeitungskuerzel
     *
     * @return string|null
     */
    public function getZeitungskuerzel()
    {
        return $this->zeitungskuerzel;
    }

    /**
     * Set dietrichkollation
     * <p>
     * (Form-)Input:
     * <ul>
     * <li>string: when a Dietrich Kollation was set
     * <li>null: when nothing was set
     * </ul>
     *
     * @param string | null $dietrichkollation
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setDietrichkollation($dietrichkollation): self
    {
        $this->dietrichkollation = $dietrichkollation;

        return $this;
    }

    /**
     * Get dietrichkollation
     *
     * @return string|null
     */
    public function getDietrichkollation()
    {
        return $this->dietrichkollation;
    }

    /**
     * Set dietrichbezeichnung
     *
     * @param string $dietrichbezeichnung
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setDietrichbezeichnung(string $dietrichbezeichnung): self
    {
        $this->dietrichbezeichnung = $dietrichbezeichnung;

        return $this;
    }

    /**
     * Get dietrichbezeichnung
     *
     * @return string|null
     */
    public function getDietrichbezeichnung()
    {
        return $this->dietrichbezeichnung;
    }

    /**
     * Set fkLiteraturreferenzbearbeitungsstatus
     *
     * @param LiteraturreferenzbearbeitungsstatusEntity $literaturreferenzbearbeitungsstatusEntity
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setLiteraturreferenzbearbeitungsstatusEntity($literaturreferenzbearbeitungsstatusEntity): self
    {
        $this->literaturreferenzbearbeitungsstatusEntity = $literaturreferenzbearbeitungsstatusEntity;

        return $this;
    }

    /**
     * @return LiteraturreferenzbearbeitungsstatusEntity|null
     */
    public function getLiteraturreferenzbearbeitungsstatusEntity()
    {
        return $this->literaturreferenzbearbeitungsstatusEntity;
    }

    /**
     * Set allgemeinebemerkung
     *
     * @param string|null $allgemeinebemerkung
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setAllgemeinebemerkung($allgemeinebemerkung): self
    {
        $this->allgemeinebemerkung = $allgemeinebemerkung;

        return $this;
    }

    /**
     * Get allgemeinebemerkung
     *
     * @return string|null
     */
    public function getAllgemeinebemerkung()
    {
        return $this->allgemeinebemerkung;
    }

    /**
     * Set bandEntity
     *
     * @param BandEntity $bandEntity
     *
     * @return DietrichliteraturreferenzEntity
     */
    public function setBandEntity(BandEntity $bandEntity): self
    {
        $this->bandEntity = $bandEntity;

        return $this;
    }

    /**
     * Get bandEntity
     *
     * @return BandEntity|null
     */
    public function getBandEntity()
    {
        return $this->bandEntity;
    }

    /**
     * @return string|null
     */
    public function getSortableSigle()
    {
        return $this->sortableSigle;
    }

    /**
     * Returns sigle string where every character has been checked and replaced if necessary to comply the URL standard.
     *
     * @see rawurlencode()
     * @return string|null
     */
    public function getUrlEscapedSigle()
    {
        return rawurlencode($this->sigle);
    }

    /**
     * @param $sigle
     * @return string|null
     */
    public static function addPointToSigleIfNecessary($sigle)
    {
        if (preg_match('/^\d+[a-z]*$/', $sigle) === 1) {
            $sigle .= '.';
        }
        return $sigle;
    }
}
