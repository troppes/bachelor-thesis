<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\BandRepository")
 * @ORM\Table(name="band")
 */
class BandEntity {
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 * @var integer $id
	 */
	private $id;

	/**
	 * @ORM\Column(type="string", length=255)
	 * @var string $bandkuerzel
	 */
	private $bandkuerzel;
	
	/**
	 * @ORM\Column(type="text")
	 * @var string $bandbezeichnung
	 */
	private $bandbezeichnung;
	
	/**
	 * @ORM\Column(type="text")
	 * @var unknown $erfassungszeitraum
	 */
	private $erfassungszeitraum;
	
	/**
	 * @ORM\Column(type="integer")
	 * @var integer $jahrVon
	 */
	private $jahrVon;

	/**
	 * @ORM\Column(type="integer")
	 * @var integer $jahrBis
	 */
	private $jahrBis;
	
	/**
	 * @ORM\Column(type="string", length=255)
	 * @var string $scanId
	 */
	private $scanId;
	
	/**
	 * @ORM\OneToMany(targetEntity="DietrichliteraturreferenzEntity", mappedBy="bandEntity", fetch="EXTRA_LAZY")
	 * @ORM\OrderBy({"sigle" = "ASC", "dietrichbezeichnung" = "ASC"})
	 // TODO: richtigen Type für den Container raussuchen und eintragen
	 * @var array
	 */
	private $dietrichliteraturreferenzen;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set bandkuerzel
     *
     * @param string $bandkuerzel
     *
     * @return BandEntity
     */
    public function setBandkuerzel($bandkuerzel)
    {
        $this->bandkuerzel = $bandkuerzel;

        return $this;
    }

    /**
     * Get bandkuerzel
     *
     * @return string
     */
    public function getBandkuerzel()
    {
        return $this->bandkuerzel;
    }

    /**
     * Set bandbezeichnung
     *
     * @param string $bandbezeichnung
     *
     * @return BandEntity
     */
    public function setBandbezeichnung($bandbezeichnung)
    {
        $this->bandbezeichnung = $bandbezeichnung;

        return $this;
    }

    /**
     * Get bandbezeichnung
     *
     * @return string
     */
    public function getBandbezeichnung()
    {
        return $this->bandbezeichnung;
    }

    /**
     * Set erfassungszeitraum
     *
     * @param string $erfassungszeitraum
     *
     * @return BandEntity
     */
    public function setErfassungszeitraum($erfassungszeitraum)
    {
        $this->erfassungszeitraum = $erfassungszeitraum;

        return $this;
    }

    /**
     * Get erfassungszeitraum
     *
     * @return string
     */
    public function getErfassungszeitraum()
    {
        return $this->erfassungszeitraum;
    }

    /**
     * Set jahrVon
     *
     * @param integer $jahrVon
     *
     * @return BandEntity
     */
    public function setJahrVon($jahrVon)
    {
        $this->jahrVon = $jahrVon;

        return $this;
    }

    /**
     * Get jahrVon
     *
     * @return integer
     */
    public function getJahrVon()
    {
        return $this->jahrVon;
    }

    /**
     * Set jahrBis
     *
     * @param integer $jahrBis
     *
     * @return BandEntity
     */
    public function setJahrBis($jahrBis)
    {
        $this->jahrBis = $jahrBis;

        return $this;
    }

    /**
     * Get jahrBis
     *
     * @return integer
     */
    public function getJahrBis()
    {
        return $this->jahrBis;
    }

    /**
     * Set scanId
     *
     * @param string $scanId
     *
     * @return BandEntity
     */
    public function setScanId($scanId)
    {
        $this->scanId = $scanId;

        return $this;
    }

    /**
     * Get scanId
     *
     * @return string
     */
    public function getScanId()
    {
        return $this->scanId;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->dietrichliteraturreferenzen = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add dietrichliteraturreferenzen
     *
     * @param \AppBundle\Entity\DietrichliteraturreferenzEntity $dietrichliteraturreferenzen
     *
     * @return BandEntity
     */
    public function addDietrichliteraturreferenzen(\AppBundle\Entity\DietrichliteraturreferenzEntity $dietrichliteraturreferenzen)
    {
        $this->dietrichliteraturreferenzen[] = $dietrichliteraturreferenzen;

        return $this;
    }

    /**
     * Remove dietrichliteraturreferenzen
     *
     * @param \AppBundle\Entity\DietrichliteraturreferenzEntity $dietrichliteraturreferenzen
     */
    public function removeDietrichliteraturreferenzen(\AppBundle\Entity\DietrichliteraturreferenzEntity $dietrichliteraturreferenzen)
    {
        $this->dietrichliteraturreferenzen->removeElement($dietrichliteraturreferenzen);
    }

    /**
     * Get dietrichliteraturreferenzen
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getDietrichliteraturreferenzen()
    {
        return $this->dietrichliteraturreferenzen;
    }

    /**
     * Returns the DFG viewer URL for the given <code>pysikalischeSeite</code> of an <code>artikel</code>.
     * <p>
     * You should use <code>$this->getDfgViewerUrlOfArtikel($artikel)</code> instead.
     * <p>
     * Note: Given protocol is not secure (HTTP).
     *
     * @param $page The localized page within the dietrich band.
     * @return string The full URL within the DFG viewer
     */
    public function getDfgViewerUrl($page)
    {
        return 'http://dfg-viewer.de/show/?id=8071&tx_dlf%5Bid%5D=http%3A%2F%2Fwww.dietrich.uni-trier.de%2FdfgViewer%2Fdfgmets%2F'
            . $this->scanId . '.xml&tx_dlf%5Bpage%5D=' . $page;
    }

    /**
     * Returns the DFG viewer URL for the localized article page.
     * <p>
     *
     * @param ArtikelEntity $artikel
     * @return string
     * @throws \RuntimeException If the <code>artikel</code> id is not equal to the <code>band</code> id
     */
    public function getDfgViewerUrlOfArtikel(ArtikelEntity $artikel) {
        if ($artikel->getBandEntity()->getId() != $this->getId()) {
            throw new \RuntimeException(
                sprintf("Artikel %s not in Band %s", $artikel->getId(), $this->getId())
            );
        }

        return $this->getDfgViewerUrl($artikel->getPhysikalischeSeite());
    }
}
