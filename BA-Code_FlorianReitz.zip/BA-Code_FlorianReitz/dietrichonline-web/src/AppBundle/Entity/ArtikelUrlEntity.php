<?php
namespace AppBundle\Entity;

use AppBundle\Util\UrlUtil;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @ORM\Table(name="artikel_url")
 */
class ArtikelUrlEntity {
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 * @var integer
	 */
	protected $id;
	
	/**
	 * @ORM\Column(type="text")
	 * @var string
	 * @Assert\Url(
	 * 	protocols = {"http", "https"},
	 * 	message = "Die URL {{ value }} ist keine gültige URL."
	 * )
	 * @Assert\NotBlank()
	 */
	protected $url;

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\NotBlank()
     */
    private $domainName;
    const DOMAIN_NAME = 'domain_name';
	
	/**
	 * @ORM\ManyToOne(targetEntity="ArtikelEntity", inversedBy="artikelUrlEntities")
	 * @ORM\JoinColumn(
	 *   name="fk_artikel", 
	 *   referencedColumnName="id", 
	 *   nullable=false
	 * )
	 * @var ArtikelEntity
	 */
	protected $artikelEntity;
	
	/**
	 * @param ArtikelEntity $artikelEntity
	 * @return void
	 */
	public function setArtikelEntity(ArtikelEntity $artikelEntity) {
	    $this->artikelEntity = $artikelEntity;
	}

    /**
     * @return ArtikelEntity
     */
    public function getArtikelEntity() {
        return $this->artikelEntity;
    }
	
	/**
	 * @return string
	 */
	public function getUrl() {
		return $this->url;
	}
	
	/**
	 * @param string $url
	 * @return void
	 */
	public function setUrl($url) {
        $this->domainName = UrlUtil::getDomainName($url);
		$this->url = $url;
	}
	
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getDomainName(): string
    {
        return $this->domainName;
    }
}
