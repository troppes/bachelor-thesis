<?php

namespace AppBundle\Entity;

use AppBundle\Util\UrlUtil;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @ORM\Table(name="werk_url")
 */
class WerkUrlEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    private $id;
    const ID = 'id';

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\Url(
     *    protocols = {"http", "https"},
     *    message = "Die URL {{ value }} ist keine gültige URL."
     * )
     * @Assert\NotBlank()
     */
    private $url;
    const URL = 'url';

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\NotBlank()
     */
    private $domainName;
    const DOMAIN_NAME = 'domain_name';

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    private $bemerkung;
    const BEMERKUNG = 'bemerkung';

    /**
     * @ORM\ManyToOne(targetEntity="NormliteraturreferenzEntity", inversedBy="werkUrlEntities")
     * @ORM\JoinColumn(name="fk_normliteraturreferenz", referencedColumnName="id", nullable=false)
     * @var NormliteraturreferenzEntity
     */
    private $normliteraturreferenzEntity;

    /**
     * @return NormliteraturreferenzEntity|null
     */
    public function getNormliteraturreferenzEntity()
    {
        return $this->normliteraturreferenzEntity;
    }

    /**
     * @param NormliteraturreferenzEntity $normliteraturreferenzEntity
     * @return self
     */
    public function setNormliteraturreferenzEntity(NormliteraturreferenzEntity $normliteraturreferenzEntity): self
    {
        $this->normliteraturreferenzEntity = $normliteraturreferenzEntity;

        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getBemerkung()
    {
        return $this->bemerkung;
    }

    /**
     * @param string|null $bemerkung
     * @return self
     */
    public function setBemerkung($bemerkung): self
    {
        $this->bemerkung = $bemerkung;

        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @param string $url
     * @return self
     */
    public function setUrl(string $url): self
    {
        $this->domainName = UrlUtil::getDomainName($url);
        $this->url = $url;
        return $this;
    }

    /**
     * Get id
     *
     * @return integer|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getDomainName(): string
    {
        return $this->domainName;
    }
}
