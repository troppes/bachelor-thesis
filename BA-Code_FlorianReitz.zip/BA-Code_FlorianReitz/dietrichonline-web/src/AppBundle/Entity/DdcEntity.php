<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\DdcRepository")
 * @ORM\Table(name="ddc")
 */
class DdcEntity {
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	private $id;

	/**
	 * @ORM\Column(type="text")
	 * @var string
	 */
	protected $notation;
	
	/**
	 * @ORM\Column(type="text")
	 * @var string
	 */
	protected $schlagwort;
	
	/**
	 * @ORM\Column(type="boolean")
	 * @var boolean
	 */
	protected $webdeweyIsChecked;
	
	/**
	 * @ORM\ManyToOne(targetEntity="DdcEntity", inversedBy="ChildEntities")
	 * @ORM\JoinColumn(name="fk_ddc_parent", referencedColumnName="id", nullable=true)
	 * @var DdcEntity
	 */
	protected $parent;
	
	/**
	 * @ORM\OneToMany(targetEntity="DdcEntity", mappedBy="parent")
	 * @var array
	 */
	protected $ChildEntities;
	
	/**
	 * Get ChildEntities
	 */
	public function getChildEntities() {
	    return $this->ChildEntities;
	}
	
	/**
	 * Set parent
	 *
	 * @param DdcEntity parent
	 *
	 * @return DdcEntity
	 */
	public function setParent($parent) {
	    $this->parent = $parent;
	
	    return $this;
	}
	
	/**
	 * Get parent
	 *
	 * @return DdcEntity
	 */
	public function getParent() {
	    return $this->parent;
	}
	
	/**
	 * Set webdeweyIsChecked
	 *
	 * @param boolean webdeweyIsChecked
	 *
	 * @return DdcEntity
	 */
	public function setWebdeweyIsChecked($webdeweyIsChecked) {
	    $this->webdeweyIsChecked = $webdeweyIsChecked;
	
	    return $this;
	}
	
	/**
	 * Get webdeweyIsChecked
	 *
	 * @return boolean
	 */
	public function getWebdeweyIsChecked() {
	    return $this->webdeweyIsChecked;
	}

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
	
	/**
	 * @return string
	 */
	public function getNotation() {
		return $this->notation;
	}
	
	/**
	 * @param string $notation
	 * @return void
	 */
	public function setNotation($notation) {
		$this->notation = $notation;
	}
	
	/**
	 * @return string
	 */
	public function getSchlagwort() {
		return $this->schlagwort;
	}
	
	/**
	 * @param string $schlagwort
	 * @return void
	 */
	public function setSchlagwort($schlagwort) {
		$this->schlagwort = $schlagwort;
	}
}