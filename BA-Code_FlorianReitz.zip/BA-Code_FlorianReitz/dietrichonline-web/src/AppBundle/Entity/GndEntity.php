<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\AutocompletableRepository")
 * @ORM\Table(name="gnd")
 */
class GndEntity
{
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	private $id;

	/**
	 * @ORM\Column(type="string", length=100)
	 */
	private $nummer;

	/**
	 * @ORM\Column(type="text")
	 */
	private $schlagwort;
	
	/**
	 * @ORM\OneToMany(targetEntity="GndDdcEntity", mappedBy="gndEntity", fetch="EXTRA_LAZY")
	 * @var array
	 */
	protected $gndDdcEntities;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nummer
     *
     * @param string $nummer
     *
     * @return GndEntity
     */
    public function setNummer($nummer)
    {
        $this->nummer = $nummer;

        return $this;
    }

    /**
     * Get nummer
     *
     * @return string
     */
    public function getNummer()
    {
        return $this->nummer;
    }

    /**
     * Set schlagwort
     *
     * @param string $schlagwort
     *
     * @return GndEntity
     */
    public function setSchlagwort($schlagwort)
    {
        $this->schlagwort = $schlagwort;

        return $this;
    }

    /**
     * Get schlagwort
     *
     * @return string
     */
    public function getSchlagwort()
    {
        return $this->schlagwort;
    }
	
	/**
	 * @return array
	 */
	public function getGndDdcEntities() {
		return $this->gndDdcEntities;
	}
}
