<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 * @ORM\Table(name="korrekturvorschlagstatus")
 */
class KorrekturvorschlagstatusEntity {
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    protected $id;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $bezeichnung;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $beschreibung;
    
    /**
     * Set beschreibung
     *
     * @param string beschreibung
     *
     * @return KorrekturvorschlagstatusEntity
     */
    public function setBeschreibung($beschreibung) {
        $this->beschreibung = $beschreibung;
    
        return $this;
    }
    
    /**
     * Get beschreibung
     *
     * @return string
     */
    public function getBeschreibung() {
        return $this->beschreibung;
    }
    
    /**
     * Set bezeichnung
     *
     * @param string bezeichnung
     *
     * @return KorrekturvorschlagstatusEntity
     */
    public function setBezeichnung($bezeichnung) {
        $this->bezeichnung = $bezeichnung;
    
        return $this;
    }
    
    /**
     * Get bezeichnung
     *
     * @return string
     */
    public function getBezeichnung() {
        return $this->bezeichnung;
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}