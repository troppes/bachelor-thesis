<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\ArtikelRepository")
 * @ORM\Table(name="artikel")
 */
class ArtikelEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @var integer
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=255)
     * @var string
     */
    protected $titel;

    /**
     * @ORM\Column(type="text")
     * @var string|null
     */
    protected $sigle;

    /**
     * @ORM\ManyToOne(targetEntity="LemmaEntity", inversedBy="artikelEntities")
     * @ORM\JoinColumn(name="fk_lemma", referencedColumnName="id", nullable=false)
     * @var LemmaEntity
     */
    protected $lemmaEntity;

    /**
     * @ORM\ManyToOne(targetEntity="BandEntity")
     * @ORM\JoinColumn(name="fk_band", referencedColumnName="id", nullable=false)
     * @var BandEntity
     */
    protected $bandEntity;

    /**
     * @ORM\Column(type="text")
     * @var string|null
     */
    protected $dietrichkollation;

    /**
     * @ORM\Column(type="integer")
     * @var integer
     */
    protected $bibliographieseite;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $bibliographiespalte;

    /**
     * @ORM\Column(type="integer")
     * @var integer
     */
    protected $bibliographiezeile;

    /**
     * @ORM\Column(type="text")
     * @var string|null
     */
    protected $autor;

    /**
     * @ORM\Column(type="integer")
     * @var integer
     */
    protected $letztmoeglichesErscheinungsjahr;

    /**
     * @ORM\Column(type="integer")
     * @var integer
     */
    protected $erstmoeglichesErscheinungsjahr;

    /**
     * @ORM\ManyToOne(targetEntity="DietrichliteraturreferenzEntity")
     * @ORM\JoinColumn(name="fk_dietrichliteraturreferenz", referencedColumnName="id", nullable=true)
     * @var DietrichliteraturreferenzEntity|null
     */
    protected $dietrichliteraturreferenzEntity;

    /**
     * @ORM\OneToMany(targetEntity="KorrekturvorschlagEntity", mappedBy="artikelEntity", fetch="EXTRA_LAZY")
     * @var Collection
     */
    protected $korrekturvorschlagEntities;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $titelMitLemma;

    /**
     * @ORM\OneToMany(targetEntity="ArtikelUrlEntity", mappedBy="artikelEntity")
     * @ORM\OrderBy({"domainName" = "ASC"})
     * @var Collection
     */
    protected $artikelUrlEntities;

    /**
     * @ORM\Column(type="integer")
     * @var integer
     */
    protected $physikalischeSeite;

    /**
     * @ORM\Column(type="string")
     * @var string
     */
    private $titelMitLemmaFormen;

    public function getTitelMitLemmaFormen(): string
    {
        return $this->titelMitLemmaFormen;
    }

    /**
     * @return int
     */
    public function getPhysikalischeSeite(): int
    {
        return $this->physikalischeSeite;
    }

    /**
     * @param int $physikalischeSeite
     */
    public function setPhysikalischeSeite(int $physikalischeSeite)
    {
        $this->physikalischeSeite = $physikalischeSeite;
    }

    /**
     * Get artikelUrlEntities
     */
    public function getArtikelUrlEntities(): Collection
    {
        return $this->artikelUrlEntities;
    }

    /**
     * Get titelMitLemma
     *
     * @return string
     */
    public function getTitelMitLemma(): string
    {
        return $this->titelMitLemma;
    }

    /**
     * Get korrekturvorschlagEntity
     *
     * @return Collection
     */
    public function getKorrekturvorschlagEntities(): Collection
    {
        return $this->korrekturvorschlagEntities;
    }

    /**
     * @return DietrichliteraturreferenzEntity|null
     */
    public function getDietrichliteraturreferenzEntity()
    {
        return $this->dietrichliteraturreferenzEntity;
    }

    /**
     * Returns the 'linked' DietrichliteraturreferenzEntity with the user data to display in the UI.
     * <p>
     * It exists two cases for a DietrichliteraturreferenzEntity:
     * <ol>
     * <li>it's a <strong>direct</strong> entity.<br>
     *     The data to the Artikel is directly connected to an entity.
     * <li>it's a <strong>linked</strong> entity.<br>
     *     The data to the Artikel is linked via one or more Siglen to an entity endpoint (it's called <quote>'siehe Sigle'</quote>).
     * </ol>
     *
     * @return DietrichliteraturreferenzEntity|null The endpoint entity, otherwise <code>null</code>
     */
    public function getDietrichliteraturreferenzEndpointEntity()
    {
        $endpoint = null;

        if ($this->dietrichliteraturreferenzEntity !== null)
        {
            $possibleEndpoint = $this->dietrichliteraturreferenzEntity;

            // has the possible endpoint a depending endpoint?
            while ($possibleEndpoint->getDietrichliteraturreferenzEntity() !== null)
            {
                // yes, than set the depending endpoint as the new possible endpoint
                $possibleEndpoint = $possibleEndpoint->getDietrichliteraturreferenzEntity();
            }
            // no, we got our endpoint
            $endpoint = $possibleEndpoint;
        }

        return $endpoint;
    }

    /**
     * @param DietrichliteraturreferenzEntity $dietrichliteraturreferenzEntity
     * @return void
     */
    public function setDietrichliteraturreferenzEntity($dietrichliteraturreferenzEntity)
    {
        $this->dietrichliteraturreferenzEntity = $dietrichliteraturreferenzEntity;
    }

    /**
     * @return integer
     */
    public function getErstmoeglichesErscheinungsjahr(): int
    {
        return $this->erstmoeglichesErscheinungsjahr;
    }

    /**
     * @param integer $erstmoeglichesErscheinungsjahr
     * @return void
     */
    public function setErstmoeglichesErscheinungsjahr($erstmoeglichesErscheinungsjahr)
    {
        $this->erstmoeglichesErscheinungsjahr = $erstmoeglichesErscheinungsjahr;
    }

    /**
     * @return integer
     */
    public function getLetztmoeglichesErscheinungsjahr(): int
    {
        return $this->letztmoeglichesErscheinungsjahr;
    }

    /**
     * @param integer $letztmoeglichesErscheinungsjahr
     * @return void
     */
    public function setLetztmoeglichesErscheinungsjahr($letztmoeglichesErscheinungsjahr)
    {
        $this->letztmoeglichesErscheinungsjahr = $letztmoeglichesErscheinungsjahr;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set id
     *
     * @param $id
     * @return $this
     */
    public function setId($id): self
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Set titel
     *
     * @param string $titel
     *
     * @return self
     */
    public function setTitel($titel): self
    {
        $this->titel = $titel;

        return $this;
    }

    /**
     * Get titel
     *
     * @return string
     */
    public function getTitel(): string
    {
        return $this->titel;
    }

    /**
     * Set sigle
     *
     * @param string $sigle
     *
     * @return self
     */
    public function setSigle($sigle): self
    {
        $this->sigle = DietrichliteraturreferenzEntity::addPointToSigleIfNecessary($sigle);

        return $this;
    }

    /**
     * Get sigle
     *
     * @return string|null
     */
    public function getSigle()
    {
        return $this->sigle;
    }

    /**
     * Set dietrichkollation
     *
     * @param string $dietrichkollation
     *
     * @return self
     */
    public function setDietrichkollation($dietrichkollation): self
    {
        $this->dietrichkollation = $dietrichkollation;

        return $this;
    }

    /**
     * Get dietrichkollation
     *
     * @return string|null
     */
    public function getDietrichkollation()
    {
        return $this->dietrichkollation;
    }

    /**
     * Set bibliographieseite
     *
     * @param integer $bibliographieseite
     *
     * @return self
     */
    public function setBibliographieseite($bibliographieseite): self
    {
        $this->bibliographieseite = $bibliographieseite;

        return $this;
    }

    /**
     * Get bibliographieseite
     *
     * @return integer
     */
    public function getBibliographieseite(): int
    {
        return $this->bibliographieseite;
    }

    /**
     * Set bibliographiespalte
     *
     * @param string $bibliographiespalte
     *
     * @return self
     */
    public function setBibliographiespalte($bibliographiespalte): self
    {
        $this->bibliographiespalte = $bibliographiespalte;

        return $this;
    }

    /**
     * Get bibliographiespalte
     *
     * @return string
     */
    public function getBibliographiespalte(): string
    {
        return $this->bibliographiespalte;
    }

    /**
     * Set bibliographiezeile
     *
     * @param integer $bibliographiezeile
     *
     * @return self
     */
    public function setBibliographiezeile($bibliographiezeile): self
    {
        $this->bibliographiezeile = $bibliographiezeile;

        return $this;
    }

    /**
     * Get bibliographiezeile
     *
     * @return integer
     */
    public function getBibliographiezeile(): int
    {
        return $this->bibliographiezeile;
    }

    /**
     * Set autor
     *
     * @param string $autor
     *
     * @return self
     */
    public function setAutor($autor): self
    {
        $this->autor = $autor;

        return $this;
    }

    /**
     * Get autor
     *
     * @return string|null
     */
    public function getAutor()
    {
        return $this->autor;
    }

    /**
     * Set lemmaEntity
     *
     * @param LemmaEntity $lemmaEntity
     *
     * @return self
     */
    public function setLemmaEntity(LemmaEntity $lemmaEntity): self
    {
        $this->lemmaEntity = $lemmaEntity;

        return $this;
    }

    /**
     * Get lemmaEntity
     *
     * @return LemmaEntity
     */
    public function getLemmaEntity(): LemmaEntity
    {
        return $this->lemmaEntity;
    }

    /**
     * Set bandEntity
     *
     * @param BandEntity $bandEntity
     *
     * @return self
     */
    public function setBandEntity(BandEntity $bandEntity): self
    {
        $this->bandEntity = $bandEntity;

        return $this;
    }

    /**
     * Get bandEntity
     *
     * @return BandEntity
     */
    public function getBandEntity(): BandEntity
    {
        return $this->bandEntity;
    }
}
