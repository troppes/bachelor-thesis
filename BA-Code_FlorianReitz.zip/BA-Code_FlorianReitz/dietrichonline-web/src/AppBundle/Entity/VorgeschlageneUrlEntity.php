<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @ORM\Table(name="vorgeschlagene_url")
 */
class VorgeschlageneUrlEntity {
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    protected $id;
    
    /**
     * @ORM\Column(type="string")	 
     * @Assert\Url(
	 * 	protocols = {"http", "https"},
	 * 	message = "Die URL {{ value }} ist keine gültige URL."
	 * )
     * @var string
     */
    protected $url;
    
    /**
     * @ORM\ManyToOne(targetEntity="KorrekturvorschlagEntity", inversedBy="vorgeschlageneUrlEntities")
     * @ORM\JoinColumn(name="fk_korrekturvorschlag", referencedColumnName="id", nullable=false)
     * @var KorrekturvorschlagEntity
     */
    protected $korrekturvorschlagEntity;
    
    /**
     * Set korrekturvorschlagEntity
     *
     * @param KorrekturvorschlagEntity korrekturvorschlagEntity
     *
     * @return VorgeschlageneUrlEntity
     */
    public function setKorrekturvorschlagEntity($korrekturvorschlagEntity) {
        $this->korrekturvorschlagEntity = $korrekturvorschlagEntity;
    
        return $this;
    }
    
    /**
     * Get korrekturvorschlagEntity
     *
     * @return KorrekturvorschlagEntity
     */
    public function getKorrekturvorschlagEntity() {
        return $this->korrekturvorschlagEntity;
    }
    
    /**
     * Set url
     *
     * @param string url
     *
     * @return VorgeschlageneUrlEntity
     */
    public function setUrl($url) {
        $this->url = $url;
    
        return $this;
    }
    
    /**
     * Get url
     *
     * @return string
     */
    public function getUrl() {
        return $this->url;
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}