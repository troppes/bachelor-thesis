<?php

namespace AppBundle\Entity;

use AppBundle\Util\UrlUtil;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @ORM\Table(name="band_url")
 */
class BandUrlEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    protected $id;

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\Url(
     *    protocols = {"http", "https"},
     *    message = "Die URL {{ value }} ist keine gültige URL."
     * )
     * @Assert\NotBlank()
     */
    protected $url;
    const URL = 'url';

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\NotBlank()
     */
    private $domainName;
    const DOMAIN_NAME = 'domain_name';

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $bemerkung;
    const BEMERKUNG = 'bemerkung';

    /**
     * @ORM\ManyToOne(targetEntity="DietrichlitrefNormlitrefEntity", inversedBy="bandUrlEntities")
     * @ORM\JoinColumn(
     *   name="fk_dietrichliteraturreferenz_normliteraturreferenz",
     *   referencedColumnName="id",
     *   nullable=false
     * )
     * @var DietrichlitrefNormlitrefEntity
     */
    protected $dietrichlitrefNormlitrefEntity;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $normkollation;
    const NORMKOLLATION = 'normkollation';

    /**
     * @return string|null
     */
    public function getNormkollation()
    {
        return $this->normkollation;
    }

    /**
     * @param string $normkollation
     * @return void
     */
    public function setNormkollation(string $normkollation)
    {
        $this->normkollation = $normkollation;
    }

    /**
     * @return DietrichlitrefNormlitrefEntity|null
     */
    public function getDietrichlitrefNormlitrefEntity()
    {
        return $this->dietrichlitrefNormlitrefEntity;
    }

    /**
     * @param DietrichlitrefNormlitrefEntity $dietLitNormLitEntity
     * @return BandUrlEntity
     */
    public function setDietrichlitrefNormlitrefEntity(DietrichlitrefNormlitrefEntity $dietLitNormLitEntity): self
    {
        $this->dietrichlitrefNormlitrefEntity = $dietLitNormLitEntity;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getBemerkung()
    {
        return $this->bemerkung;
    }

    /**
     * @param string|null $bemerkung
     * @return BandUrlEntity
     */
    public function setBemerkung($bemerkung): self
    {
        $this->bemerkung = $bemerkung;
        return $this;
    }

    /**
     * @return string|null
     */
    public function getUrl()
    {
        return $this->url;
    }

    /**
     * @param string $url
     * @return BandUrlEntity
     */
    public function setUrl(string $url): self
    {
        $this->domainName = UrlUtil::getDomainName($url);
        $this->url = $url;
        return $this;
    }

    /**
     * Get id
     *
     * @return integer|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getDomainName(): string
    {
        return $this->domainName;
    }
}
