<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\ORM\Mapping\JoinColumn;
use Doctrine\ORM\Mapping\JoinTable;
use Doctrine\ORM\Mapping\ManyToMany;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\BandSegmentationRepository")
 * @ORM\Table(name="tfl_fehler")
 */
class SegmentationsFehlerEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     * @var integer
     */
    private $eid;

    /**
     * @ORM\Column(type="integer")
     * @var integer
     * @Assert\NotBlank()
     */
    private $severity;

    /**
     * @ORM\Column(type="text", name="originalText")
     * @var string
     * @Assert\NotBlank()
     */
    private $originalText;

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\NotBlank()
     */
    private $band;

    /**
     * @ORM\Column(type="integer", name="bd_seite")
     * @var integer
     * @Assert\NotBlank()
     */
    private $bdSeite;

    /**
     * @ORM\Column(type="text", name="bd_spalte")
     * @var string
     * @Assert\NotBlank()
     */
    private $bdSpalte;

    /**
     * @ORM\Column(type="integer", name="bd_zeile")
     * @var integer
     * @Assert\NotBlank()
     */
    private $bdZeile;

    /**
     * @ORM\Column(type="text")
     * @var string
     * @Assert\NotBlank()
     */
    private $lemma;

    /**
     * @ORM\Column(type="text", name="charErrors")
     * @var string
     */
    private $possibleError;

    /**
     *
     * @ManyToMany(targetEntity="RPTMapEntity")
     * @JoinTable(name="tfl_fehler_rptmap",
     *      joinColumns={@JoinColumn(name="fk_fehler", referencedColumnName="eid")},
     *      inverseJoinColumns={@JoinColumn(name="fk_rptmap", referencedColumnName="id")}
     *      )
     */
    protected $fehlerRPTMapsEntities;

    /**
     * @return int
     */
    public function getEid(): int
    {
        return $this->eid;
    }

    /**
     * @return string
     */
    public function getSeverity(): string
    {
        return $this->severity;
    }

    /**
     * @return string
     */
    public function getOriginalText(): string
    {
        return $this->originalText;
    }

    /**
     * @return string
     */
    public function getBand(): string
    {
        return $this->band;
    }

    /**
     * @return string
     */
    public function getBdSeite(): string
    {
        return $this->bdSeite;
    }

    /**
     * @return string
     */
    public function getBdSpalte(): string
    {
        return $this->bdSpalte;
    }

    /**
     * @return string
     */
    public function getBdZeile(): string
    {
        return $this->bdZeile;
    }

    /**
     * @return string
     */
    public function getLemma(): string
    {
        return $this->lemma;
    }

    /**
     * @return string
     */
    public function getPossibleError()
    {
        return $this->possibleError;
    }

    /**
     * @return mixed
     */
    public function getFehlerRPTMapsEntities()
    {
        return $this->fehlerRPTMapsEntities;
    }


}
