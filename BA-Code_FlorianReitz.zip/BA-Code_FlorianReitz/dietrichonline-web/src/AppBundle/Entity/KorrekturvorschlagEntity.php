<?php
namespace AppBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\KorrekturVorschlagRepository")
 * @ORM\Table(name="korrekturvorschlag")
 */
class KorrekturvorschlagEntity {
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    protected $id;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $titel;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $autor;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $literaturreferenz;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $sonstiges;
    
    /**
     * @ORM\ManyToOne(targetEntity="ArtikelEntity", inversedBy="korrekturvorschlagEntities")
     * @ORM\JoinColumn(name="fk_artikel", referencedColumnName="id", nullable=false)
     * @var ArtikelEntity
     */
    protected $artikelEntity;
    
    /**
     * @Assert\Valid
     * @ORM\ManyToOne(targetEntity="KorrektorEntity", cascade={"persist"})
     * @ORM\JoinColumn(name="fk_korrektor", referencedColumnName="id", nullable=true)
     * @var KorrektorEntity
     */
    protected $korrektorEntity;
    
    /**
     * @ORM\ManyToOne(targetEntity="KorrekturvorschlagstatusEntity")
     * @ORM\JoinColumn(name="fk_korrekturvorschlagstatus", referencedColumnName="id", nullable=false)
     * @var KorrekturvorschlagstatusEntity
     */
    protected $korrekturvorschlagstatusEntity;
    
    /**
     * @ORM\OneToMany(targetEntity="VorgeschlageneUrlEntity", mappedBy="korrekturvorschlagEntity", cascade={"persist"})
     * @var Collection
     */
    protected $vorgeschlageneUrlEntities;
    
    /**
     * @ORM\Column(type="integer")
     * @var integer
     */
    protected $timestamp;
    
    /**
     * Set timestamp
     *
     * @param integer timestamp
     *
     * @return KorrekturvorschlagEntity
     */
    public function setTimestamp($timestamp) {
        $this->timestamp = $timestamp;
    
        return $this;
    }
    
    /**
     * Get timestamp
     *
     * @return integer
     */
    public function getTimestamp() {
        return $this->timestamp;
    }
    
    public function __construct() {
        $this->vorgeschlageneUrlEntities = new ArrayCollection();
    }
    
    /**
     * Get vorgeschlageneUrlEntities
     */
    public function getVorgeschlageneUrlEntities() {
        return $this->vorgeschlageneUrlEntities;
    }
    
    /**
     * Magic function to add VorgeschlageneUrlEntities
     */
    public function addVorgeschlageneUrlEntity(VorgeschlageneUrlEntity $urlEntity) {
        $this->vorgeschlageneUrlEntities->add($urlEntity);
        $urlEntity->setKorrekturvorschlagEntity($this);
    }
    
    /**
     * Magic function to remove VorgeschlageneUrlEntities
     */
    public function removeVorgeschlageneUrlEntity(VorgeschlageneUrlEntity $entity) {
        
    }
    
    /**
     * Set korrekturvorschlagstatusEntity
     *
     * @param KorrekturvorschlagstatusEntity korrekturvorschlagstatusEntity
     *
     * @return KorrekturvorschlagEntity
     */
    public function setKorrekturvorschlagstatusEntity($korrekturvorschlagstatusEntity) {
        $this->korrekturvorschlagstatusEntity = $korrekturvorschlagstatusEntity;
    
        return $this;
    }
    
    /**
     * Get korrekturvorschlagstatusEntity
     *
     * @return KorrekturvorschlagstatusEntity
     */
    public function getKorrekturvorschlagstatusEntity() {
        return $this->korrekturvorschlagstatusEntity;
    }
    
    /**
     * Set korrektorEntity
     *
     * @param KorrektorEntity korrektorEntity
     *
     * @return KorrekturvorschlagEntity
     */
    public function setKorrektorEntity($korrektorEntity) {
        $this->korrektorEntity = $korrektorEntity;
    
        return $this;
    }
    
    /**
     * Get korrektorEntity
     *
     * @return KorrektorEntity
     */
    public function getKorrektorEntity() {
        return $this->korrektorEntity;
    }
    
    /**
     * Set artikelEntity
     *
     * @param ArtikelEntity artikelEntity
     *
     * @return KorrekturvorschlagEntity
     */
    public function setArtikelEntity($artikelEntity) {
        $this->artikelEntity = $artikelEntity;
    
        return $this;
    }
    
    /**
     * Get artikelEntity
     *
     * @return ArtikelEntity
     */
    public function getArtikelEntity() {
        return $this->artikelEntity;
    }
    
    /**
     * Set sonstiges
     *
     * @param string sonstiges
     *
     * @return KorrekturvorschlagEntity
     */
    public function setSonstiges($sonstiges) {
        $this->sonstiges = $sonstiges;
    
        return $this;
    }
    
    /**
     * Get sonstiges
     *
     * @return string
     */
    public function getSonstiges() {
        return $this->sonstiges;
    }
    
    /**
     * Set literaturreferenz
     *
     * @param string literaturreferenz
     *
     * @return KorrekturvorschlagEntity
     */
    public function setLiteraturreferenz($literaturreferenz) {
        $this->literaturreferenz = $literaturreferenz;
    
        return $this;
    }
    
    /**
     * Get literaturreferenz
     *
     * @return string
     */
    public function getLiteraturreferenz() {
        return $this->literaturreferenz;
    }
    
    /**
     * Set autor
     *
     * @param string autor
     *
     * @return KorrekturvorschlagEntity
     */
    public function setAutor($autor) {
        $this->autor = $autor;
    
        return $this;
    }
    
    /**
     * Get autor
     *
     * @return string
     */
    public function getAutor() {
        return $this->autor;
    }
    
    /**
     * Set titel
     *
     * @param string titel
     *
     * @return KorrekturvorschlagEntity
     */
    public function setTitel($titel) {
        $this->titel = $titel;
    
        return $this;
    }
    
    /**
     * Get titel
     *
     * @return string
     */
    public function getTitel() {
        return $this->titel;
    }
    
    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
}