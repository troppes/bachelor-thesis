<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="tfl_fehler_rptmap")
 */
class SegmentationsFehlerRPTMapEntity {
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="NONE")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="SegmentationsFehlerEntity", fetch="EAGER", inversedBy="fehlerRptMapEntities")
     * @ORM\JoinColumn(name="fk_fehler", referencedColumnName="eid", nullable=false)
     * @var SegmentationsFehlerEntity
     */
    protected $TextFehlerEntity;

    /**
     * @ORM\ManyToOne(targetEntity="RPTMapEntity", fetch="EAGER")
     * @ORM\JoinColumn(name="fk_rptmap", referencedColumnName="id", nullable=false)
     * @var RPTMapEntity
     */
    protected $rptMapEntity;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return RPTMapEntity
     */
    public function getRptMapEntity(): RPTMapEntity
    {
        return $this->rptMapEntity;
    }

    /**
     * @return SegmentationsFehlerEntity
     */
    public function getTextFehlerEntity(): SegmentationsFehlerEntity
    {
        return $this->TextFehlerEntity;
    }
}
