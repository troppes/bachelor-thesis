<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @ORM\Table(name="korrekturvorschlag_benachrichtigungsadresse")
 */
class KorrekturvorschlagBenachrichtigungsadresse {
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    protected $id;
    
    /**
     * @Assert\Email(
     *   message = "Die eMail-Adresse {{ value }} kann nicht validiert werden. Haben Sie sich vertippt?",
     *   checkHost = true
     * )
     * @Assert\NotBlank()
     * @ORM\Column(type="string")
     * @var string
     */
    protected $email;

    /**
     * @return int
     */
    public function getId() {
        return $this->id;
    }

    /**
     * @param $email The email address to set.
     */
    public function setEmail($email) {
        $this->$email = $email;
    }
    
    /**
     * @return string
     */
    public function getEmail() {
        return $this->email;
    }
}

