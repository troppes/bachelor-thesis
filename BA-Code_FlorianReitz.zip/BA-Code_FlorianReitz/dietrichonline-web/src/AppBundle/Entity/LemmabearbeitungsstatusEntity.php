<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity()
 * @ORM\Table(name="lemmabearbeitungsstatus")
 */
class LemmabearbeitungsstatusEntity {
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 * @var integer $id
	 */
	protected  $id;
	
	/**
	 * @ORM\Column(type="string", length=255)
	 * @var string
	 */
	protected $bezeichnung;
	
	/**
	 * @ORM\Column(type="text")
	 * @var string
	 */
	protected $beschreibung;

	/**
	 * Get id
	 *
	 * @return integer
	 */
	public function getId()
	{
		return $this->id;
	}
	
	/**
	 * @return string
	 */
	public function getBezeichnung() {
		return $this->bezeichnung;
	}
	
	/**
	 * @param string $bezeichnung
	 * @return void
	 */
	public function setBezeichnung($bezeichnung) {
		$this->bezeichnung = $bezeichnung;
	}
	
	/**
	 * @return string
	 */
	public function getBeschreibung() {
		return $this->beschreibung;
	}
	
	/**
	 * @param string $beschreibung
	 * @return void
	 */
	public function setBeschreibung($beschreibung) {
		$this->beschreibung = $beschreibung;
	}
}
