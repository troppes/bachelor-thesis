<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="gnd_ddc")
 */
class GndDdcEntity {
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	private $id;

	/**
	 * @ORM\ManyToOne(targetEntity="GndEntity", fetch="EAGER", inversedBy="gndDdcEntities")
	 * @ORM\JoinColumn(name="fk_gnd", referencedColumnName="id", nullable=false)
	 * @var GndEntity
	 */
	protected $gndEntity;
	
	/**
	 * @ORM\ManyToOne(targetEntity="DdcEntity", fetch="EAGER")
	 * @ORM\JoinColumn(name="fk_ddc", referencedColumnName="id", nullable=false)
	 * @var DdcEntity
	 */
	protected $ddcEntity;
	
	/**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
	
	/**
	 * @return GndEntity
	 */
	public function getGndEntity() {
		return $this->gndEntity;
	}
	
	/**
	 * @param GndEntity $gndEntity
	 * @return void
	 */
	public function setGndEntity($gndEntity) {
		$this->gndEntity = $gndEntity;
	}
	
	/**
	 * @return DdcEntity
	 */
	public function getDdcEntity() {
		return $this->ddcEntity;
	}
	
	/**
	 * @param DdcEntity $ddcEntity
	 * @return void
	 */
	public function setDdcEntity($ddcEntity) {
		$this->ddcEntity = $ddcEntity;
	}
}