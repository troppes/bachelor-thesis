<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Context\ExecutionContextInterface;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\AutocompletableRepository")
 * @ORM\Table(name="normliteraturreferenz")
 */
class NormliteraturreferenzEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer $id
     */
    protected $id;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $zdbIdn;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $zdbId;
    const ZDB_ID = 'zdbId';

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $zdbBezeichnung;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $kvkBezeichnung;
    const KVK_BEZEICHNUNG = 'kvkBezeichnung';

    /**
     * @ORM\ManyToOne(targetEntity="LiteraturtypEntity", fetch="EAGER")
     * @ORM\JoinColumn(name="fk_literaturtyp", referencedColumnName="id", nullable=true)
     * @var LiteraturtypEntity
     */
    protected $literaturtypEntity;
    const LITERATURTYP_ENTITY = 'literaturtypEntity';

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $zdbMaterial;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $zdbErscheinungsverlauf;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $zdbErschienen;

    /**
     * @ORM\OneToMany(targetEntity="WerkUrlEntity", mappedBy="normliteraturreferenzEntity", fetch="EXTRA_LAZY")
     * @ORM\OrderBy({"domainName" = "ASC", "bemerkung" = "ASC"})
     */
    protected $werkUrlEntities;

    /**
     * @ORM\Column(type="boolean")
     * @var boolean
     */
    protected $keineWerkUrlGefunden = false;
    const KEINE_WERK_URL_GEFUNDEN = 'keineWerkUrlGefunden';

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $bemerkung;
    const BEMERKUNG = 'bemerkung';

    /**
    /**
     * @return string|null
     */
    public function getBemerkung()
    {
        return $this->bemerkung;
    }

    /**
     * @param string|null $bemerkung
     * @return self
     */
    public function setBemerkung($bemerkung): self
    {
        $this->bemerkung = $bemerkung;
        return $this;
    }

    /**
     * @return boolean
     */
    public function getKeineWerkUrlGefunden(): bool
    {
        return $this->keineWerkUrlGefunden;
    }

    /**
     * @param boolean $keineWerkUrlGefunden
     * @return self
     */
    public function setKeineWerkUrlGefunden(bool $keineWerkUrlGefunden): self
    {
        $this->keineWerkUrlGefunden = $keineWerkUrlGefunden;

        return $this;
    }

    /**
     * @return Collection
     */
    public function getWerkUrlEntities(): Collection
    {
        return $this->werkUrlEntities;
    }

    /**
    /**
     * @return string|null
     */
    public function getZdbErschienen()
    {
        return $this->zdbErschienen;
    }

    /**
     * @param string|null $zdbErschienen
     * @return self
     */
    public function setZdbErschienen($zdbErschienen): self
    {
        $this->zdbErschienen = $zdbErschienen;
        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getZdbErscheinungsverlauf()
    {
        return $this->zdbErscheinungsverlauf;
    }

    /**
     * @param string $zdbErscheinungsverlauf
     * @return self
     */
    public function setZdbErscheinungsverlauf($zdbErscheinungsverlauf): self
    {
        $this->zdbErscheinungsverlauf = $zdbErscheinungsverlauf;
        return $this;
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
    /**
     * @return string|null
     */
    public function getZdbId()
    {
        return $this->zdbId;
    }

    /**
     * @param string|null $zdbId
     * @return self
     */
    public function setZdbId($zdbId): self
    {
        $this->zdbId = $zdbId;
        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getZdbBezeichnung()
    {
        return $this->zdbBezeichnung;
    }

    /**
     * @param string|null $zdbBezeichnung
     * @return self
     */
    public function setZdbBezeichnung($zdbBezeichnung): self
    {
        $this->zdbBezeichnung = $zdbBezeichnung;
        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getZdbMaterial()
    {
        return $this->zdbMaterial;
    }

    /**
     * @param string $zdbMaterial
     * @return self
     */
    public function setZdbMaterial(string $zdbMaterial): self
    {
        $this->zdbMaterial = $zdbMaterial;
        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getKvkBezeichnung()
    {
        return $this->kvkBezeichnung;
    }

    /**
     * @param string $kvkBezeichnung
     * @return self
     */
    public function setKvkBezeichnung(string $kvkBezeichnung): self
    {
        $this->kvkBezeichnung = $kvkBezeichnung;
        return $this;
    }

    /**
     * Returns the html decoded Normliteraturreferenz-Bezeichnung.
     * <p>
     * Decides between the following cases:
     * <ol>
     * <li>zdbId is set -> returns the zdbBezeichnung
     * <li>kvkBezeichnung is set -> returns the kvkBezeichnung
     * <li>empty -> returns <code>''</code>
     * </ol>
     *
     * @return string The decoded html string, otherwise an empty string.
     */
    public function getNormlitRefBezeichnungHtmlDecoded(): string
    {
        $result = '';

        if (!empty($this->zdbId)) {
            $result = html_entity_decode($this->zdbBezeichnung);
        } else if (!empty($this->kvkBezeichnung)) {
            $result = html_entity_decode($this->kvkBezeichnung);
        }

        return $result;
    }

    /**
     * @return LiteraturtypEntity|null
     */
    public function getLiteraturtypEntity()
    {
        return $this->literaturtypEntity;
    }

    /**
     * @param LiteraturtypEntity $literaturtypEntity
     * @return self
     */
    public function setLiteraturtypEntity(LiteraturtypEntity $literaturtypEntity): self
    {
        $this->literaturtypEntity = $literaturtypEntity;
        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getZdbIdn()
    {
        return $this->zdbIdn;
    }

    /**
     * @param string|null $zdbIdn
     * @return void
     */
    public function setZdbIdn($zdbIdn)
    {
        $this->zdbIdn = $zdbIdn;
    }

    /**
     * @see https://symfony.com/doc/3.4/reference/constraints/Callback.html
     * @Assert\Callback
     * @param ExecutionContextInterface $context
     * @param $payload
     */
    public function validateKvkOrZdbDataExists(
        ExecutionContextInterface $context, /** @noinspection PhpUnusedParameterInspection */
        $payload
    )
    {
        if (!($this->zdbDataIsSet() || $this->kvkDataIsSet())) {
            $msg = 'Es müssen entweder alle ZDB- oder KVK-Daten vollständig angegeben werden.';
            $context->buildViolation($msg)
                ->atPath(self::ZDB_ID)
                ->addViolation();
            $context->buildViolation($msg)
                ->atPath(self::KVK_BEZEICHNUNG)
                ->addViolation();
        }
    }

    /**
     * @return bool
     */
    private function zdbDataIsSet(): bool
    {
        return isset($this->zdbId, $this->zdbIdn, $this->zdbBezeichnung);
    }

    /**
     * @return bool
     */
    private function kvkDataIsSet(): bool
    {
        return isset($this->kvkBezeichnung);
    }
}
