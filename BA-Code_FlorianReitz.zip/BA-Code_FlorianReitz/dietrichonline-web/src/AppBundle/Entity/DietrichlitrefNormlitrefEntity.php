<?php

namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\DietrichlitrefNormlitrefRepository")
 * @ORM\Table(name="dietrichliteraturreferenz_normliteraturreferenz")
 */
class DietrichlitrefNormlitrefEntity
{
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer $id
     */
    protected $id;

    /**
     * @ORM\ManyToOne(targetEntity="DietrichliteraturreferenzEntity", fetch="EAGER", inversedBy="dietrichlitrefNormlitrefEntities")
     * @ORM\JoinColumn(name="fk_dietrichliteraturreferenz", referencedColumnName="id", nullable=false)
     * @var DietrichliteraturreferenzEntity
     */
    protected $dietrichliteraturreferenzEntity;
    const DIETRICHLITERATURREFERENZ_ENTITY = 'dietrichliteraturreferenzEntity';

    /**
     * @ORM\ManyToOne(targetEntity="NormliteraturreferenzEntity", fetch="EAGER")
     * @ORM\JoinColumn(name="fk_normliteraturreferenz", referencedColumnName="id", nullable=false)
     * @var NormliteraturreferenzEntity
     */
    protected $normliteraturreferenzEntity;
    const NORMLITERATURREFERENZ_ENTITY = 'normliteraturreferenzEntity';

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $normkollation;
    const NORMKOLLATION = 'normkollation';

    /**
     * @ORM\OneToMany(targetEntity="BandUrlEntity", mappedBy="dietrichlitrefNormlitrefEntity", fetch="EXTRA_LAZY")
     * @ORM\OrderBy({"domainName" = "ASC", "bemerkung" = "ASC"})
     * @var Collection
     */
    protected $bandUrlEntities;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $bandUrl;

    /**
     * @ORM\Column(type="text")
     * @var string
     */
    protected $bandUrlBemerkung;

    /**
     * @ORM\Column(type="boolean")
     * @var boolean
     */
    protected $keineBandUrlGefunden = false;
    const KEINE_BAND_URL_GEFUNDEN = 'keineBandUrlGefunden';

    /**
     * @return boolean
     */
    public function getKeineBandUrlGefunden(): bool
    {
        return $this->keineBandUrlGefunden;
    }

    /**
     * @param boolean $keineBandUrlGefunden
     * @return DietrichlitrefNormlitrefEntity
     */
    public function setKeineBandUrlGefunden($keineBandUrlGefunden): self
    {
        $this->keineBandUrlGefunden = $keineBandUrlGefunden;

        return $this;
    }

    /**
     * @return string|null
     */
    public function getBandUrlBemerkung()
    {
        return $this->bandUrlBemerkung;
    }

    /**
     * @param string $bandUrlBemerkung
     * @return DietrichlitrefNormlitrefEntity
     */
    public function setBandUrlBemerkung(string $bandUrlBemerkung): self
    {
        $this->bandUrlBemerkung = $bandUrlBemerkung;

        return $this;
    }

    /**
    /**
     * @return string|null
     */
    public function getBandUrl()
    {
        return $this->bandUrl;
    }

    /**
     * @param string $bandUrl
     * @return DietrichlitrefNormlitrefEntity
     */
    public function setBandUrl(string $bandUrl): self
    {
        $this->bandUrl = $bandUrl;

        return $this;
    }

    /**
     * @return Collection
     */
    public function getBandUrlEntities(): Collection
    {
        return $this->bandUrlEntities;
    }

    /**
    /**
     * @return string|null
     */
    public function getNormkollation()
    {
        return $this->normkollation;
    }

    /**
     * @param string $normkollation
     * @return DietrichlitrefNormlitrefEntity
     */
    public function setNormkollation(string $normkollation): self
    {
        $this->normkollation = $normkollation;

        return $this;
    }

    /**
     * Get id
     *
     * @return integer|null
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set dietrichliteraturreferenzEntity
     *
     * @param DietrichliteraturreferenzEntity $dietLitrefEntity
     *
     * @return DietrichlitrefNormlitrefEntity
     */
    public function setDietrichliteraturreferenzEntity(DietrichliteraturreferenzEntity $dietLitrefEntity): self
    {
        $this->dietrichliteraturreferenzEntity = $dietLitrefEntity;

        return $this;
    }

    /**
     * Get dietrichliteraturreferenzEntity
     *
     * @return DietrichliteraturreferenzEntity|null
     */
    public function getDietrichliteraturreferenzEntity()
    {
        return $this->dietrichliteraturreferenzEntity;
    }

    /**
     * Set normliteraturreferenzEntity
     *
     * @param NormliteraturreferenzEntity $normliteraturreferenzEntity
     *
     * @return DietrichlitrefNormlitrefEntity
     */
    public function setNormliteraturreferenzEntity(NormliteraturreferenzEntity $normliteraturreferenzEntity): self
    {
        $this->normliteraturreferenzEntity = $normliteraturreferenzEntity;

        return $this;
    }

    /**
     * Get normliteraturreferenzEntity
     *
     * @return NormliteraturreferenzEntity|null
     */
    public function getNormliteraturreferenzEntity()
    {
        return $this->normliteraturreferenzEntity;
    }
}
