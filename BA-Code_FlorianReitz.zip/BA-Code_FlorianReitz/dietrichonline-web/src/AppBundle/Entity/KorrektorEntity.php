<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity()
 * @ORM\Table(name="korrektor")
 */
class KorrektorEntity {
    /**
     * @ORM\Column(type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     * @var integer
     */
    protected $id;
    
    /**
     * @Assert\Email(
     *   message = "Die eMail-Adresse {{ value }} kann nicht validiert werden. Haben Sie sich vertippt?",
     *   checkHost = true
     * )
     * @ORM\Column(type="string")
     * @var string
     */
    protected $email;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $vorname;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $nachname;
    
    /**
     * @ORM\Column(type="string")
     * @var string
     */
    protected $titel;
    
    public function update(KorrektorEntity $korrektor) {
        $this->email = $korrektor->email;
        $this->titel = $korrektor->titel;
        $this->vorname = $korrektor->vorname;
        $this->nachname = $korrektor->nachname;
    }
    
    /**
     * Set titel
     *
     * @param string titel
     *
     * @return KorrektorEntity
     */
    public function setTitel($titel) {
        $this->titel = $titel;
    
        return $this;
    }
    
    /**
     * Get titel
     *
     * @return string
     */
    public function getTitel() {
        return $this->titel;
    }
    
    /**
     * Set nachname
     *
     * @param string nachname
     *
     * @return KorrektorEntity
     */
    public function setNachname($nachname) {
        $this->nachname = $nachname;
    
        return $this;
    }
    
    /**
     * Get nachname
     *
     * @return string
     */
    public function getNachname() {
        return $this->nachname;
    }
    
    /**
     * Set vorname
     *
     * @param string vorname
     *
     * @return KorrektorEntity
     */
    public function setVorname($vorname) {
        $this->vorname = $vorname;
    
        return $this;
    }
    
    /**
     * Get vorname
     *
     * @return string
     */
    public function getVorname() {
        return $this->vorname;
    }
    
    /**
     * Set email
     *
     * @param string email
     *
     * @return KorrektorEntity
     */
    public function setEmail($email) {
        $this->email = $email;
    
        return $this;
    }
    
    /**
     * Get email
     *
     * @return string
     */
    public function getEmail() {
        return $this->email;
    }
}

