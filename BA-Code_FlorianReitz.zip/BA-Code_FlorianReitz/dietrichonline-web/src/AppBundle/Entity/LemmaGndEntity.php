<?php
namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity
 * @ORM\Table(name="lemma_gnd")
 */
class LemmaGndEntity
{
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	private $id;
	
	/**
	 * @ORM\ManyToOne(targetEntity="LemmaEntity", fetch="EAGER", inversedBy="lemmaGNDEntities")
	 * @ORM\JoinColumn(name="fk_lemma", referencedColumnName="id", nullable=false)
	 * @var LemmaEntity
	 */
	private $lemmaEntity;
	
	/**
	 * @ORM\ManyToOne(targetEntity="GndEntity", fetch="EAGER")
	 * @ORM\JoinColumn(name="fk_gnd", referencedColumnName="id", nullable=false)
	 * @var GndEntity
	 */
	private $gndEntity;

	/**
	 * @param field_type $id
	 */
	public function setId($id)
	{
		$this->id = $id;
	}

	/**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }
    
    /**
     * @return LemmaEntity
     */
    public function getLemmaEntity()
    {
    	return $this->lemmaEntity;
    }
    
    /**
     * @return GndEntity
     */
    public function getGndEntity()
    {
    	return $this->gndEntity;
    }
    
    public function setLemmaEntity(LemmaEntity $lemmaEntity) {
    	$this->lemmaEntity = $lemmaEntity;
    }
    
    public function setGndEntity(GndEntity $gndEntity) {
    	$this->gndEntity = $gndEntity;
    }
}
