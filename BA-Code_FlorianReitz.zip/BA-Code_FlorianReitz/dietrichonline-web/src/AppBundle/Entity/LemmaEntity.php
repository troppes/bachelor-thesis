<?php
namespace AppBundle\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity(repositoryClass="AppBundle\Repository\LemmaRepository")
 * @ORM\Table(name="lemma")
 */
class LemmaEntity
{


    /**
     * Constants for setting Categories other than Letters
     */
    const NOT_A_TO_Z_CHARACTER = 'not_a-z';
    const DELETED = 'geloeschte';


	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	protected $id;

	/**
	 * @ORM\Column(type="text")
	 * @Assert\NotBlank()
	 */
	protected $bezeichnung;
	
	/**
	 * @ORM\Column(type="text")
	 * @var string
	 * @Assert\Regex(
     *   pattern="/^[\S ]*$/u",
     *   message="Die Lemmabezeichnung darf keine Whitespaces außer Leerzeichen beinhalten."
     * )
	 */
	protected $originalBezeichnung;
	
	/**
	 * @ORM\Column(type="text")
	 * @Assert\Regex(
     *   pattern="/^[\S ]*$/u",
     *   message="Die Erweiterung darf keine Whitespaces außer Leerzeichen beinhalten."
     * )
	 * @var string
	 */
	protected $erweiterung;
	
	/**
	 * @ORM\Column(type="text")
	 * @Assert\Regex(
     *   pattern="/^[\S ]*$/u",
     *   message="Der Original-Homonymzusatz darf keine Whitespaces außer Leerzeichen beinhalten."
     * )
	 * @var string
	 */
	protected $originalHomonymZusatz;
	
	/**
	 * @ORM\Column(type="text")
	 * @Assert\Regex(
     *   pattern="/^[\S ]*$/u",
     *   message="Die neue Homonymzusatz darf keine Whitespaces außer Leerzeichen beinhalten."
     * )
	 * @var string
	 */
	protected $neuerHomonymZusatz;

	/**
	 * @ORM\Column(type="text")
	 */
	private $allgemeinebemerkung;
	
	/**
	 * @ORM\Column(type="integer")
	 */
	private  $ist_gnd_verzeichnet;
	
	/**
	 * @ORM\Column(type="integer")
	 */
	private  $ist_geloescht;
	
	/**
	 * @ORM\ManyToOne(targetEntity="LemmabearbeitungsstatusEntity", fetch="LAZY")
	 * @ORM\JoinColumn(name="fk_lemmabearbeitungsstatus", referencedColumnName="id", nullable=false)
	 * @var LemmabearbeitungsstatusEntity
	 */
	protected $lemmabearbeitungsstatusEntity;
	
	/**
	 * @ORM\Column(type="text")
	 */
	private $verweis;

    /**
     * @ORM\Column(type="integer")
     */
    private $fk_lemmabearbeitungsstatus;

	/**
	 * @ORM\OneToMany(targetEntity="LemmaGndEntity", mappedBy="lemmaEntity", fetch="EXTRA_LAZY")
	 * @var Collection
	 */
	private $lemmaGNDEntities;
	
	/**
	 * @ORM\OneToMany(targetEntity="ArtikelEntity", mappedBy="lemmaEntity", fetch="EXTRA_LAZY")
	 * @var array
	 */
	protected $artikelEntities;

	/**
     * @ORM\ManyToOne(targetEntity="LemmaEntity", inversedBy="groupedLemmas")
     * @ORM\JoinColumn(name="fk_master_lemma", referencedColumnName="id", nullable=true)
	 * @var LemmaEntity|null
	 */
	private $masterLemma;

	/**
     * @ORM\OneToMany(targetEntity="LemmaEntity", mappedBy="masterLemma", fetch="EXTRA_LAZY")
	 * @var Collection
	 */
	private $groupedLemmas;

	public function getGroupedLemmas(): Collection
    {
	    return $this->groupedLemmas;
	}

    /**
     * Get masterLemma
     *
     * @return LemmaEntity|null
     */
    public function getMasterLemma()
    {
        return $this->masterLemma;
    }

    /**
     * @param $masterLemma LemmaEntity|null
     *
     * @return LemmaEntity
     */
	public function setMasterLemma($masterLemma): LemmaEntity
    {
	    $this->masterLemma = $masterLemma;

	    if ($masterLemma === null) {
            return $this;
        }

        // check if $masterLemma->groupedLemmas needs update
        /** @var LemmaEntity $lemma */
        foreach ($masterLemma->groupedLemmas as $lemma) {
            $isContainedInGroupedLemmas = $lemma->getId() === $this->getId();
            if ($isContainedInGroupedLemmas) {
                return $this;
            }
        }

        // update $masterLemma->groupedLemmas
        $masterLemma->groupedLemmas->add($this);

        return $this;
	}

	public function isMasterLemma(): bool
    {
        // every master_lemma references itself
	    return $this->getMasterLemma() !== null && $this->getId() === $this->getMasterLemma()->getId();
    }

    public function isSubLemma(): bool
    {
        return $this->getMasterLemma() !== null && $this->getId() !== $this->getMasterLemma()->getId();
    }
	
	public function getVollstaendigeBezeichnung(): string
    {
	    $homonymZusatz = isset($this->originalHomonymZusatz) && ($this->originalHomonymZusatz !== '') ? ' ['.$this->originalHomonymZusatz.']' : '';
	    $homonymZusatz .= isset($this->neuerHomonymZusatz) && ($this->neuerHomonymZusatz !== '')? ' ['.$this->neuerHomonymZusatz.']' : '';
	    return $this->originalBezeichnung.$this->erweiterung.$homonymZusatz;
	}
	
  	/**
     * @return array
     */
    public function getArtikelEntities()
    {
        return $this->artikelEntities;
    }

    /**
     * @param array $artikelEntities
     */
    public function setArtikelEntities($artikelEntities)
    {
        $this->artikelEntities = $artikelEntities;
    }

    /**
	 * @return Collection
	 */
	public function getLemmaGNDEntities(): Collection
    {
        if ($this->isSubLemma()) {
            return $this->getMasterLemma()->lemmaGNDEntities;
        }
        return $this->lemmaGNDEntities;
	}

	/**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set bezeichnung
     *
     * @param string $bezeichnung
     *
     * @return LemmaEntity
     */
    public function setBezeichnung($bezeichnung)
    {
        $this->bezeichnung = $bezeichnung;

        return $this;
    }

    /**
     * Get bezeichnung
     *
     * @return string
     */
    public function getBezeichnung()
    {
        return $this->bezeichnung;
    }

    /**
     * Set allgemeinebemerkung
     *
     * @param string $allgemeinebemerkung
     *
     * @return LemmaEntity
     */
    public function setAllgemeinebemerkung($allgemeinebemerkung)
    {
        $this->allgemeinebemerkung = $allgemeinebemerkung;

        return $this;
    }

    /**
     * Get allgemeinebemerkung
     *
     * @return string
     */
    public function getAllgemeinebemerkung()
    {
        return $this->allgemeinebemerkung;
    }

    /**
     * Set istGndVerzeichnet
     *
     * @param integer $istGndVerzeichnet
     *
     * @return LemmaEntity
     */
    public function setIstGndVerzeichnet($istGndVerzeichnet)
    {
        $this->ist_gnd_verzeichnet = $istGndVerzeichnet;

        return $this;
    }

    /**
     * Get istGndVerzeichnet
     *
     * @return integer
     */
    public function getIstGndVerzeichnet()
    {
        return $this->ist_gnd_verzeichnet;
    }

    /**
     * Set istGeloescht
     *
     * @param integer $istGeloescht
     *
     * @return LemmaEntity
     */
    public function setIstGeloescht($istGeloescht)
    {
        $this->ist_geloescht = $istGeloescht;

        return $this;
    }

    /**
     * Get istGeloescht
     *
     * @return integer
     */
    public function getIstGeloescht()
    {
        return $this->ist_geloescht;
    }

    /**
     * Set fkLemmabearbeitungsstatus
     *
     * @param integer $fkLemmabearbeitungsstatus
     *
     * @return LemmaEntity
     */
    public function setFkLemmabearbeitungsstatus($fkLemmabearbeitungsstatus)
    {
        $this->fk_lemmabearbeitungsstatus = $fkLemmabearbeitungsstatus;

        return $this;
    }

    /**
     * Get fkLemmabearbeitungsstatus
     *
     * @return integer
     */
    public function getFkLemmabearbeitungsstatus()
    {
        return $this->fk_lemmabearbeitungsstatus;
    }
    
    /**
     * Set verweis
     *
     * @param string $verweis
     *
     * @return LemmaEntity
     */
    public function setVerweis($verweis) 
    {
    	$this->verweis = $verweis;
    	
    	return $this;
    }
    
    /**
     * Get bezeichnung
     *
     * @return string
     */
    public function getVerweis() {
    	return $this->verweis;
    }
	
	/**
	 * @return string
	 */
	public function getOriginalBezeichnung() {
		return $this->originalBezeichnung;
	}
	
	/**
	 * @param string $originalBezeichnung
	 * @return void
	 */
	public function setOriginalBezeichnung($originalBezeichnung) {
		$this->originalBezeichnung = $originalBezeichnung;
	}
	
	/**
	 * @return string
	 */
	public function getOriginalHomonymZusatz() {
		return $this->originalHomonymZusatz;
	}
	
	/**
	 * @param string $originalHomonymZusatz
	 * @return void
	 */
	public function setOriginalHomonymZusatz($originalHomonymZusatz) {
		$this->originalHomonymZusatz = $originalHomonymZusatz;
	}
	
	/**
	 * @return string
	 */
	public function getNeuerHomonymZusatz() {
		return $this->neuerHomonymZusatz;
	}
	
	/**
	 * @param string $neuerHomonymZusatz
	 * @return void
	 */
	public function setNeuerHomonymZusatz($neuerHomonymZusatz) {
		$this->neuerHomonymZusatz = $neuerHomonymZusatz;
	}
	
	/**
	 * @return string
	 */
	public function getErweiterung() {
	    return $this->firstCharIsLetter($this->erweiterung) ? 
	       ' '.$this->erweiterung : $this->erweiterung;
	}
	
	/**
	 * @param string $erweiterung
	 * @return void
	 */
	public function setErweiterung($erweiterung) {
	    $this->erweiterung = $this->firstCharIsLetter($erweiterung) ? 
	       ' '.$erweiterung : $erweiterung;
	}
	
	private function firstCharIsLetter($string) {
	    return preg_match('/^\p{L}/u', $string) ? true : false;
	}
	
	/**
	 * @return LemmabearbeitungsstatusEntity
	 */
	public function getLemmabearbeitungsstatusEntity() {
		return $this->lemmabearbeitungsstatusEntity;
	}
	
	/**
	 * @param LemmabearbeitungsstatusEntity $lemmabearbeitungsstatusEntity
	 * @return void
	 */
	public function setLemmabearbeitungsstatusEntity($lemmabearbeitungsstatusEntity) {
		$this->lemmabearbeitungsstatusEntity = $lemmabearbeitungsstatusEntity;
	}
	
	public function isNew() {
	    if ($this->lemmabearbeitungsstatusEntity->getBezeichnung() == 'neu') {
	        return true;
	    }
	    if (count($this->lemmaGNDEntities) == 0) {
	        return true;
	    }
	    $gndDdcEntityFound = false;
	    foreach ($this->lemmaGNDEntities as $lemmaGndEntity) {
	        /* @var $lemmaGndEntity LemmaGndEntity */
	        if(count($lemmaGndEntity->getGndEntity()->getGndDdcEntities()) > 0) {
	            $gndDdcEntityFound = true;
	            break;
	        }
	    }
	    // is considered new, if no DDC data is connected
	    return !$gndDdcEntityFound;
	}
	
	public function istUnklar() {
	    return $this->lemmabearbeitungsstatusEntity->getBezeichnung() == 'unklar';
	}
}
