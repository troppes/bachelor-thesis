<?php

namespace AppBundle\Crawler;

use \DOMDocument;
use \DOMXPath;
use AppBundle\Entity\GndEntity;
use AppBundle\Entity\DdcEntity;

/**
 * Das MARC21-xml wird hier beschrieben: https://d-nb.info/1135147647/34
 * @author weiss
 */
class DnbGndMarc21 {
    const DNB_ACCESS_TOKEN = 'b14dbb86b7e81ffbf2a768bdab0e2d1';

    // GND Generaltypes:
    // http://www.dnb.de/SharedDocs/Downloads/EN/DNB/standardisierung/inhaltserschliessung/entitaetenSatztypen.pdf?__blob=publicationFile
    const GND_TYPE_KOERPERSCHAFT = 'b';
    const GND_TYPE_KONFERENZ = 'f';
    const GND_TYPE_GEOGRAFIKUM = 'g';
    const GND_TYPE_PERSON_NICHT_INDIVID = 'n';
    const GND_TYPE_PERSON_INDIVID = 'p';
    const GND_TYPE_SACHBEGRIFF = 's';
    const GND_TYPE_WERK = 'u';

    public static function retrieveGndAndDdcEntitiesByNid($nid) {
        $url = 'https://services.dnb.de/sru/authorities?version=1.1&accessToken=' . self::DNB_ACCESS_TOKEN
            . '&operation=searchRetrieve&recordSchema=MARC21-xml&query=nid%3D' . $nid;

        $streamContext = stream_context_create([
            "ssl" => array(
                "verify_peer" => false,
                "verify_peer_name" => false,
            )
        ]);

        $xml = @file_get_contents($url, false, $streamContext);

        if ($xml === false)
        {
            throw new ConnectionTimeoutException($url);
        }

        $doc = new DOMDocument();
        $doc->loadXML($xml);

        $xpath = new DOMXpath($doc);
        $xpath->registerNamespace('std', 'http://www.loc.gov/zing/srw/');
        $xpath->registerNamespace('marc', 'http://www.loc.gov/MARC21/slim');

        /** @var string $numberOfRecords */
        $numberOfRecords = DomNodeListUtils::getValueOfFirstItem($xpath->query('/descendant::std:numberOfRecords'));
        if (is_null($numberOfRecords))
        {
            // TODO: exception? This only happens if the server is delivering an unexpected response.
            return null;
        }
        if ($numberOfRecords !== '1')
        {
            return null;
        }

        $result = self::retrieveStdData($xpath);

        $type = self::findGeneralType($xpath);

        switch ($type) {
            case self::GND_TYPE_KOERPERSCHAFT:
                $schlagwort = self::findKoerperschaft($xpath);
                break;

            case self::GND_TYPE_KONFERENZ:
                $schlagwort = self::findKonferenz($xpath);
                break;

            case self::GND_TYPE_GEOGRAFIKUM:
                $schlagwort = self::findGeografikum($xpath);
                break;

            case self::GND_TYPE_PERSON_NICHT_INDIVID:
                $schlagwort = self::findPerson($xpath);
                break;

            case self::GND_TYPE_PERSON_INDIVID:
                $schlagwort = self::findPerson($xpath);
                break;

            case self::GND_TYPE_SACHBEGRIFF:
                $schlagwort = self::findSachbegriff($xpath);
                break;

            case self::GND_TYPE_WERK:
                $schlagwort = self::findWerk($xpath);
                break;

            default:
                return null;

        }

        $result->gndEntity->setSchlagwort($schlagwort);

        return $result;
    }

    protected static function retrieveStdData(\DOMXPath $xpath) {
        $gndEntity = new GndEntity();
        $gndEntity->setNummer(self::findGndNumber($xpath));
        $ddcEntities = self::findDdcEntities($xpath);

        $result = new DnbGndMarc21Result();
        $result->gndEntity = $gndEntity;
        $result->ddcEntities = $ddcEntities;
        return $result;
    }

    protected static function findDdcEntities(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="083"]';
        $ddcNodeList = $xpath->query($xpathQuery);
        $ddcNotationen = [];
        foreach ($ddcNodeList as $ddcNode) {
            /* @var $ddcNode \DOMNode */
            $ddcNotation = DomNodeListUtils::getValueOfFirstItem($xpath->query('marc:subfield[@code="a"]', $ddcNode));
            $hilfsTabelle = DomNodeListUtils::getValueOfFirstItem($xpath->query('marc:subfield[@code="z"]', $ddcNode));
            if ($hilfsTabelle !== null) {
                $ddcNotation = 'T' . $hilfsTabelle . '--' . $ddcNotation;
            }
            $ddcNotationen[] = $ddcNotation;
        }
        $ddcEntities = [];
        foreach ($ddcNotationen as $ddcNotation) {
            $ddcEntity = new DdcEntity();
            $ddcEntity->setNotation($ddcNotation);
            $ddcEntities[] = $ddcEntity;
        }
        return $ddcEntities;
    }

    protected static function findSachbegriff(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="150"]/marc:subfield[@code="a"]';
        $sachbegriff = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));

        $xpathQuery = '/descendant::marc:datafield[@tag="150"]/marc:subfield[@code="g"]';
        $zusatz = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        if (!is_null($zusatz)) {
            $sachbegriff .= ' [' . $zusatz . ']';
        }

        return $sachbegriff;
    }

    protected static function findWerk(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="130"]/marc:subfield[@code="a"]';
        $titel = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        $xpathQuery = '/descendant::marc:datafield[@tag="130"]/marc:subfield[@code="p"]';
        $teil = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        if (!is_null($teil)) {
            $titel .= '. ' . $teil;
        }

        if (is_null($titel)) {
            $xpathQuery = '/descendant::marc:datafield[@tag="100"]/marc:subfield[@code="t"]';
            $titel = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        }

        return $titel;
    }

    protected static function findPerson(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="100"]/marc:subfield[@code="a"]';
        $name = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        $xpathQuery = '/descendant::marc:datafield[@tag="100"]/marc:subfield[@code="c"]';
        $name .= ', ' . DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        return $name;
    }

    protected static function findGeografikum(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="151"]/marc:subfield[@code="a"]';
        $name = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        $xpathQuery = '/descendant::marc:datafield[@tag="151"]/marc:subfield[@code="g"]';
        $homonymZusatz = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        if ($homonymZusatz)
        {
            $name .= ' [' . $homonymZusatz . ']';
        }
        return $name;
    }

    protected static function findKonferenz(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="111"]/marc:subfield[@code="a"]';
        $hauptkonferenzname = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        $xpathQuery = '/descendant::marc:datafield[@tag="111"]/marc:subfield[@code="c"]';
        $ort = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        $xpathQuery = '/descendant::marc:datafield[@tag="111"]/marc:subfield[@code="d"]';
        $datum = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        return $hauptkonferenzname . ' (' . $ort . ' ' . $datum . ')';
    }

    protected static function findKoerperschaft(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="110"]/marc:subfield[@code="a"]';
        $koerperschaft = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));

        $xpathQuery = '/descendant::marc:datafield[@tag="110"]/marc:subfield[@code="b"]';
        $unterkoerperschaft = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));

        $xpathQuery = '/descendant::marc:datafield[@tag="110"]/marc:subfield[@code="g"]';
        $zusatz = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));

        $koerperschaft .= isset($unterkoerperschaft) ? '. ' . $unterkoerperschaft : '';
        $koerperschaft .= isset($zusatz) ? ' (' . $zusatz . ')' : '';
        return $koerperschaft;
    }

    protected static function findGndNumber(\DOMXPath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="035"]/marc:subfield[@code="a"][starts-with(text(),"(DE-588)")]';
        $raw = DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
        $gndNumber = substr($raw, strlen("(DE-588)"));
        return $gndNumber;
    }

    protected static function findGeneralType(DOMXpath $xpath) {
        $xpathQuery = '/descendant::marc:datafield[@tag="075"][./marc:subfield/text()="gndgen"]/marc:subfield[@code="b"]';
        return DomNodeListUtils::getValueOfFirstItem($xpath->query($xpathQuery));
    }
}

class DnbGndMarc21Result {
    /**
     * @var GndEntity
     */
    public $gndEntity;

    /**
     * @var array
     */
    public $ddcEntities;
}
