<?php
namespace AppBundle\Crawler;

use Symfony\Component\DomCrawler\Crawler;
use AppBundle\Entity\NormliteraturreferenzEntity;

class ZdbSuchergebnis implements \Countable, \IteratorAggregate {
	protected $baseUri;

	protected $count;
	
	public function getIterator() {
		return new ZdbSuchergebnisIterator($this);
	}
	
	public function __construct($baseUri, $count = null) {
		$this->baseUri = $baseUri;
		if (is_null($count)) {
			$url = $this->baseUri.'SHW?FRST=1';		
			// TODO: Exception abfangen, falls Server nicht erreichbar
			$html = file_get_contents($url);
			$crawler = new Crawler($html);
			$itemCountNode = $crawler->filterXPath('descendant::strong[attribute::class="pages"][1]')->getNode(0);
			if (is_null($itemCountNode)) {
				$sessionIsExpired = strpos($html, 'Die bisherigen Ergebnisse sind nicht mehr verf&uuml;gbar') !== false;
				if ($sessionIsExpired) {
					throw new \UnexpectedValueException('ZDB Session ist abgelaufen.');
				} else {
					throw new \Exception('Kann weder html node für die Anzahl Suchtreffer finden, noch kann bestätigt werden dass keine Suchtreffer vorhanden sind.');
				}
			}
			$itemCountHtml = $itemCountNode->textContent;
			$output = array();
			/* um die Lücken zwischen den Wörtern zu matchen, nutze [\W\D],
			 * da irgendein Steuerzeichen statt einem Leerzeichen verwendet wird. */
			preg_match("/\d+[\W\D]von[\W\D](\d+)/u", $itemCountHtml, $output);
			$this->count = (int) $output[1];
		} else {
			$this->count = $count;			
		}
	}
	
	public function findNormliteraturreferenz($nummer) {
		$zdbNormlitrefUrl = $this->generateDetailViewUrl($nummer);
		// TODO: Exception abfangen, falls Server nicht erreichbar
		$html = file_get_contents($zdbNormlitrefUrl);
		$crawler = new Crawler($html);
		
		$zdbIdNode = $crawler->filterXPath('descendant::td[strong/div/text()="ZDB-ID: "]/following-sibling::td/div')->getNode(0);
		$zdbId = $zdbIdNode->textContent;
		
		$zdbBezeichnungNode = $crawler->filterXPath('descendant::td[strong/div/text()="Titel: "]/following-sibling::td/div')->getNode(0);
		$zdbBezeichnung = $zdbBezeichnungNode->textContent;
		
		$zdbMaterialNode = $crawler->filterXPath('descendant::img[attribute::id="maticon"]/attribute::src')->getNode(0);
		$zdbMaterialSrcValue = $zdbMaterialNode->value;
		// remove path information to get raw material value
		$zdbMaterial = strtr($zdbMaterialSrcValue, array(
			'http://images.opac.dnb.de:80/img_psi/2.0/icons/' => '',
			'.gif' => ''
		));
		
		$zdbErscheinungsverlaufNode = $crawler->filterXPath('descendant::td[strong/div/text()="Erscheinungsverlauf: "]/following-sibling::td/div')->getNode(0);
		if (isset($zdbErscheinungsverlaufNode)) {
			$zdbErscheinungsverlauf = $zdbErscheinungsverlaufNode->textContent;
		} else {
			$zdbErscheinungsverlauf = null;
		}

		$zdbErschienenNode = $crawler->filterXPath('descendant::td[strong/div/text()="Erschienen: "]/following-sibling::td/div')->getNode(0);
		if (isset($zdbErschienenNode)) {
			$zdbErschienen = $zdbErschienenNode->textContent;
		} else {
			$zdbErschienen = null;
		}
		
		$normLitref = new NormliteraturreferenzEntity();
		$normLitref
			->setZdbId($zdbId)
			->setZdbBezeichnung($zdbBezeichnung)
			->setZdbMaterial($zdbMaterial)
			->setZdbErschienen($zdbErschienen)
			->setZdbErscheinungsverlauf($zdbErscheinungsverlauf);
		return $normLitref;
	}
	
	public function generateDetailViewUrl($suchtrefferNummer) {
		return $this->baseUri.'SHW?FRST='.$suchtrefferNummer;
	}
	
	public function generateBesitznachweisUrl($suchtrefferNummer) {
		return $this->baseUri.'PRS=HOL/SHW?FRST='.$suchtrefferNummer;
	}
	
	public function count() {
		return $this->count;
	}
	
	public function getBaseUri() {
		return $this->baseUri;
	}
}

class ZdbSuchergebnisIterator implements \Iterator {
	protected $zdbSuchergebnis;
	protected $position;
	
	public function __construct(ZdbSuchergebnis $zdbSuchergebnis) {
		$this->zdbSuchergebnis = $zdbSuchergebnis;
		$this->rewind();
	}

	public function current () {
		return $this->zdbSuchergebnis->findNormliteraturreferenz($this->position);
	}

	public function next () {
		++$this->position;
	}

	public function key () {
		return $this->position;
	}

	public function valid () {
		return $this->position <= $this->zdbSuchergebnis->count();
	}

	public function rewind () {
		$this->position = 1;
	}
}
