<?php

namespace AppBundle\Crawler;


use Throwable;

/**
 * The ConnectionTimeoutException will be
 *
 * @package AppBundle\Crawler
 * @author Martin Kock <kock@uni-trier.de>
 */
class ConnectionTimeoutException
    extends \Exception
{
    /** @var string The url to connect while timeout */
    private $url;

    /**
     * ConnectionTimeoutException constructor.
     *
     * @param string $url The url to connect while timeout
     */
    public function __construct(string $url)
    {
        parent::__construct(sprintf('The server <%s> is not available.', $url), 0, null);
        $this->url = $url;
    }

    /**
     * Returns the error message.
     *
     * @return string
     */
    public function errorMessage(): string
    {
        return sprintf('The server <%s> is not available.', $this->url);
    }
}
