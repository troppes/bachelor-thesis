<?php
namespace AppBundle\Crawler;

use Symfony\Component\DomCrawler\Crawler;
use \Exception;

class ZdbSuche {
	const KATEGORIE_STW = 'Stichwort (allgemein) [STW]';
	const KATEGORIE_STW_WERT = '8509';
	const JUNKTOR_UND = 'und';
	const JUNKTOR_UND_WERT = '*';
	const KATEGORIEN = array(
		'Stichwort (allgemein) [STW]' => '8509',
		'Titelanfang [TST]' => '8508',
		'Titel (Stichwort) [TIT]' => '4',
		'Körperschaftsname (Anfang) [KSK]' => '2',
		'Körperschaft (Stichwort) [KOE]' => '1005',
		'ISSN [ISS]' => '8',
		'Erscheinungsort, Verlag [VER]' => '8500',
		'Standardnummern [NUM]' => '8505',
		'CODEN [CDN]' => '8504',
		'Personenname [PER]' => '1004',
		'DDC-Sachgruppe [DCZ]' => '8575',
		'Verbreitungsort [VOZ]' => '8501',
		'ZDB-ID' => '8506',
		'Dokumenttyp [DOK]' => '8510',
		'Bibliothekssigel [SIG]' => '8502',
		'Erscheinungsland [ELA]' => '8511',
		'Signaturen [SGN]' => '8527',
		'Sondersammelgebiet [SSG]' => '8530'
	);
	const KATEGORIEN_ZDB_ID_FIRST = array(
		'ZDB-ID' => '8506',
		'Stichwort (allgemein) [STW]' => '8509',
		'Titelanfang [TST]' => '8508',
		'Titel (Stichwort) [TIT]' => '4',
		'Körperschaftsname (Anfang) [KSK]' => '2',
		'Körperschaft (Stichwort) [KOE]' => '1005',
		'ISSN [ISS]' => '8',
		'Erscheinungsort, Verlag [VER]' => '8500',
		'Standardnummern [NUM]' => '8505',
		'CODEN [CDN]' => '8504',
		'Personenname [PER]' => '1004',
		'DDC-Sachgruppe [DCZ]' => '8575',
		'Verbreitungsort [VOZ]' => '8501',
		'Dokumenttyp [DOK]' => '8510',
		'Bibliothekssigel [SIG]' => '8502',
		'Erscheinungsland [ELA]' => '8511',
		'Signaturen [SGN]' => '8527',
		'Sondersammelgebiet [SSG]' => '8530'
	);
	const JUNKTOREN = array(
		'und' => '*',
		'oder' => '+',
		'und nicht' => '-'
	);
	const SORTIERUNG = array(
		'Titel' => 'LST_ty',
		'Erscheinungsjahr' => 'YOP'
	);

	/**
	 * @var string
	 */
	protected $kategorie1;
	
	/**
	 * @return string
	 */
	public function getKategorie1() {
		return $this->kategorie1;
	}
	
	/**
	 * @param string $kategorie1
	 * @return void
	 */
	public function setKategorie1($kategorie1) {
		$this->kategorie1 = $kategorie1;
	}
	
	/**
	 * @var string
	 */
	protected $kategorie2;
	
	/**
	 * @return string
	 */
	public function getKategorie2() {
		return $this->kategorie2;
	}
	
	/**
	 * @param string $kategorie2
	 * @return void
	 */
	public function setKategorie2($kategorie2) {
		$this->kategorie2 = $kategorie2;
	}
	
	/**
	 * @var string
	 */
	protected $kategorie3;
	
	/**
	 * @return string
	 */
	public function getKategorie3() {
		return $this->kategorie3;
	}
	
	/**
	 * @param string $kategorie3
	 * @return void
	 */
	public function setKategorie3($kategorie3) {
		$this->kategorie3 = $kategorie3;
	}
	
	/**
	 * @var string
	 */
	protected $begriff1;
	
	/**
	 * @return string
	 */
	public function getBegriff1() {
		return $this->begriff1;
	}
	
	/**
	 * @param string $begriff1
	 * @return void
	 */
	public function setBegriff1($begriff1) {
		$this->begriff1 = $begriff1;
	}
	
	/**
	 * @var string
	 */
	protected $begriff2;
	
	/**
	 * @return string
	 */
	public function getBegriff2() {
		return $this->begriff2;
	}
	
	/**
	 * @param string $begriff2
	 * @return void
	 */
	public function setBegriff2($begriff2) {
		$this->begriff2 = $begriff2;
	}
	
	/**
	 * @var string
	 */
	protected $begriff3;
	
	/**
	 * @return string
	 */
	public function getBegriff3() {
		return $this->begriff3;
	}
	
	/**
	 * @param string $begriff3
	 * @return void
	 */
	public function setBegriff3($begriff3) {
		$this->begriff3 = $begriff3;
	}
	
	/**
	 * @var string
	 */
	protected $junktor1;
	
	/**
	 * @return string
	 */
	public function getJunktor1() {
		return $this->junktor1;
	}
	
	/**
	 * @param string $junktor1
	 * @return void
	 */
	public function setJunktor1($junktor1) {
		$this->junktor1 = $junktor1;
	}
	
	/**
	 * @var string
	 */
	protected $junktor2;
	
	/**
	 * @return string
	 */
	public function getJunktor2() {
		return $this->junktor2;
	}
	
	/**
	 * @param string $junktor2
	 * @return void
	 */
	public function setJunktor2($junktor2) {
		$this->junktor2 = $junktor2;
	}
	
	/**
	 * @var string
	 */
	protected $baseUri;
	
	public function __construct($baseUri = null) {
		
	}
	
	public function suche() {
		if (is_null($this->baseUri)) {
			$this->baseUri = $this->findBaseUri();
		}
		$queryArray = array(
				'IKT0' => $this->kategorie1,
				'IKT1' => $this->kategorie2,
				'IKT2' => $this->kategorie3,
				'IKT3' => '',
				'TRM0' => $this->begriff1,
				'TRM1' => $this->begriff2,
				'TRM2' => $this->begriff3,
				'TRM3' => '',
				'ACT1' => $this->junktor1,
				'ACT2' => $this->junktor2,
				'ACT3' => '',
				'SRT' => self::SORTIERUNG['Titel'],
				'ACT' => 'SRCHM', // hidden
				'MATCFILTER' => 'Y', // hidden
				'MATCSET' => 'Y', // hidden
				'NOSCAN' => 'Y', // hidden
				'PARSE_MNEMONICS' => 'N', // hidden
				'PARSE_OPWORDS' => 'N', // hidden
				'PARSE_OLDSETS' => 'N', // hidden
				'ACT0' => 'SRCH' // hidden
		);
		$queryParameterList = http_build_query($queryArray);
		$action = 'CMD?';
		$searchUrl = $this->baseUri . $action . $queryParameterList;
		
		// TODO: Exception abfangen, falls Server nicht erreichbar
		$html = file_get_contents($searchUrl);
		$crawler = new Crawler($html);
		
		$baseNode = $crawler->filterXPath('descendant::base/attribute::href')->getNode(0);
		if ($baseNode === null) { 
			throw new \Exception('Kann base url nicht finden. Wurde die korrekte Seite aufgerufen? Hat sich die Datenquelle geändert?');
		}
		$resultBaseUri = $baseNode->textContent;
		
		$count = $this->findItemCount($crawler, $html);
		
		return new ZdbSuchergebnis($resultBaseUri, $count);
	}
	
	protected function findItemCount(Crawler $crawler, $html) {
		$itemCountNode = $crawler->filterXPath('descendant::strong[attribute::class="pages"][1]')->getNode(0);
		if (is_null($itemCountNode)) {
			// check if no record message is found
			$noRecordMessageFound = strpos($html, 'Es wurde nichts gefunden.') !== FALSE;
			if(!$noRecordMessageFound) {
				throw new \Exception('Kann weder html node für die Anzahl Suchtreffer finden, noch kann bestätigt werden dass keine Suchtreffer vorhanden sind.');
			}
			return 0;
		} else {
			$itemCountHtml = $itemCountNode->textContent;
			$output = array();
			/* um die Lücken zwischen den Zahlen zu matchen, nutze [\W\D],
			 * da irgendein Steuerzeichen statt einem Leerzeichen verwendet wird. */
			$isMatched = preg_match("/\d+[\W\D]-[\W\D]\d+[\W\D]von[\W\D](\d+)/u", $itemCountHtml, $output);
			if ($isMatched) {
				return (int) $output[1];
			} else {
				// check if single record is matched
				$isMatched = preg_match('/1[\W\D]von[\W\D]1/u', $itemCountHtml, $output);
				if (!$isMatched) {
					throw new \Exception('Kann gesuchte Anzahl Treffer des Suchergebnisses nicht finden.');
				}
				return 1;
			}
		}
	}
	
	protected function findBaseUri() {
		$url = 'http://dispatch.opac.dnb.de/';
		// TODO: Exception abfangen, falls Server nicht erreichbar
		$html = file_get_contents($url);
		$crawler = new Crawler($html);
		$baseNode = $crawler->filterXPath('descendant::base/attribute::href')->getNode(0);
		if (is_null($baseNode)) { throw new \Exception(); }
		$baseUri = $baseNode->textContent;
		return $baseUri;
	}
	
	public function getBaseUri() {
		return $this->baseUri;
	}
}

