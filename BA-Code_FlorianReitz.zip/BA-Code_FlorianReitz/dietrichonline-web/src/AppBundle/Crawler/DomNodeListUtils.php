<?php
namespace AppBundle\Crawler;

use \DOMNodeList;

class DomNodeListUtils {
	public static function getValueOfAllItemsSemicolonSeperated(DOMNodeList $nodeList) {
		$values = '';
		if($nodeList->length > 0) {
			$i = 0;
			for (; $i < ($nodeList->length - 1); ++$i) {
				$values = $values . $nodeList->item($i)->nodeValue . '; ';
			}
			$values = $values . $nodeList->item($i)->nodeValue;
			return $values;
		} else { return null; }
	}
	
	public static function getValueOfFirstItem(DOMNodeList $nodeList) {
		if($nodeList->length > 0) {
			return $nodeList->item(0)->nodeValue;
		} else { return null; }
	}
	
	public static function getValueOfAllItems(DOMNodeList $nodeList) {
		$values = [];
		foreach ($nodeList as $node) {
			$values[] = $node->nodeValue;
		}
		return $values;
	}
}