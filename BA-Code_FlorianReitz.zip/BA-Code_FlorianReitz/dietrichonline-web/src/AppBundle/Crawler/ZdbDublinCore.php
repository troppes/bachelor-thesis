<?php

namespace AppBundle\Crawler;

use \DOMDocument;
use \DOMXPath;
use AppBundle\Entity\NormliteraturreferenzEntity;
use OutOfBoundsException;
use Symfony\Component\HttpKernel\Exception\ServiceUnavailableHttpException;

class ZdbDublinCore
{
    public static function produceNormlitrefOriginUrl($zdbId): string
    {
        return 'http://services.dnb.de/sru/zdb?version=1.1&operation=searchRetrieve&query=zdbid%3D'
            .$zdbId.'&recordSchema=oai_dc';
    }

    /**
     * @param $zdbId
     *
     * @return NormliteraturreferenzEntity|null
     *
     * @throws ServiceUnavailableHttpException if data cannot be retrieved from the ZDB-server
     * @throws OutOfBoundsException if the data from the ZDB-server does not contain exactly 1 result
     */
    public static function retrieveNormlitrefEntityByZdbId($zdbId)
    {
        $zdbRequestUrl = self::produceNormlitrefOriginUrl($zdbId);
        $xml = @file_get_contents($zdbRequestUrl);
        $dataRetrievalFromZdbServerFailed = $xml === false;
        if ($dataRetrievalFromZdbServerFailed) {
            throw new ServiceUnavailableHttpException(
                null,
                sprintf(
                    'Data retrieval from ZDB-server for id <%s> failed (full url <%s>).',
                    $zdbId,
                    $zdbRequestUrl
                )
            );
        }

        $doc = new DOMDocument();
        $doc->loadXML($xml);

        $xpath = new DOMXpath($doc);
        $xpath->registerNameSpace('std', 'http://www.loc.gov/zing/srw/');
        $xpath->registerNameSpace('dc', 'http://purl.org/dc/elements/1.1/');
        $xpath->registerNamespace('xsi', 'http://www.w3.org/2001/XMLSchema-instance');

        $numberOfRecords = DomNodeListUtils::getValueOfFirstItem($xpath->query('/descendant::std:numberOfRecords'));
        if (($numberOfRecords === 0 || $numberOfRecords === '0')) {
            return null;
        }
        if ($numberOfRecords > 1 || $numberOfRecords > '1') {
            throw new OutOfBoundsException('More than 1 result was found. Searching by ZDB-ID expects at most 1 result.');
        }

        $normlitrefEntity = new NormliteraturreferenzEntity();

        $zdbIdn = DomNodeListUtils::getValueOfFirstItem(
            $xpath->query('/descendant::dc:identifier[attribute::xsi:type="dnb:IDN"]')
        );
        $normlitrefEntity->setZdbIdn($zdbIdn);

        $zdbId = DomNodeListUtils::getValueOfFirstItem(
            $xpath->query('/descendant::dc:identifier[attribute::xsi:type="dnb:ZDBID"]')
        );
        $normlitrefEntity->setZdbId($zdbId);

        $title = DomNodeListUtils::getValueOfFirstItem($xpath->query('/descendant::dc:title'));
        $normlitrefEntity->setZdbBezeichnung($title);

        $publisher = DomNodeListUtils::getValueOfAllItemsSemicolonSeperated(
            $xpath->query('/descendant::dc:publisher')
        );
        $normlitrefEntity->setZdbErschienen($publisher);

        // TODO: This might yield less information than the official zdb-katalog.de interface.
        // We provide a link to the zdb-katalog.de site of the reference.
        // Christiane says she almost always uses the link to verify the connection of the litref.
        // So shall we drop this in favour of the link?
        $date = DomNodeListUtils::getValueOfFirstItem($xpath->query('/descendant::dc:date'));
        $normlitrefEntity->setZdbErscheinungsverlauf($date);

        return $normlitrefEntity;
    }

    public static function updateNormlitref(NormliteraturreferenzEntity $normlitref)
    {
        $crawledNormlitref = self::retrieveNormlitrefEntityByZdbId($normlitref->getZdbId());
        if (is_null($crawledNormlitref)) {
            throw new \Exception('Cannot crawl ZDB Data for normlitref with table id ['.$normlitref->getId().'].');
        }
        $normlitref->setZdbIdn($crawledNormlitref->getZdbIdn());
        $normlitref->setZdbBezeichnung($crawledNormlitref->getZdbBezeichnung());
        $normlitref->setZdbErschienen($crawledNormlitref->getZdbErschienen());
        $normlitref->setZdbErscheinungsverlauf($crawledNormlitref->getZdbErscheinungsverlauf());
    }
}
