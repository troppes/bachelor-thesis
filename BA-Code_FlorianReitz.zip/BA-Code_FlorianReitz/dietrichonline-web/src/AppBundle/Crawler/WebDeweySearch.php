<?php
namespace AppBundle\Crawler;

class WebDeweySearch {
    public static function crawlDdcThema($ddcNum) {
        $url = 'https://deweysearchde.pansoft.de/webdeweysearch/executeSearch.html?query='.$ddcNum;
        $doc = new \DOMDocument('1.0', 'UTF-8');
        $doc->loadHTMLFile($url, LIBXML_NOERROR);
        
        $xpath = new \DOMXPath($doc);
        $themaResultList = $xpath->query('/descendant::table/tbody/tr/td/div/span[@style="font-weight: bold;"]');
        if ($themaResultList->length === 0) { return null; }
        $thema = $themaResultList->item(0)->nodeValue;
        return $thema;
    }
}