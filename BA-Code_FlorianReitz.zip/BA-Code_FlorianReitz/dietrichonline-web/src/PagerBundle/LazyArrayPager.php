<?php
namespace PagerBundle;

use PagerBundle\AbstractPager;

class LazyArrayPager extends AbstractPager {
	protected $array;
	protected $numberOfItems;

	public function __construct($array, $maximumItemsPerPage, $numberOfItems) {
		parent::__construct($maximumItemsPerPage);
		$this->array = $array;
		$this->numberOfItems = $numberOfItems;
	}

	protected function sliceCollection($offset, $maximumSize){
		return $this->array;
	}

	public function countItems() {
		return $this->numberOfItems;
	}
}