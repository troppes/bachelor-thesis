<?php
namespace PagerBundle;

use Doctrine\Common\Collections\Collection;

/**
 * This pager paginates doctrine collections of the type Doctrine\Common\Collections\Collection.
 * 
 * @author Kajetan Weiß
 */
class DoctrineCollectionPager extends AbstractPager {
	/**
	 * @var Collection
	 */
	private $collection;
	
	/**
	 * Creates a new Pager which manages the given collection. The retrieved pages contain the given
	 * maximum number of items or less.
	 * 
	 * @param Collection $collection
	 * @param integer $maximumItemsPerPage
	 */
	public function __construct(Collection $collection, $maximumItemsPerPage) {
		parent::__construct($maximumItemsPerPage);
		$this->collection = $collection;
	}

	/**
	 * {@inheritDoc}
	 * @see \PagerBundle\AbstractPager::sliceCollection()
	 */
	protected function sliceCollection($offset, $maximumLength) {
		return $this->collection->slice($offset, $maximumLength);
	}
	
	/**
	 * {@inheritDoc}
	 * @see \PagerBundle\AbstractPager::countItems()
	 */
	public function countItems() {
		return $this->collection->count();
	}
}