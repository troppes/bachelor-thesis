<?php
namespace PagerBundle;

use Doctrine\ORM\Query;
use Doctrine\ORM\Tools\Pagination\Paginator as DoctrinePaginator;

/**
 * This pager paginates results of doctrine queries of the type Doctrine\ORM\Query.
 *
 * @author Kajetan Weiß
 */
class DoctrineQueryPager extends AbstractPager {
	/**
	 * @var Query
	 */
	private $query;
	
	/**
	 * @var Paginator
	 */
	private $paginator;

	/**
	 * @var boolean
	 */
	private $fetchJoinCollection;
	
	/**
	 * Creates a new Pager which manages the results of the given query. 
	 * The retrieved pages contain the given maximum number of items or less.
	 * If the given query does not contain a fetch join clause you may set the
	 * $fetchJoinCollection flag to false to inhibit an unnecessary database query
	 * in such a case. 
	 *
	 * @param Query $query
	 * @param integer $maximumItemsPerPage
	 * @param boolean $fetchJoinCollection
	 */
	public function __construct(
		Query $query, 
		$maximumItemsPerPage, 
		$fetchJoinCollection=true
	) {
		parent::__construct($maximumItemsPerPage);
		$this->query = $query;
		$this->paginator = null;
		$this->fetchJoinCollection = $fetchJoinCollection;
	}

	/**
	 * {@inheritDoc}
	 * @see \PagerBundle\AbstractPager::sliceCollection()
	 */
	protected function sliceCollection($offset, $maximumLength) {
		$this->query
		->setFirstResult($offset)
		->setMaxResults($maximumLength);
		$this->paginator = new DoctrinePaginator(
			$this->query, 
			$fetchJoinCollection=$this->fetchJoinCollection
		);
		return $this->paginator;
	}

	/**
	 * Returns the total number of items managed by this pager. In order to inhibit
	 * an unneccessary database query, retrieve a page first so the object can be properly
	 * initialized and the items can be counted by consulting the query result already made.
	 * @see \PagerBundle\AbstractPager::countItems()
	 */
	public function countItems() {
		if ($this->paginator === null) { $this->sliceCollection(0, 1); }
		return count($this->paginator);
	}
}