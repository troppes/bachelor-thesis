<?php

namespace PagerBundle;

use PagerBundle\AbstractPager;

class ElasticSearchPager
{
    private $resultCount;
    private $maximumItemsPerPage;

    public function __construct($resultCount, $maximumItemsPerPage)
    {
        $this->resultCount         = $resultCount;
        $this->maximumItemsPerPage = $maximumItemsPerPage;
    }


    /**
     * Generates an array of 4 integer page numbers lower than the $pageNumber provided. The first number is
     * always 1, the second is a page number in between 1 and the given $pageNumber, the third is the given
     * $pageNumber decremented by 5 and the fourth page number is the page number before the given
     * $pageNumber. If the given $pageNumber is lower than 11, 4 consecutive numbers are generated descending
     * from the given $pageNumber. This should ease the way users can traverse accross large sets of page numbers
     * without having to type their desired page number.
     *
     * @param integer $pageNumber
     *
     * @return array
     */
    public function getLowerQuickNavigationPageNumbers($pageNumber)
    {
        $numbers       = [];
        $numberOfPages = $this->countPages();
        if ($numberOfPages == 0) {
            return $numbers;
        }

        if ($pageNumber >= 11) {
            $numbers[] = 1;
            $numbers[] = floor($pageNumber / 2);
            $numbers[] = $pageNumber - 5;
            $numbers[] = $pageNumber - 1;
        } else {
            for (
                $i = 1, $number = $pageNumber - 1;
                $i <= 4 && $number > 0;
                $i++, $number--
            ) {
                array_unshift($numbers, $number);
            }
        }

        return $numbers;
    }

    /**
     * Generates an array of 4 integer page numbers higher than the $pageNumber provided. The first number is
     * the next page number after the given $pageNumber, the second is the $pageNumber incremented by 5, the
     * third page number is a page number in between the highest possible page number and the given
     * $pageNumber, the fourth is always the highest possible page number. If the given $pageNumber is lower
     *  than the highest page number minus 11, 4 consecutive numbers are generated ascending from the given
     *  $pageNumber. This should ease the way users can traverse accross large sets of page numbers without
     *  having to type their desired page number.
     *
     * @param integer $pageNumber
     *
     * @return array
     */
    public function getHigherQuickNavigationPageNumbers($pageNumber)
    {
        $numbers       = [];
        $numberOfPages = $this->countPages();
        if ($numberOfPages < 2 || $pageNumber >= $numberOfPages) {
            return $numbers;
        }

        if ($pageNumber < $numberOfPages - 11) {
            $numbers[] = $pageNumber + 1;
            $numbers[] = $pageNumber + 5;
            $numbers[] = floor($pageNumber + ($numberOfPages - $pageNumber) / 2);
            $numbers[] = $numberOfPages;
        } else {
            for (
                $i = 1, $number = $pageNumber + 1;
                $i <= 3 && $number < $numberOfPages;
                $i++, $number++
            ) {
                $numbers[] = $number;
            }
            $numbers[] = $numberOfPages;
        }

        return $numbers;
    }

    /**
     * Returns the amount of pages managed by this pager.
     *
     * @return integer
     */
    public function countPages()
    {
        $numberOfItems = $this->resultCount;
        return ceil($numberOfItems / $this->maximumItemsPerPage);
    }

}