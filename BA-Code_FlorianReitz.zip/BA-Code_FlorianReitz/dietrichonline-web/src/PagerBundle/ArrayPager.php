<?php
namespace PagerBundle;

use PagerBundle\AbstractPager;

class ArrayPager extends AbstractPager {
	protected $array;
	
	public function __construct($array, $maximumItemsPerPage) {
		parent::__construct($maximumItemsPerPage);
		$this->array = $array;
	}
	
	protected function sliceCollection($offset, $maximumSize){
		return array_slice($this->array, $offset, $maximumSize);
	}
	
	public function countItems() {
		return count($this->array);
	}
}