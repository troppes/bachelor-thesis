<?php
namespace PagerBundle;

/**
 * AbstractPager serves as base class for specific Pagers which paginate specific collections.
 * 
 * @author Kajetan Weiß (weiss@uni-trier.de)
 */
abstract class AbstractPager {
	/**
	 * @var integer
	 */
	protected $maximumItemsPerPage;
	
	/**
	 * This constructor is used by derived classes as a base to initialise the quantity maximum 
	 * of items of a page. The retrieved pages contain the given maximum number of items or less.
	 * 
	 * @param unknown $maximumItemsPerPage
	 */
	protected function __construct($maximumItemsPerPage) {
		$this->maximumItemsPerPage = $maximumItemsPerPage;
	}

	/**
	 * Returns the amount of pages managed by this pager.
	 * 
	 * @return integer
	 */
	public function countPages() {
		$numberOfItems = $this->countItems();
		$numberOfPages = ceil($numberOfItems / $this->maximumItemsPerPage);
		return $numberOfPages;
	}

	/**
	 * Retrieves the requested page referenced by its page number which is an index starting with 1.
	 * The requested page is returned as a \Traversable as stated by the \Traversable Interface.
	 * 
	 * @param integer $pageNumber
	 * 
	 * @return \Traversable
	 */
	public function getPageByNumber($pageNumber) {
		$pageIndex = $pageNumber - 1;
		return $this->getPageByIndex($pageIndex);
	}
	
	/**
	 * Retrieves the requested page referenced by its page number which is an index starting with 0.
	 * The requested page is returned as a \Traversable as stated by the \Traversable Interface.
	 * 
	 * @param integer $pageIndex
	 * 
	 * @return \Traversable
	 */
	public function getPageByIndex($pageIndex) {
		$offset = $pageIndex * $this->maximumItemsPerPage;
		$page = $this->sliceCollection($offset, $this->maximumItemsPerPage);
		return $page;
	}

	/**
	 * Generates an array of 4 integer page numbers lower than the $pageNumber provided. The first number is 
	 * always 1, the second is a page number in between 1 and the given $pageNumber, the third is the given
	 * $pageNumber decremented by 5 and the fourth page number is the page number before the given 
	 * $pageNumber. If the given $pageNumber is lower than 11, 4 consecutive numbers are generated descending 
	 * from the given $pageNumber. This should ease the way users can traverse accross large sets of page numbers 
	 * without having to type their desired page number.
	 *  
	 * @param integer $pageNumber
	 * @return array
	 */
	public function getLowerQuickNavigationPageNumbers($pageNumber) {
		$numbers = array();
		$numberOfPages = $this->countPages();
		if ($numberOfPages == 0) {
			return $numbers;
		}
		
		if ($pageNumber >= 11) {
			$numbers[] = 1;
			$numbers[] = floor($pageNumber / 2);
			$numbers[] = $pageNumber - 5;
			$numbers[] = $pageNumber - 1;
		} else {
			for (
				$i = 1, $number = $pageNumber - 1; 
				$i <= 4 && $number > 0;
				$i++, $number--
			) {
				array_unshift($numbers, $number);
			}
		}
		return $numbers;
	}
	
	/**
	 * Generates an array of 4 integer page numbers higher than the $pageNumber provided. The first number is
	 * the next page number after the given $pageNumber, the second is the $pageNumber incremented by 5, the 
	 * third page number is a page number in between the highest possible page number and the given 
	 * $pageNumber, the fourth is always the highest possible page number. If the given $pageNumber is lower
	 *  than the highest page number minus 11, 4 consecutive numbers are generated ascending from the given 
	 *  $pageNumber. This should ease the way users can traverse accross large sets of page numbers without 
	 *  having to type their desired page number.
	 *
	 * @param integer $pageNumber
	 * @return array
	 */
	public function getHigherQuickNavigationPageNumbers($pageNumber) {
		$numbers = array();
		$numberOfPages = $this->countPages();
		if ($numberOfPages < 2 || $pageNumber >= $numberOfPages) {
			return $numbers;
		}
		
		if ($pageNumber < $numberOfPages - 11) {
			$numbers[] = $pageNumber + 1;
			$numbers[] = $pageNumber + 5;
			$numbers[] = floor($pageNumber + ($numberOfPages - $pageNumber) / 2);
			$numbers[] = $numberOfPages;
		} else {
			for (
				$i = 1, $number = $pageNumber + 1;
				$i <= 3 && $number < $numberOfPages;
				$i++, $number++
			) {
				$numbers[] = $number;
			}
			$numbers[] = $numberOfPages;
		}
		return $numbers;
	}
	
	/**
	 * Returns the total number of items managed by this pager.
	 * 
	 * @return integer
	 */
	public abstract function countItems();
	
	/**
	 * Returns a \Traversable object which contains the items from the given offset to the 
	 * maximum size given.   
	 * 
	 * @param integer $offset
	 * @param integer $maximumSize
	 * @return \Traversable
	 */
	protected abstract function sliceCollection($offset, $maximumSize);
}