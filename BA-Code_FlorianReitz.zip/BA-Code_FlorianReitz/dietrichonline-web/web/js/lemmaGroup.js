function findGroupBtnFromCheckbox(checkBox) {
    let result = document.evaluate(
        'ancestor::tr//button[@name="group_button"]',
        checkBox,
        null,
        XPathResult.FIRST_ORDERED_NODE_TYPE
    );
    return result.singleNodeValue;
}

lemmaCheckboxCheckHooks.push(function (checkbox, lemmaIds) {
    let grpBtn = findGroupBtnFromCheckbox(checkbox);
    grpBtn.classList.remove('disabled');
});

lemmaCheckboxUncheckHooks.push(function (checkbox, lemmaIds) {
    let grpBtn = findGroupBtnFromCheckbox(checkbox);
    grpBtn.classList.add('disabled');
});
