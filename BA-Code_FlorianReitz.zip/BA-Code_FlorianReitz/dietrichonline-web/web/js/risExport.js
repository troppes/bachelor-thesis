var DefaultFileName = "DietrichOnlineExport.ris";

/** 
  * To add new data to the RIS file, add a new entry to this array,
  * then put the data, that should be added, inside of an HTML element inside the article element
  * with the class "[array key] data" (example: <span class="media-type data">Zeitschrift</span>)
  * 
  * The corresponding array value specifies the tag of the data in the RIS file.
  * The order of the tags will be the same in the RIS file.
  */
var risTagForDataField = {};
risTagForDataField["media-type"] 	= "TY";
risTagForDataField["title"] 		= "T1";
risTagForDataField["author"] 		= "AU";
risTagForDataField["published-in"] 	= "JF";
risTagForDataField["keyword"] 		= "KW";
risTagForDataField["link"] 			= "L2";

/**
 * media-type data fields may contain any of the following strings (the keys of risValueForMediaType).
 * These will be translated to the corresponding following values inside the RIS-file (the values of risValueForMediaType). 
 */
var risValueForMediaType = {};
risValueForMediaType["Zeitschrift"] = "JOUR";
risValueForMediaType["Zeitung"] 	= "MGZN";
risValueForMediaType["Buch"] 		= "BOOK";
risValueForMediaType["default"] 	= "JOUR"; // Default value if not specified in Dietrich.

/**
 * This function will be called on click on "Exportieren ins RIS-Dateiformat ..."
 */
function exportSelectedBookmarksAsRIS() {
	if (bookmarksCookie.count() > 0) {	
		var risFileString = getRISFileString(); // Get file data
		executeDataDownload(DefaultFileName, risFileString); // Execute file download
	}
}

/**
 * Produces the content of the RIS-file.
 * @returns the complete string, that will be the content of the RIS-file.
 */
function getRISFileString() {
	var risFileString = "";
	
	var articleElements = new Array();
	
	// Get all bookmarked article IDs from the cookie interface object
	// and find all respective article html elements on the page.
	var bookmarkedIDs = bookmarksCookie.getAll();
	for (var i=0; i < bookmarkedIDs.length; ++i) {
		var ele = $("#"+bookmarkedIDs[i]);
		if (ele.length > 0)
			articleElements.push(ele);
	}		
	
	// Build RIS-file string.
	for (var i=0; i < articleElements.length; ++i) {
		risFileString += getArticleRISString(articleElements[i]);
	}
	
	return risFileString;
}

/**
 * The RIS-file will be built by concatenating the strings of all contained articles,
 * 	which are produced through this function.
 * @param articleElement
 * @returns the RIS-file string for the article.
 */
function getArticleRISString(articleElement) {
	var risString = "";
	
	// Extract data for every tag specified in risTagForDataField from the html page.
	for (var key in risTagForDataField) {
		// Html elements containing the data have got the classes "[data-type] data"
		var dataFields = $(articleElement).find(".data."+key);	
		
		for (var i=0; i < dataFields.length; ++i) {
			data = $(dataFields[i]).text();
				
			// convert media-type to RIS equivalent.
			// if media-type is not defined, take the default value.
			if (key == "media-type") {
				if (data === undefined)
					data = risValueForMediaType["default"];
				else
					data = risValueForMediaType[data];
			} else if (data === undefined) {
				continue;
			}	
			
			risString += getRISTagString(risTagForDataField[key], data);
		}
	}
	
	// Finish article string by adding an "ER"-tag line (End of Record).
	risString += getRISTagString("ER", "");
	return risString;
}

/**
 * Returns the string for a single tag (=line) of the RIS-file.
 * @param {string} tag
 * @param {string} value
 * @returns {string} of the following pattern: "[tag]  - [value][newline]"
 */
function getRISTagString(tag, value) {
	var tagString = "";
	tagString += tag + "  - ";
	tagString += value;
	tagString += "\r\n";
	return tagString;
}


/**
 * The browser will execute a file download on call of this function.
 * @param {string} filename - The default filename of the file, that will be downloaded.
 * @param {string} data	- The content of the file.
 */
function executeDataDownload(filename, data) {
    var blob = new Blob([data], {type: 'text/csv'});
    
    // Microsoft browser
    if(window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveBlob(blob, filename);
    }
    
    // Other browsers
    else{
        var elem = window.document.createElement('a');
        
        blobObjectURL = window.URL.createObjectURL(blob);
        elem.href = blobObjectURL;
        elem.download = filename;        
        
        document.body.appendChild(elem);
        elem.click();        
        
        document.body.removeChild(elem);
        // window.URL.revokeObjectURL(blobObjectURL); //May not be compatible with all browser.
    }
}
