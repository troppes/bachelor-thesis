function quoteTokenize(string) {
  var tokens = [];
  var isInsideQuote = false;
  var i = 0;
  while (i < string.length) {
    var start = i;
    var isQuoted = false;
    if (string[i] === '"') {
      isInsideQuote = true;
      i++;
    }
    while(i < string.length && string[i] !== '"') {
      i++;
    }
    if (isInsideQuote && string[i] === '"') {
      i++;
      isQuoted = true;
      isInsideQuote = false;
    }
    tokens.push({
      start: start,
      end: i,
      isQuoted: isQuoted
      , value: string.substring(start, i)
    });

  }
  return tokens;
}

function initializeSearchForms() {
	$('#quicksearch-form').addClass('searchform');
	$('#fullsearch-form').addClass('searchform');
	var searchForms = $('.searchform');
	
	// Empty quicksearch form
	$('#quicksearch-form').find('input').val("");
	initializeDynamicSearchRows();
}

function initializeDynamicSearchRows() {
	// "Suchkriterium hinzufügen" adds a new dynamic row
	$('#add-search-row-button').click(function() {
		var dynamicHiddenRows = $('.dynamic.search-row:hidden');
		
		if (dynamicHiddenRows.length > 0)
			$(dynamicHiddenRows[0]).show();
		
		updateAddSearchRowButton();
	});
	
	// The red delete icons remove their respective dynamic row on click
	$('.delete-dynamic-row-button').click(function() {
		var closestRow = $(this).closest('.dynamic.search-row')

		resetDynamicSearchRow(closestRow);
		updateAddSearchRowButton();
	});
	
	showUsedRows();
	updateAddSearchRowButton();
}

/**
 * Sets a dynamic search back to its original state (this also means hidden).
 * @param row - the dynamic search row to reset.
 */
function resetDynamicSearchRow(row) {
	row.find('.prompt').val("");
	row.find('.prompt').removeClass('suggestion-selected');
	row.find('.category.dropdown').dropdown('restore default value');
	row.find('.junktor.dropdown').dropdown('restore default value');
	row.hide();
}

function updateAddSearchRowButton() {
	if ($('.dynamic.search-row:hidden').length == 0)
		$('#add-search-row-button').hide();
	else
		$('#add-search-row-button').show();
}

/**
 * Makes every row up to the last filled-in row visible.
 */
function showUsedRows() {
	var lastFilledRow = undefined;
	$.each($('.dynamic.search-row:hidden'), function(k, v) {
		var ele = $(v);
		if (ele.find('.prompt').val())
			lastFilledRow = ele;
	});
	
	if (lastFilledRow) {
		lastFilledRow.show();
		$.each(lastFilledRow.prevAll('.dynamic.search-row:hidden'), function(k, v) {
			$(v).show();
		});
	}
}