function initializeSemanticUiComponents() {
    $('.ui.modal').modal();

    $('.modalTrigger').click(function () {
        $('#' + this.dataset.modalTargetId).modal('show');
    });

    $('.ui.modal.show').first().modal('show');

    $("button[name='loeschenButton']").click(function () {
        let confirmModalId = this.value;
        $('#' + confirmModalId).modal('show');
    });

    $('.ui.dropdown').dropdown();

    $('.ui.popupTrigger').popup({
        inline: true,
        position: 'bottom center',
        on: "click"
    });

    $('.ui.hoverPopupTrigger').popup({
        inline: true,
        position: 'bottom left',
        on: 'hover',
        delay: {
            show: 1500
        }
    });

    $('.ui.popupTrigger.showPopup').popup('show');

    $('.ui.accordion').accordion();

    $('.ui.tabular.menu .item').tab();

    $('.with.tooltip').popup();

    $('.ui.checkbox').checkbox();

    $('.ui.sticky').sticky();

    // noinspection JSUnusedLocalSymbols
    $('.ui.search').search({
        apiSettings: {
            url: "/getsuggestions?query={query}&category={/category}&quicksearch={/quicksearch}",
            action: 'search',
            beforeSend: function (settings) {
                if (settings.urlData.category === undefined) {
                    // Retrieve category index from associated category dropdown menu.
                    let categorySelectionEle = $(this).closest('.search-row').find('.category.dropdown').find(':selected');
                    settings.urlData.category = categorySelectionEle.attr('value');
                }
                return settings;
            }
        },
        maxResults: 10,
        onSelect: function (result, response) {
            let input = $(this).find('.prompt')[0];
            let tokens = quoteTokenize(input.value);
            let preservedValue = tokens.reduce(function (total, crrnt) {
                if (crrnt.isQuoted) {
                    return total + input.value.substring(crrnt.start, crrnt.end);
                } else {
                    return total;
                }
            }, '');

            if (result.title.length === 0) { //Check if result is empty, if so take input value instead
                let selectedValue = input.value;
                input.value = preservedValue + selectedValue;
                return;
            } else {
                let selectedValue = '"' + result.title.replace(/"/g, '”') + '"';
                input.value = preservedValue + selectedValue;
            }
            // workaround to blur focus after semantic-ui resets focus after select
            input.onfocus = function () {
                input.blur();
                input.onfocus = null;
            };

            $(this).search('hide results');

            // Search on select if quicksearch
            if (input.getAttribute('data-isQuicksearch')) {
                $('#quicksearch-form').submit();
            }

            // suppress default behaviour
            return false;
        }
    });
}

