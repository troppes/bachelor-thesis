let lemmaSelection =
    {
        selectedLemmaIds: {},

        addId: function (id) {
            if (id in this.selectedLemmaIds) {
                return;
            }

            this.selectedLemmaIds[id] = true;
        },

        removeId: function (id) {
            if (!(id in this.selectedLemmaIds)) {
                return;
            }

            delete this.selectedLemmaIds[id];
        },

        isContainingId: function (id) {
            return id in this.selectedLemmaIds;
        },

        produceCommaSeperatedString: function () {
            let string = "";
            for (let id in lemmaSelection.selectedLemmaIds) {
                string += id + ",";
            }
            return string.substr(0, string.length - 1);
        },
    };

let lemmaCheckboxCheckHooks = [];
let lemmaCheckboxUncheckHooks = [];

lemmaCheckboxCheckHooks.push(function (checkbox, lemmaIds) {
    lemmaIds.forEach(function (lemmaId) {
        lemmaSelection.addId(lemmaId);
    });
});

lemmaCheckboxUncheckHooks.push(function (checkbox, lemmaIds) {
   lemmaIds.forEach(function (lemmaId) {
       lemmaSelection.removeId(lemmaId);
   });
});

function lemmaCheckboxHandler(checkBox, lemmaIds) {
    if (checkBox.checked) {
        lemmaCheckboxCheckHooks.forEach(function (hook) {
            hook(checkBox, lemmaIds);
        });
    } else {
        lemmaCheckboxUncheckHooks.forEach(function (hook) {
            hook(checkBox, lemmaIds);
        });
    }
}

function initLemmaCheckboxes() {
    const lemmaCheckboxes = document.querySelectorAll(".lemma.checkbox");
    lemmaCheckboxes.forEach(function (checkbox) {
        checkbox.checked = false;
    });
}
