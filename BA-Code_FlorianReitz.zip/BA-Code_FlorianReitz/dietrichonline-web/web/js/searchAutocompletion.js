function initializeClearCacheOnCategoryChange() {
	// Assign the function categoryDropdownOnChange to every category dropdown menu's onChange event
	var categoryDropdownEles = $(".category.selection");
	categoryDropdownEles.change(categoryDropdownOnChange);
}

/**
 * Makes sure, that a new auto-complete request will be sent to the server,
 * 	if the category has been changed, but not the text in the search field.
 */
function categoryDropdownOnChange() {
	$(this).closest(".fields").find(".ui.search").search('clear cache');
}
