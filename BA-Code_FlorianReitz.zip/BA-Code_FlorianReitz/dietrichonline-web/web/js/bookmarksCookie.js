/**
 * Interface class to the bookmarks cookie.
 * Stores all bookmarks in a cookie and provides functions to edit it.
 * Note: the most recently added element will be on top of the list
 */
function BookmarksCookie()
{
	var BOOKMARKS_COOKIE_NAME = "bookmarks";
	var self = this; // Pointer to the current object.

	// Array of integers (the bookmarked article IDs)
	// which represents the data written into the actual cookie.
	var articleIdList; 
	
	var hasChangedSinceLastRequest = false;
	
	function init() {
		readCookie();
	}
	
	 /** ### Public functions ### **/
	
	/**
	 * Adds an article's id to the cookie.
	 * @params {number} id - the article id to bookmark.
	 */
	self.add = function(id) {
		if (id === undefined)
			return;
		
		readCookie();
		articleIdList.unshift(id); // Add to the front
		writeCookie();
		
		hasChangedSinceLastRequest = true;
	}
	
	/**
	 * Removes an article's id from the cookie.
	 * @params {number} id - the article id to remove from bookmarks.
	 */
	self.remove = function(id) {
		if (id === undefined)
			return;
		
		readCookie();
		
		var firstIndex = 0;
		while (articleIdList[firstIndex] != id) {
			firstIndex++;
			if (firstIndex >= articleIdList.length) return;
		}
			
		articleIdList.splice(firstIndex, 1);
		writeCookie();
		
		hasChangedSinceLastRequest = true;
	}
	
	/**
	 * Checks if given article id is bookmarked.
	 * @params id - article id to check
	 * @return true, if given id is contained in the bookmarks list, else return false.
	 */
	self.has = function(id) {
		readCookie();
		
		for (var i=0; i < articleIdList.length; ++i) {
			if (articleIdList[i] == id)
				return true;
		}
		return false;
	}
	
	/**
	 * Remove all bookmarks.
	 */
	self.reset = function() {
		articleIdList = new Array();
		writeCookie();
	}
	
	/**
	 * Gets the count of bookmarked articles.
	 * @return {number}
	 */
	self.count = function() {
		readCookie();
		return articleIdList.length;
	}
	
	/**
	 * Gets all bookmarked article ids.
	 * @return {array} the bookmarked article id list as an array of numbers.
	 */
	self.getAll = function() {
		readCookie();
		return articleIdList;
	}
	
	/**
	 * Checks if the cookie has been modified by another instance of bookmarksCookie (or somehow else).
	 * @return {boolean}
	 */
	self.hasBeenExternallyModified = function() {
		var localCount = articleIdList.length;
		readCookie();
		return (localCount != articleIdList.length);
	}
	
	/** ### Private functions ### **/
	
	/**
	 * Saves the content of articleIdList as a string inside of the actual cookie.
	 */
	function writeCookie() {
		// Using the library function Cookies.set of jscookie.js
		Cookies.set(BOOKMARKS_COOKIE_NAME, articleIdList.toString(), {expires: 365 * 10} /*10 years*/);
	}
	
	/**
	 * Reads the actual cookie and writes its content into articleIdList.
	 */
	function readCookie() {
		// Using the library function Cookies.get of jscookie.js
		var bookmarkString = Cookies.get(BOOKMARKS_COOKIE_NAME);
		if (bookmarkString !== undefined) {
			try {
				articleIdList = JSON.parse("["+bookmarkString+"]") // It should be save to go over an arbitrary string with JSON.parse
			}
			
			// if anything goes wrong while reading cookie, create empty list
			catch(e) {
				articleIdList = new Array();
			}
		} 
		// If cookie doesn't exist, create empty list
		else {
			articleIdList = new Array();
		}
	}

	// Call constructor
	init();
}