 // in milliseconds
var PeriodicUpdateInterval = 750;
var DeleteFadeOutTime = 100;

var AddBookmarkPopupText = "Artikel zum Exportieren vormerken";
var RemoveBookmarkPopupText = "Artikel von Merkliste entfernen";

var bookmarksCookie = new BookmarksCookie(); // Interface to the cookie.
var currentPageIsBookmarksList = false;

/** ### Functions of bookmark control buttons ### **/

function bookmarkAll() {
	// Preserve order as shown
	triggerClickInReverseOrder($(".outline.bookmark.icon.button"));
}

function invertSelection() {
	// Preserve order as shown
	triggerClickInReverseOrder($(".bookmark.icon.button"));
}

function unbookmarkAll() {
	triggerClick($(".bookmark.icon.button").not(".outline"));
}

function emptyBookmarks() {
	triggerClick($(".red.remove.icon"));
}

function restoreBookmarks() {
	var articleElements = $(".artikel");
	
	bookmarksCookie.reset();
	
	// After restoring the list should have the same order as seen on the screen
	for (var i=articleElements.length-1; i >= 0; --i) {
		var ele = $(articleElements[i]);
		
		ele.show();
		bookmarksCookie.add(ele.attr("id"));
	}
	
	$("#undo-remove-bookmark-button").addClass("disabled");
	$("#empty-bookmarks-button").removeClass("disabled");
	$("#export-bookmarks-button").removeClass("disabled");
	updateBookmarkCounter();
}

/** ### Update functions ### **/

function updateBookmarkCounter() {
	// Reload page if on bookmarks page and the bookmarks cookie has been modified externally (e.g. on another tab) 
	if (currentPageIsBookmarksList && bookmarksCookie.hasBeenExternallyModified()) {	
		window.location.reload(true);
		return;
	}
	
	var bookmarkCounterElement = $("#bookmark-counter");	
	var resetBookmarksButton = $("#reset-bookmarks-button");
	var bookmarkMenuIcon = $("#bookmark-menu-item").find(".bookmark.icon");
	
	if (bookmarksCookie.count() > 0) {
		resetBookmarksButton.show();
		bookmarkCounterElement.html(" "+bookmarksCookie.count()+" ");
		bookmarkMenuIcon.removeClass("outline");
	}
	else {
		resetBookmarksButton.hide();
		bookmarkCounterElement.html("");
		bookmarkMenuIcon.addClass("outline");
	}
}

function updateBookmarkIcons() {
	var bookmarkIconElements = $(".bookmark.icon");
	var isAnySelected = false;
	var isAnyDeselected = false;
	
	for (var i=0; i < bookmarkIconElements.length; ++i) {
		var ele = bookmarkIconElements[i];
		var id = getAssociatedArticleID(ele);
		
		// Do not update icons which have no assigned article id.
		// (as example the bookmark icon of the menu item)
		if (id === undefined)
			continue;
		
		var isSelected = bookmarksCookie.has(id);
		setBookmarkIcon(ele, isSelected);
		
		isAnySelected = (isAnySelected || isSelected);
		isAnyDeselected = (isAnyDeselected || !isSelected);
	}
	
	updateBookmarkControlButtons(isAnySelected, isAnyDeselected);
}

function updateBookmarkControlButtons(isAnySelected, isAnyDeselected) {
	var deselectAllButton = $("#deselect-all-button");
	if (isAnySelected) {
		deselectAllButton.removeClass("disabled");
	} else {
		deselectAllButton.addClass("disabled");
	}
	
	var selectAllButton = $("#select-all-button")
	if (isAnyDeselected) {
		selectAllButton.removeClass("disabled");
	} else {
		selectAllButton.addClass("disabled");
	}
}

function updateBookmarksPeriodically() {
	var updateFunction = function() {
		updateBookmarkIcons();
		updateBookmarkCounter();
	};	
	setInterval(updateFunction, PeriodicUpdateInterval);
}

/***
 * @param iconElement : A bookmark icon element.
 * @param isSelected : The state the element should be set to.
 */
function setBookmarkIcon(iconElement, isSelected) {		
	var iconEle = $(iconElement);
	var popupEle = $(iconElement).parent().next();
	
	if(isSelected) { 
	// Convert the icon to the "this bookmark is now added" icon.
		iconEle.removeClass("outline");
		setTimeout(popupEle.html.bind(popupEle, RemoveBookmarkPopupText), 500);
	} else { 
		// Convert the icon to the "click to bookmark this entry" icon.
		iconEle.addClass("outline");
		setTimeout(popupEle.html.bind(popupEle, AddBookmarkPopupText), 500);
	}
}

function initializeBookmarkIcons() {
	var bookmarkIcons = $(".bookmark.icon.button");
	if (bookmarkIcons.length > 0) {
		bookmarkIcons.click(bookmarkIconOnClick);
		updateBookmarkIcons();
	}
	
	var deleteIcons = $(".red.remove.icon.button");
	if (deleteIcons.length > 0) {
		deleteIcons.click(deleteIconOnClick);
		deleteIcons.parent().next().html(RemoveBookmarkPopupText);
	}
}

function hideArticle(ele) {
	var articleEle = ele.closest(".artikel");	
	articleEle.fadeOut(DeleteFadeOutTime, articleEle.hide);
	
	$("#undo-remove-bookmark-button").removeClass("disabled");
	if (bookmarksCookie.count() < 1) {
		$("#empty-bookmarks-button").addClass("disabled");
		$("#export-bookmarks-button").addClass("disabled");
	}
}

/***
 * @param iconElement : A bookmark icon element.
 * @returns The article id associated with the given bookmark icon element.
 */
function getAssociatedArticleID(iconElement) {
	var articleEle = $(iconElement).closest(".artikel");
		
	if (articleEle.length > 0) {
		var id = parseInt(articleEle.attr("id"));
		
		if (id !== NaN)
			return id;
		else
			return undefined;
	}
	
	return undefined;
}

function triggerClick(elements) {
	$(elements).trigger("click");
}

function triggerClickInReverseOrder(elements) {
	var reverseElementList = $(elements).get().reverse();
	$(reverseElementList).each(function(){$(this).trigger("click");});
}

/** ### Bind functions ### **/

function bookmarkIconOnClick() {
	var ele = $(this);
	var articleID = getAssociatedArticleID(ele);
	
	if (articleID === undefined)
		return;
	
	ele.parent().popup("hide");
	
	if (bookmarksCookie.has(articleID)) {
		bookmarksCookie.remove(articleID);
	} else {
		bookmarksCookie.add(articleID);
		//$("#bookmark-counter").parent().transition("pulse");
	}
	
	updateBookmarkCounter();
	updateBookmarkIcons();	
}

function deleteIconOnClick() {
	var ele = $(this);
	var articleID = getAssociatedArticleID(ele);
	
	bookmarksCookie.remove(articleID);
	hideArticle(ele);

	updateBookmarkCounter();
}

