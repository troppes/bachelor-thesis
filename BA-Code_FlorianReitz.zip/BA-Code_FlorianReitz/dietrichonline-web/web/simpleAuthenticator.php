<?php
$password = 'blinkende affen grunzen im all';
$cookiePassword = '8T;t0WzR\rqZy(T.o!1DBDltP3}l:fH';
$securedAreas = [
	'literaturreferenzadministration',
	'lemma_administration',
    'korrekturvorschlagRedaktion'
];

if(securedAreaRequested($securedAreas)) {
	$isAthenticated = checkAuthentication($password, $cookiePassword);
	if (!$isAthenticated) { die(); }
}

function checkAuthentication($password, $cookiePassword) {
	$requestCookiePassword = isset($_COOKIE['cookiePassword'])? $_COOKIE['cookiePassword'] : null;
	$isAuthenticated = $requestCookiePassword === $cookiePassword;
	if ($isAuthenticated) {
		return true;
	} else {
		$submittedPw = isset($_POST['uniBibSimpleAuthPw'])? $_POST['uniBibSimpleAuthPw'] : null;
		if ($submittedPw === $password) {
			$expire = 0;
			$path = '/';
			setcookie('cookiePassword', $cookiePassword, $expire, $path);
			return  true;
		} else {
			require 'simpleAuthenticatorForm.php';
			return false;
		}
	}
	
}

function securedAreaRequested($securedAreas) {
	$uri = $_SERVER['REQUEST_URI'];
	foreach ($securedAreas as $securedArea) {
		if (preg_match('<'.$securedArea.'>', $uri)) {
			return true;
		}
	}
	return false;
}
