<?php
/**
 * Page routes to modify:
 * <ul>
 *   <li>comment -> route is open
 *   <li>uncomment -> route shows maintenance page
 * </ul>
 *
 * ATM all routes implement database access.
 */
$maintenanceAreas = [
//    'suche',
//    'bookmarks',
//    'korrekturvorschlagRedaktion',
//    'literaturreferenzadministration',
//    'lemma_administration',
    'maintenanceTest'
];

if(maintenanceAreaRequested($maintenanceAreas)) {
    require 'SorryMaintenanceAreaRequested.html';
    die();
}

function maintenanceAreaRequested($maintenanceAreas) {
    $uri = $_SERVER['REQUEST_URI'];
    foreach ($maintenanceAreas as $maintenanceArea) {
        if (preg_match('<'.$maintenanceArea.'>', $uri)) {
            return true;
        }
    }
    return false;
}
