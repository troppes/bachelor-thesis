# DFG-Viewer data folder

This folder contains the relevant data for the client view.

Local data will not be synced!