<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<form action="<?php echo $_SERVER['REQUEST_URI'] ?>" method="post">
		<input type="text" name="uniBibSimpleAuthPw" size="50">
		<button type="submit">login</button>
	</form>
	<?php if(isset($_POST['uniBibSimpleAuthPw'])):?>
		<p>Das eingegebene Passwort wird nicht akzeptiert.</p>
	<?php endif ?>
</body>
</html>
