<?php

namespace AppBundle\NativeSql;

use InvalidArgumentException;
use PHPUnit_Framework_TestCase;

/**
 * Class SearchNormalizationTest
 *
 * @package AppBundle\NativeSql
 * @author Martin Kock <kock@uni-trier.de>
 */
class SearchNormalizationTest
    extends PHPUnit_Framework_TestCase
{
    const FULLTEXT_ENGINE_SEARCH_WORD_1 = 'Trier';
    const FULLTEXT_ENGINE_SEARCH_WORD_2 = 'Fliegeralarm!';
    const FULLTEXT_KEYWORD_SUPPORTED = 1;
    const FULLTEXT_KEYWORD_NOT_SUPPORTED = 2;

    public function testGetLoneAsteriskCleanedString_nullString()
    {
        $input = null;
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEmpty($cleaned);
    }

    public function testGetLoneAsteriskCleanedString_emptyString()
    {
        $input = '';
        $expected = '';
        $result = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertSame($expected, $result);
    }

    public function testGetLoneAsteriskCleanedString_oneAsteriskOnlyString()
    {
        $input = '*';
        $expected = '';
        $result = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertSame($expected, $result);
    }

    public function testGetLoneAsteriskCleanedString_twoConsecutiveAsteriskString()
    {
        $input = 'a**';
        $expected = 'a*';
        $result = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $result);
    }

    public function testGetLoneAsteriskCleanedString_twoAsterisAndOneIsLonekString()
    {
        $input = 'a* *';
        $expected = 'a*';
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetLoneAsteriskCleanedString_oneAsteriskAndOneSymbolString()
    {
        $input = 'a, *';
        $expected = 'a,';
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetLoneAsteriskCleanedString_oneAsteriskAfterSymbolString()
    {
        $input = 'a,*';
        $expected = 'a,';
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetLoneAsteriskCleanedString_oneAsteriskAfterExclamationMarkSymbolString()
    {
        $input = 'a!*';
        $expected = 'a!';
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetLoneAsteriskCleanedString_manyAsteriskOneIsLoneString()
    {
        $input = 'a** b* c *';
        $expected = 'a* b* c';
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetLoneAsteriskCleanedString_manyAsteriskOneIsSuffixOneIsLoneString()
    {
        $input = 'a** b*c d *';
        $expected = 'a* b*c d';
        $cleaned = SearchNormalization::getLoneAsteriskWithoutPrefixCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_nullString()
    {
        $input = null;
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEmpty($cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_emptyString()
    {
        $input = '';
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEmpty($cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_oneAsteriskString()
    {
        $input = '*';
        $expected = '*';
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_oneConsecutiveAsteriskSeriesOfTwokString()
    {
        $input = '**';
        $expected = '*';
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_oneConsecutiveAsteriskSeriesOfThree()
    {
        $input = '***';
        $expected = '*';
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_twoOneAsteriskSeriesString()
    {
        $input = '* *';
        $expected = '* *';
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetConsecutiveAsteriskCleanedString_twoDoubleAsteriskSeriesString()
    {
        $input = '** **';
        $expected = '* *';
        $cleaned = SearchNormalization::getConsecutiveAsteriskCleanedString($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_nullString()
    {
        $input = null;
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEmpty($cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_emptyString()
    {
        $input = '';
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEmpty($cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_asteriskString()
    {
        $input = SearchNormalization::SUPPORTED_SYMBOL_ASTERISK;
        $expected = '*';
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_asteriskStringHasNoSpace()
    {
        $input = 'abc*d';
        $expected = 'abc*d';
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_doubleQuoteString()
    {
        $input = SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE;
        $expected = '"';
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_supportedSymbols()
    {
        $input = '!$%^&()+|~=`{}[]:;\'<>?,./\\';
        $inputArray = str_split($input);
        $expectedFull = '';

        foreach ($inputArray as $symbol) {
            // because of the trim
            $expected = $symbol;
            $expectedFull .= sprintf('%s ', $symbol);
            $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($symbol);
            self::assertEquals($expected, $cleaned);
        }

        self::assertEquals(trim($expectedFull), SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input));
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_slashString()
    {
        $input = '/';
        $expected = '/';
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetStringWithSpaceAfterEverySearchSymbol_backslashString()
    {
        $input = '\\';
        $expected = '\\';
        $cleaned = SearchNormalization::getStringWithSpaceAfterEverySearchSymbol($input);
        self::assertEquals($expected, $cleaned);
    }

    public function testGetStringWithReplacedFulltextEngineKeywords_withNullStringAsInput_successfulReturnsEmptyString()
    {
        $input = null;
        $expected = SearchNormalization::NO_SPACE;
        $result = SearchNormalization::getFilteredStringWithSupportedFulltextOperationsOnly($input);
        self::assertSame($expected, $result);
    }

    public function dbFulltextEngineKeywordProvider(): array
    {
        return [
            'ASTERISK Symbol' => [
                SearchNormalization::SUPPORTED_SYMBOL_ASTERISK,
                self::FULLTEXT_KEYWORD_SUPPORTED,
            ],
            'PLUS Symbol' => [
                '+',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
            'MINUS Symbol' => [
                '-',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
            'GREATER Symbol' => [
                '>',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
            'LOWER Symbol' => [
                '<',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
            'ROUND BRACKET OPEN Symbol' => [
                '(',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
            'ROUND BRACKET CLOSE Symbol' => [
                ')',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
            'TILDA tha SNAKE Symbol' => [
                '~',
                self::FULLTEXT_KEYWORD_NOT_SUPPORTED,
            ],
        ];
    }

    /**
     * Tests the sql normalization for the cleaning of MariaDB fulltext engine keywords.
     *
     * @param string $symbol The fulltext engine keyword/operator
     * @param int $supportedKeyword Supported/not supported by us
     *
     * @dataProvider dbFulltextEngineKeywordProvider
     *
     * @link SearchNormalization::getStringWithReplacedFulltextEngineKeywords($input, $replacement)
     */
    public function testKeywordReplacement_withoutQuotes(string $symbol, int $supportedKeyword)
    {
        $input = sprintf(
            '%s %s %s',
            self::FULLTEXT_ENGINE_SEARCH_WORD_1,
            $symbol,
            self::FULLTEXT_ENGINE_SEARCH_WORD_2
        );

        switch ($supportedKeyword) {
            case self::FULLTEXT_KEYWORD_SUPPORTED:
                $expectedWithSpace = $input;

                break;

            case self::FULLTEXT_KEYWORD_NOT_SUPPORTED:
                $expectedWithSpace = sprintf(
                    '%s %s',
                    self::FULLTEXT_ENGINE_SEARCH_WORD_1,
                    self::FULLTEXT_ENGINE_SEARCH_WORD_2
                );

                break;

            default:
                throw new InvalidArgumentException(
                    sprintf('Type for supported keyword is unknown <%d>.', $supportedKeyword)
                );
        }

        $resultWithSpace = SearchNormalization::getFilteredStringWithSupportedFulltextOperationsOnly($input);

        self::assertSame(
            $expectedWithSpace,
            $resultWithSpace,
            self::getFulltextEngineAssertMessage(
                $symbol,
                $input,
                $expectedWithSpace,
                $resultWithSpace
            )
        );
    }

    /**
     * Test words with quotes.
     *
     * @param string $symbol The fulltext engine keyword/operator
     * @param int $supportedKeyword Supported/not supported by us
     *
     * @dataProvider dbFulltextEngineKeywordProvider
     */
    public function testKeywordReplacement_withWordQuotes(string $symbol, int $supportedKeyword)
    {
        $input = sprintf(
            '%s%s%s %s %s%s%s',
            SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
            self::FULLTEXT_ENGINE_SEARCH_WORD_1,
            SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
            $symbol,
            SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
            self::FULLTEXT_ENGINE_SEARCH_WORD_2,
            SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE
        );

        switch ($supportedKeyword) {
            case self::FULLTEXT_KEYWORD_SUPPORTED:
                $expectedWithSpace = $input;

                break;

            case self::FULLTEXT_KEYWORD_NOT_SUPPORTED:
                $expectedWithSpace = sprintf(
                    '%s%s%s %s%s%s',
                    SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
                    self::FULLTEXT_ENGINE_SEARCH_WORD_1,
                    SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
                    SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
                    self::FULLTEXT_ENGINE_SEARCH_WORD_2,
                    SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE
                );

                break;

            default:
                throw new InvalidArgumentException(
                    sprintf('Type for supported keyword is unknown <%d>.', $supportedKeyword)
                );
        }

        $resultWithSpace = SearchNormalization::getFilteredStringWithSupportedFulltextOperationsOnly($input);

        self::assertSame(
            $expectedWithSpace,
            $resultWithSpace,
            self::getFulltextEngineAssertMessage(
                $symbol,
                $input,
                $expectedWithSpace,
                $resultWithSpace
            )
        );
    }

    /**
     * Test Keywords wit full quotes.
     *
     * @param string $symbol The fulltext engine keyword/operator
     * @param int $supportedKeyword Supported/not supported by us
     *
     * @dataProvider dbFulltextEngineKeywordProvider
     */
    public function testKeywordReplacement_withFullQuotes(string $symbol, int $supportedKeyword)
    {
        $input = sprintf(
            '%s%s %s %s%s',
            SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
            self::FULLTEXT_ENGINE_SEARCH_WORD_1,
            $symbol,
            self::FULLTEXT_ENGINE_SEARCH_WORD_2,
            SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE
        );

        switch ($supportedKeyword) {
            case self::FULLTEXT_KEYWORD_SUPPORTED:
                $expectedWithSpace = $input;
                break;
            case self::FULLTEXT_KEYWORD_NOT_SUPPORTED:
                $expectedWithSpace = sprintf(
                    '%s%s %s%s',
                    SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE,
                    self::FULLTEXT_ENGINE_SEARCH_WORD_1,
                    self::FULLTEXT_ENGINE_SEARCH_WORD_2,
                    SearchNormalization::SUPPORTED_SYMBOL_DOUBLE_QUOTE
                );

                break;

            default:
                throw new InvalidArgumentException(
                    sprintf('Type for supported keyword is unknown <%d>.', $supportedKeyword)
                );
        }

        $resultWithSpace = SearchNormalization::getFilteredStringWithSupportedFulltextOperationsOnly($input);

        self::assertSame(
            $expectedWithSpace,
            $resultWithSpace,
            self::getFulltextEngineAssertMessage(
                $symbol,
                $input,
                $expectedWithSpace,
                $resultWithSpace
            )
        );
    }

    /**
     * Helper for fulltext engine tests assert messages.
     *
     * @param string $symbol
     * @param string $input
     * @param string $expected
     * @param string $result
     *
     * @return string
     */
    private static function getFulltextEngineAssertMessage(
        string $symbol,
        string $input,
        string $expected,
        string $result
    ): string
    {
        return sprintf(
            "Test KEYWORD replacement for MariaDB Fulltext Engine operator <%s> doesn't match. Input was <%s>, expected <%s>, got <%s>.",
            $symbol,
            $input,
            $expected,
            $result
        );
    }
}
