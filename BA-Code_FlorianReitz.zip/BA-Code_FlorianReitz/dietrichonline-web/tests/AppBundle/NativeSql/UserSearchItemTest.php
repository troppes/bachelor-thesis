<?php

/**
 * Created by PhpStorm.
 * User: kock
 * Date: 11.10.2018
 * Time: 14:38
 */

namespace Tests\AppBundle\NativeSql;

use AppBundle\NativeSql\UserSearchItem;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

class UserSearchItemTest extends TestCase
{
    const ALL_JUNKTORS = [
        UserSearchItem::JUNKTOR_NO,
        UserSearchItem:: JUNKTOR_AND,
        UserSearchItem:: JUNKTOR_OR,
        UserSearchItem::JUNKTOR_AND_NOT
    ];

    const ALL_TYPES = [
        UserSearchItem::TYPE_LEMMA,
        UserSearchItem::TYPE_GND,
        UserSearchItem::TYPE_ARTIKEL,
        UserSearchItem::TYPE_AUTOR,
        UserSearchItem::TYPE_DDC,
        UserSearchItem::TYPE_SIGLE,
        UserSearchItem::TYPE_BAND,
        UserSearchItem::TYPE_DIETRICHLITERATURREFERENZ,
        UserSearchItem::TYPE_NORMLITERATURREFERENZ,
        UserSearchItem::TYPE_VON_JAHR,
        UserSearchItem::TYPE_BIS_JAHR
    ];

    const EMPTY_VALUE = '';

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_nullJunktor_throwsException()
    {
        new UserSearchItem(null, null, null);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_emptyJunktor_throwsException()
    {
        new UserSearchItem(self::EMPTY_VALUE, null, null);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_nullType_throwsException()
    {
        new UserSearchItem(UserSearchItem::JUNKTOR_NO, null, null);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_emptyType_throwsException()
    {
        new UserSearchItem(UserSearchItem::JUNKTOR_NO, self::EMPTY_VALUE, null);
    }

    public function test__construct_nullValue()
    {
        new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_SIGLE, null);
        self::assertTrue(true, 'only check if previous statement completes without throwing an exception.');
    }

    public function test__construct_emptyValue()
    {
        new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_SIGLE, self::EMPTY_VALUE);
        self::assertTrue(true, 'only check if previous statement completes without throwing an exception.');
    }

    public function test__construct_validJunktorBoundary()
    {
        foreach (self::ALL_JUNKTORS as $junktor) {
            new UserSearchItem($junktor, UserSearchItem::TYPE_SIGLE, null);
        }
        self::assertTrue(true, 'only check if previous statement completes without throwing an exception.');
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_invalidJunktorBoundaryMin_throwsException()
    {
        $junktorBoundaryShot = UserSearchItem::JUNKTOR_NO - 1;
        new UserSearchItem($junktorBoundaryShot, UserSearchItem::TYPE_SIGLE, null);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_invalidJunktorBoundaryMax_throwsException()
    {
        $junktorBoundaryShot = UserSearchItem::JUNKTOR_AND_NOT + 1;
        new UserSearchItem($junktorBoundaryShot, UserSearchItem::TYPE_SIGLE, null);
    }

    public function test__construct_validTypeBoundary()
    {
        foreach (self::ALL_TYPES as $type) {
            new UserSearchItem(UserSearchItem::JUNKTOR_NO, $type, null);
        }
        self::assertTrue(true, 'only check if previous statement completes without throwing an exception.');
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_invalidTypeBoundaryMin_throwsException()
    {
        $junktorBoundaryShot = UserSearchItem::TYPE_LEMMA - 1;
        new UserSearchItem(UserSearchItem::JUNKTOR_NO, $junktorBoundaryShot, null);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function test__construct_invalidTypeBoundaryMax_throwsException()
    {
        $junktorBoundaryShot = UserSearchItem::TYPE_BIS_JAHR + 1;
        new UserSearchItem(UserSearchItem::JUNKTOR_NO, $junktorBoundaryShot, null);
    }

    public function testIsEmpty_nullValue()
    {
        $usi = new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_LEMMA, null);
        self::assertTrue($usi->isEmpty());
    }

    public function testIsEmpty_emptyValue_isNotEmpty()
    {
        $usi = new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_LEMMA, self::EMPTY_VALUE);
        self::assertFalse($usi->isEmpty());
    }

    public function testIsEmpty_settedValue_isNotEmpty()
    {
        $usi = new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_LEMMA, 'abc');
        self::assertFalse($usi->isEmpty());
    }


    public function testIsValid()
    {
        //still tested via the constructor
        self::assertTrue(true, 'only check if previous statement completes without throwing an exception.');
    }

    public function testCreateNormalizedValue_nullValue()
    {
        $testValue = null;
        $usi = new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_LEMMA, $testValue);
        self::assertEquals(self::EMPTY_VALUE, $usi->getSqlNormalizedValue());
    }

    public function testCreateNormalizedValue_emptyValue()
    {
        $testValue = self::EMPTY_VALUE;
        $usi = new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_LEMMA, $testValue);
        self::assertEquals(self::EMPTY_VALUE, $usi->getSqlNormalizedValue());
    }


    public function testCreateNormalizedValue_asteriskOnly()
    {
        $testValue = '*';
        $usi = new UserSearchItem(UserSearchItem::JUNKTOR_NO, UserSearchItem::TYPE_LEMMA, $testValue);
        self::assertEquals(self::EMPTY_VALUE, $usi->getSqlNormalizedValue());
    }
}
