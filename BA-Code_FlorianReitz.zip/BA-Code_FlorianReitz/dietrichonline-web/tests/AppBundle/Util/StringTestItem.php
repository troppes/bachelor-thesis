<?php


namespace Tests\AppBundle\Util;


use AppBundle\Util\Preconditions;

/**
 * An instance of the class <code>StringTestItem</code> represents an item for special string tests.
 * <p>
 * With this class can you give some test methods a string and the threshold for testing.
 *
 * @package Tests\AppBundle\Util
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class StringTestItem
{
    const CONTAINS_EXACTLY = 1;
    const CONTAINS_BLURRY = 2;

    /** @var string $string */
    private $string;
    /** @var TestContainsString $testRun */
    private $testRun;

    /**
     * StringTestTupel constructor.
     * @param string $string
     * @param int $testRun
     */
    public function __construct(string $string, int $testRun = self::CONTAINS_EXACTLY)
    {
        Preconditions::notNull($string, 'string');
        Preconditions::notNull($testRun, 'TestRun');
        Preconditions::checkIsInRange($testRun,
                                      'contains constant',
                                      self::CONTAINS_EXACTLY,
                                      self::CONTAINS_BLURRY);

        $this->string = $string;
        $this->testRun = $testRun;
    }

    /**
     * @return string
     */
    public function getString(): string
    {
        return $this->string;
    }

    /**
     * @return TestContainsString
     */
    public function getTestRun(): int
    {
        return $this->testRun;
    }
}