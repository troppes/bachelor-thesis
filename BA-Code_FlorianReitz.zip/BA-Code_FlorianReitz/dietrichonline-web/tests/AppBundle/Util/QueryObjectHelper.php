<?php

namespace Tests\AppBundle\Util;

use AppBundle\Entity\ArtikelEntity;
use AppBundle\Entity\ArtikelUrlEntity;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\BandUrlEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Entity\GndEntity;
use AppBundle\Entity\LemmabearbeitungsstatusEntity;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Entity\LemmaGndEntity;
use AppBundle\Entity\LiteraturreferenzbearbeitungsstatusEntity;
use AppBundle\Entity\LiteraturtypEntity;
use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Entity\WerkUrlEntity;

class QueryObjectHelper
{

    /**
     * A function to help create an Artikel entity
     *
     * @param int $id Since this table doesn't have auto increment, a valid id is needed
     * @param LemmaEntity $lemmaEntity The lemma entity linked to the article
     * @param BandEntity $bandEntity The Band entity the article is in. Found in Table band
     * @param string $title The title of the article
     *
     * @return ArtikelEntity
     */
    public static function createArticleEntity(
        int $id,
        LemmaEntity $lemmaEntity,
        BandEntity $bandEntity,
        string $title
    ): ArtikelEntity
    {
        $article = new ArtikelEntity();
        $article->setId($id);
        $article->setTitel($title);
        $article->setLemmaEntity($lemmaEntity);
        $article->setBandEntity($bandEntity);

        return $article;
    }

    /**
     * A function to help create an Lemma entity
     *
     * @param string $bezeichnung The description for the lemma
     * @param bool $istGndVerzeichnet Boolean value whether the Lemma is in the GND
     * @param bool $istGeloescht Boolean Value whether the the Lemma is deleted
     * @param LemmabearbeitungsstatusEntity $bStatus LemmaBearbeitungsstatusEntity
     *
     * @return LemmaEntity
     */

    public static function createLemmaEntity(
        string $bezeichnung,
        bool $istGndVerzeichnet,
        bool $istGeloescht,
        LemmabearbeitungsstatusEntity $bStatus
    ): LemmaEntity
    {
        $lemmaEntity = new LemmaEntity();
        $lemmaEntity->setBezeichnung($bezeichnung);
        $lemmaEntity->setIstGndVerzeichnet(intval($istGndVerzeichnet));
        $lemmaEntity->setIstGeloescht(intval($istGeloescht));
        $lemmaEntity->setLemmabearbeitungsstatusEntity($bStatus);

        return $lemmaEntity;
    }

    /**
     * A function to help create an Literaturreferenz entity
     *
     * @param string $sigle The Sigle for the LitRef
     * @param string $bezeichnung The description for the LitRef
     * @param LiteraturreferenzbearbeitungsstatusEntity $litStatus The Status taken from the Table: literaturreferenzbearbeitungsstatus
     * @param BandEntity $band The band the LitRef is taken from. Found in table: band
     *
     * @return DietrichliteraturreferenzEntity
     */

    public static function createLitRefEntity(
        string $sigle,
        string $bezeichnung,
        LiteraturreferenzbearbeitungsstatusEntity $litStatus,
        BandEntity $band
    ): DietrichliteraturreferenzEntity
    {
        $litrefEntity = new DietrichliteraturreferenzEntity();
        $litrefEntity->setSigle($sigle);
        $litrefEntity->setDietrichbezeichnung($bezeichnung);
        $litrefEntity->setLiteraturreferenzbearbeitungsstatusEntity($litStatus);
        $litrefEntity->setBandEntity($band);

        return $litrefEntity;
    }

    /**
     * A function to help create an Normliteraturreferenz entity
     *
     * @param LiteraturtypEntity $litType The type of the NormLitRef, taken from literaturtyp
     * @param bool $hasNoneWerkUrl Sets if the NormLitRef does not have a Werk-Url
     * @param string $kvkBezeichnung Sets the KVK-Bezeichnung von der NormLitRef. If you want to use ZBD entries, you cant use this method
     *
     * @return NormliteraturreferenzEntity
     */
    public static function createNormLitRefEntity(
        LiteraturtypEntity $litType,
        bool $hasNoneWerkUrl,
        string $kvkBezeichnung
    ): NormliteraturreferenzEntity
    {
        $normLitRefEntity = new NormliteraturreferenzEntity();
        $normLitRefEntity->setLiteraturtypEntity($litType);
        $normLitRefEntity->setKeineWerkUrlGefunden($hasNoneWerkUrl);
        $normLitRefEntity->setKvkBezeichnung($kvkBezeichnung);

        return $normLitRefEntity;
    }

    /**
     * A function to help create an WerkUrl entity
     *
     * @param string $url The Url to the Werk
     * @param NormliteraturreferenzEntity $normliteraturreferenzEntity The NormLitRef this Werk is bound to
     *
     * @return WerkUrlEntity
     */
    public static function createWerkUrlEntity(
        string $url,
        NormliteraturreferenzEntity $normliteraturreferenzEntity
    ): WerkUrlEntity
    {
        $werkUrlEntity = new WerkUrlEntity();
        $werkUrlEntity->setUrl($url);
        $werkUrlEntity->setNormliteraturreferenzEntity($normliteraturreferenzEntity);

        return $werkUrlEntity;
    }

    /**
     * A function to help create an BandUrl entity
     *
     * @param string $url The URl to the Band.
     * @param DietrichlitrefNormlitrefEntity $dietrichlitrefNormlitrefEntity The LitRef Entity this Band is bound to
     *
     * @return BandUrlEntity
     */
    public static function createBandUrlEntity(
        string $url,
        DietrichlitrefNormlitrefEntity $dietrichlitrefNormlitrefEntity
    ): BandUrlEntity
    {
        $bandUrlEntity = new BandUrlEntity();
        $bandUrlEntity->setUrl($url);
        $bandUrlEntity->setDietrichlitrefNormlitrefEntity($dietrichlitrefNormlitrefEntity);

        return $bandUrlEntity;
    }

    /**
     * A function to help create an ArtikelURL entity
     *
     * @param string $url The URL to the article.
     * @param ArtikelEntity $article The article this entity is bound to.
     *
     * @return ArtikelUrlEntity
     */
    public static function createArticleUrlEntity(string $url, ArtikelEntity $article): ArtikelUrlEntity
    {
        $articleUrlEntity = new ArtikelUrlEntity();
        $articleUrlEntity->setUrl($url);
        $articleUrlEntity->setArtikelEntity($article);

        return $articleUrlEntity;
    }

    /**
     * A function to help create an LemmaGND entity
     *
     * @param LemmaEntity $lemmaEntity The lemma entity that should be bound to the GND entity.
     * @param GndEntity $gndEntity The GND entity that should be bound to the lemma entity.
     *
     * @return LemmaGndEntity
     */
    public static function createLemmaGndEntity(LemmaEntity $lemmaEntity, GndEntity $gndEntity): LemmaGndEntity
    {
        $lemmaGndEntity = new LemmaGndEntity();
        $lemmaGndEntity->setLemmaEntity($lemmaEntity);
        $lemmaGndEntity->setGndEntity($gndEntity);

        return $lemmaGndEntity;
    }

    /**
     * A function to help create an DietrichlitrefNormlitref entity
     *
     * @param DietrichliteraturreferenzEntity $litRef The Dietrichliteraturreferenz entity that should be bound to the Normliteraturreferenz entity.
     * @param NormliteraturreferenzEntity $normLitRef The Normliteraturreferenz entity that should be bound to the Dietrichliteraturreferenz entity.
     *
     * @return DietrichlitrefNormlitrefEntity
     */
    public static function createDietrichlitrefNormlitrefEntity(
        DietrichliteraturreferenzEntity $litRef,
        NormliteraturreferenzEntity $normLitRef
    ): DietrichlitrefNormlitrefEntity
    {
        $dLitRefNormLitRef = new DietrichlitrefNormlitrefEntity();
        $dLitRefNormLitRef->setDietrichliteraturreferenzEntity($litRef);
        $dLitRefNormLitRef->setNormliteraturreferenzEntity($normLitRef);

        return $dLitRefNormLitRef;
    }

}
