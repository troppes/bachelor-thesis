<?php


namespace Tests\AppBundle\Util;


use AppBundle\Util\Preconditions;
use DOMDocument;
use DOMXPath;
use Symfony\Bundle\FrameworkBundle\Client;

/**
 * The class HtmlContentUtils contains functions for convenience validating of html content.
 *
 * @package Tests\AppBundle\Util
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class HtmlContentUtils
{
    /**
     * Returns the state if a headline (with level) contains the given label.
     * <p>
     * You can test if the headline contains the label exactly between the html tags or between only. To activate set it in the depending StingTestItem.
     * <p>
     * Example:
     *   StringTestItem::CONTAINS_EXACTLY:
     *     <code>isHeadlineAvailable(client, Headline, 1)</code> checks for <code><h1>Headline</h1></code>
     *
     *   StringTestItem::CONTAINS_BLURRY:
     *     <code>isHeadlineAvailable(client, Headline, 1)</code> checks for <code><h1>...Headline...</h1></code>
     *
     * @param Client $client
     * @param StringTestItem $labelItem
     * @param int $headLineLevel
     *
     * @return bool <code>true</code> if the headline contains the label, otherwise <code>false</code>
     */
    public static function isHeadlineAvailable(Client $client, StringTestItem $labelItem, int $headLineLevel = 1): bool
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($labelItem, 'HeadLineLabel');
        Preconditions::notNull($headLineLevel, 'HeadlineSize');

        $htmlContent = $client->getResponse()->getContent();

        $headlineContainsLabel = false;

        switch ($labelItem->getTestRun())
        {
            case StringTestItem::CONTAINS_EXACTLY:
                $headline = sprintf('<h%d>%s</h%d>',
                                    $headLineLevel,
                                    $labelItem->getString(),
                                    $headLineLevel);
                if (strpos($htmlContent, $headline) !== false) {
                    $headlineContainsLabel = true;
                }

                break;

            case StringTestItem::CONTAINS_BLURRY:
                $headlineTagStart = sprintf('<h%d>', $headLineLevel);
                $headlineTagClose = sprintf('</h%d>', $headLineLevel);

                $startHeadline = strpos($htmlContent, $headlineTagStart);
                $endHeadline = strpos($htmlContent, $headlineTagClose);
                $completeHeadline = substr($htmlContent, $startHeadline, $endHeadline);

                if (strpos($completeHeadline, $labelItem->getString()) !== false) {
                    $headlineContainsLabel = true;
                }

                break;

            default:
                throw new \RuntimeException("Value <%s> is not valid, because of unknown TestRun type.");
        }

        return $headlineContainsLabel;
    }


    public static function isTopLevelMenuAvailable(
        Client $client,
        StringTestItem $labelItem
    ): bool
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($labelItem, 'HeadLineLabel');

        $htmlContent = $client->getResponse()->getContent();

        $headlineContainsLabel = false;

        $xpathQuery = '//div[@id="headline"]//h1';


        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath = new DOMXpath($doc);

        $matches = $xpath->query($xpathQuery);

        switch ($labelItem->getTestRun()) {
            case StringTestItem::CONTAINS_EXACTLY:
                $headlineElement = $matches[0]->lastChild->nodeValue;
                $headline = sprintf(
                    "%s",
                    $labelItem->getString()
                );
                if ($headlineElement === $headline) {
                    $headlineContainsLabel = true;
                }
                break;
            case StringTestItem::CONTAINS_BLURRY:
                $headlineElement = $matches[0]->lastChild->NodeValue;
                $headline = sprintf(
                    "%s",
                    $labelItem->getString()
                );
                if (strpos($headlineElement, $headline) !== false) {
                    $headlineContainsLabel = true;
                }
                break;
            default:
                throw new \RuntimeException("Value <%s> is not valid, because of unknown TestRun type.");
        }

        return $headlineContainsLabel;
    }
}