<?php
/**
 * Created by PhpStorm.
 * User: kock
 * Date: 16.10.2018
 * Time: 09:05
 */

namespace AppBundle\Util;


/**
 * Class ParamValidationTest
 * @package AppBundle\Util
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class PreconditionsTest extends \PHPUnit_Framework_TestCase
{
    const NOT_NULL_INT = 1;
    const NOT_NULL_STRING = 'ParamName';
    const EMPTY_STRING = '';

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotNull_paramIsNullAndParamNameIsNull_failsWithException()
    {
        $param = null;
        $paramName = null;
        Preconditions::notNull($param, $paramName);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotNull_paramIsNullAndParamNameIsNotNull_failsWithException()
    {
        $param = null;
        $paramName = self::NOT_NULL_STRING;
        Preconditions::notNull($param, $paramName);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotNull_paramIsNotNullAndParamNameIsNull_failsWithException()
    {
        $param = self::NOT_NULL_INT;
        $paramName = null;
        Preconditions::notNull($param, $paramName);
    }

    public function testNotNull_paramIsNotNullAndParamNameIsNotNull()
    {
        $param = self::NOT_NULL_INT;
        $paramName = self::NOT_NULL_STRING;
        Preconditions::notNull($param, $paramName);
        $noExceptionWasThrown = true;
        self::assertTrue($noExceptionWasThrown);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotEmpty_paramIsNullAndParamNameIsNull_failsWithException()
    {
        $param = null;
        $paramName = null;
        Preconditions::notEmpty($param, $paramName);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotEmpty_paramIsNullAndParamNameIsNotNull_failsWithException()
    {
        $param = null;
        $paramName = self::NOT_NULL_STRING;
        Preconditions::notEmpty($param, $paramName);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotEmpty_paramIsNotNullAndParamNameIsNull_failsWithException()
    {
        $param = self::NOT_NULL_INT;
        $paramName = null;
        Preconditions::notEmpty($param, $paramName);
    }

    public function testNotEmpty_paramIsNotNullAndParamNameIsNotNull()
    {
        $param = self::NOT_NULL_INT;
        $paramName = self::NOT_NULL_STRING;
        Preconditions::notEmpty($param, $paramName);
        $noExceptionWasThrown = true;
        self::assertTrue($noExceptionWasThrown);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotEmpty_paramIsEmptyAndParamNameIsEmpty_failsWithException()
    {
        $param = self::EMPTY_STRING;
        $paramName = self::EMPTY_STRING;
        Preconditions::notEmpty($param, $paramName);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotEmpty_paramIsEmptyAndParamNameIsNotNull_failsWithException()
    {
        $param = self::EMPTY_STRING;
        $paramName = self::NOT_NULL_STRING;
        Preconditions::notEmpty($param, $paramName);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testNotEmpty_paramIsNotNullAndParamNameIsEmpty_failsWithException()
    {
        $param = self::NOT_NULL_INT;
        $paramName = self::EMPTY_STRING;
        Preconditions::notEmpty($param, $paramName);
    }

    public function testNotEmpty_paramIsNotEmptyAndParamNameIsNotEmpty()
    {
        $param = self::NOT_NULL_INT;
        $paramName = self::NOT_NULL_STRING;
        Preconditions::notEmpty($param, $paramName);
        $noExceptionWasThrown = true;
        self::assertTrue($noExceptionWasThrown);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testIsInRange_paramMinAndMaxAreEqual_failsWithExecption()
    {
        $testValue = 1;
        $testName = self::NOT_NULL_STRING;
        $minValue = 1;
        $maxValue = 1;

        Preconditions::checkIsInRange($testValue, $testName, $minValue, $maxValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testIsInRange_paramMinIsGreaterThanMax_failsWithExecption()
    {
        $testValue = 1;
        $testName = self::NOT_NULL_STRING;
        $minValue = 2;
        $maxValue = 1;

        Preconditions::checkIsInRange($testValue, $testName, $minValue, $maxValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testIsInRange_paramMaxIsGreaterThanMinAndValueIsGreaterAndNotInRange_failsWithException()
    {
        $testValue = 3;
        $testName = self::NOT_NULL_STRING;
        $minValue = 1;
        $maxValue = 2;

        Preconditions::checkIsInRange($testValue, $testName, $minValue, $maxValue);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testIsInRange_paramMaxIsGreaterThanMinAndValueIsLowerAndNotInRange_failsWithException()
    {
        $testValue = 0;
        $testName = self::NOT_NULL_STRING;
        $minValue = 1;
        $maxValue = 2;

        Preconditions::checkIsInRange($testValue, $testName, $minValue, $maxValue);
    }

    public function testIsInRange_paramMaxIsGreaterThanMinAndValueInRange()
    {
        $testValue = 1;
        $testName = self::NOT_NULL_STRING;
        $minValue = 1;
        $maxValue = 2;

        Preconditions::checkIsInRange($testValue, $testName, $minValue, $maxValue);
    }

    /**
     * @expectedException \TypeError
     */
    public function testCheckLength_paramValueIsNull_failedWithTypeError()
    {
        $value = null;
        $name = self::NOT_NULL_STRING;

        Preconditions::checkMaxLength($value, $name);
    }

    public function testCheckLength_paramValueIsEmptyWithDefaultLength_success()
    {
        $value = '';
        $name = self::NOT_NULL_STRING;

        Preconditions::checkMaxLength($value, $name);
    }

    public function testCheckLength_paramValueIsEmptyWithZeroLength_success()
    {
        $value = '';
        $name = self::NOT_NULL_STRING;
        $length = 0;

        Preconditions::checkMaxLength($value, $name, $length);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testCheckLength_paramValueIsEmptyWithNegativeLength_failed()
    {
        $value = '';
        $name = self::NOT_NULL_STRING;
        $length = -1;

        Preconditions::checkMaxLength($value, $name, $length);
    }

    /**
     * @expectedException \InvalidArgumentException
     */
    public function testCheckLength_paramValueIsSetWithSmallerLength_failed()
    {
        $value = 'a';
        $name = self::NOT_NULL_STRING;
        $length = 0;

        Preconditions::checkMaxLength($value, $name, $length);
    }

    public function testCheckLength_paramValueIsSetWithEqualLength_success()
    {
        $value = 'a';
        $name = self::NOT_NULL_STRING;
        $length = 1;

        Preconditions::checkMaxLength($value, $name, $length);
    }

    public function testCheckLength_paramValueIsSetWithGreaterLength_success()
    {
        $value = 'a';
        $name = self::NOT_NULL_STRING;
        $length = 2;

        Preconditions::checkMaxLength($value, $name, $length);
    }
}
