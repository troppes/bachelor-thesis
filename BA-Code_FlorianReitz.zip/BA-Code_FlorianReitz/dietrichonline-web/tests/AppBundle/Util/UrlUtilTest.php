<?php


namespace Tests\AppBundle\Util;

use AppBundle\Util\UrlUtil;
use InvalidArgumentException;
use TypeError;

class UrlUtilTest extends \PHPUnit_Framework_TestCase
{
    /**
     * @expectedException TypeError
     */
    public function testGetDomainName_urlParamIsNullNull_failedWithTypeError()
    {
        UrlUtil::getDomainName(null);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testGetDomainName_urlParamIsNotAnUrl_failedWithException()
    {
        $url = 'url';
        UrlUtil::getDomainName($url);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testGetDomainName_urlParamIsNotAnUrl2_failedWithException()
    {
        $url = 'www.url';
        UrlUtil::getDomainName($url);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testGetDomainName_urlParamIsNotAnUrl3_failedWithException()
    {
        $url = 'http.www.url';
        UrlUtil::getDomainName($url);
    }

    /**
     * @expectedException InvalidArgumentException
     */
    public function testGetDomainName_urlParamIsNotAnUrl4_failedWithException()
    {
        $url = 'https://url';
        UrlUtil::getDomainName($url);
    }

    /**
     * ATM we filter not for valid IP addresses, so this one is only to describe the API.
     */
    public function testGetDomainName_urlParamIsIpAddress_success()
    {
        $url = 'http://192.168.0.1';
        $expected = '168.0.1';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsSmallerFourToTwoButWwwIsNoSubDomain2_successWithDomain()
    {
        $url = 'http://www.org';
        $expected = 'www.org';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsSmallerFourToTwoButWwwIsNoSubDomain3_successWithDomain()
    {
        $url = 'http://abc.org';
        $expected = 'abc.org';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsSmallerFourToTwoButWwwIsNoSubDomain_successWithDomain()
    {
        $url = 'https://www.four.de';
        $expected = 'four.de';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsSmallerThreeToThreeButWwwIsNoSubDomain_successWithDomain()
    {
        $url = 'https://www.abc.org';
        $expected = 'abc.org';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsSmallerWithoutSubDomain_successWithDomain()
    {
        $url = 'https://subdomain.abc.de';
        $expected = 'subdomain.abc.de';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsSmallerWithSubDomain_successWithDomain()
    {
        $url = 'https://www.subdomain.abc.de';
        $expected = 'subdomain.abc.de';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsBiggerWithoutSubDomain_successWithDomain()
    {
        $url = 'https://www.doma.tld';
        $expected = 'doma.tld';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }

    public function testGetDomainName_urlParamIsBiggerWithSubDomain_successWithDomain()
    {
        $url = 'https://www.subdomain.doma.tld';
        $expected = 'doma.tld';
        $result = UrlUtil::getDomainName($url);
        self::assertSame($expected, $result);
    }
}