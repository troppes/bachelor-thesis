<?php


namespace Tests\AppBundle\Controller;

/**
 * Description of BookmarksTest
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class BookmarksTest extends BaseWebTestCase
{
    const URL = 'bookmarks';

    public function setUp()
    {
        parent::setUp();
        $this->client->request('GET', $this->getTestHostUrl(self::URL));
    }

    public function test_doesPageExists_success()
    {
        $this->assertTrue($this->client->getResponse()->isOk());
        $this->assertTrue($this->client->getResponse()->isSuccessful());
    }

    public function test_noBookmarksAreMarked_showsNoEntryAvailableMessage()
    {
        $noEntriesAvailable = "Keine Einträge vorhanden ¯\_(ツ)_/¯";

        $html = $this->client->getCrawler()->html();
        $this->assertContains($noEntriesAvailable, $html);
    }

    public function test_oneBookmarkStored_ShowsOneEntryAvailableMessage()
    {
        $urlSuche = 'http://localhost:8000/suche';
        $formButtonLabel = "suchen";
        $searchFor = 'Trier';
        $expectedSearchResultHtmlBlock = 'search-result-count';
        // test only if more than 1 results are available, otherwise we need db access and thats to much as starter
        $expectedSearchResultMsg = 'Suchtreffer 1 - ';

        $searchPageClient = static::createClient();
        $searchPageClient->followRedirects();
        $spc = $searchPageClient->request('GET', $urlSuche);

        $this->assertNotNull($spc);
        $submitButton = $spc->selectButton($formButtonLabel);
        $form = $submitButton->form(array(
            'user_search[b1]' => $searchFor
        ));
        $this->assertNotNull($form);
        $searchPageClient->submit($form);

        $searchResultContent = $searchPageClient->getResponse()->getContent();
        $this->assertContains($expectedSearchResultHtmlBlock, $searchResultContent);
        $this->assertContains($expectedSearchResultMsg, $searchResultContent);

        //precondition -> counter is empty
        $this->assertContains("<b id=\"bookmark-counter\" ></b>", $searchResultContent);
        $this->assertEquals(0, BookmarkUtils::getBookmarkCount($searchResultContent));
    }
}
