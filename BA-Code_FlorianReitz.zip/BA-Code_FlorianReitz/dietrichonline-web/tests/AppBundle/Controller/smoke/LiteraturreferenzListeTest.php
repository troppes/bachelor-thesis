<?php


namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Util\Preconditions;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Controller\BaseWebTestCase;
use Tests\AppBundle\Util\HtmlContentUtils;
use Tests\AppBundle\Util\StringTestItem;

class LiteraturreferenzListeTest
    extends BaseWebTestCase
{
    const HTTP_OK = 200;
    const BAND    = 2;

    const LITREF_ROOT = 'literaturreferenzadministration';

    //it's a redirect, bad to test
    const LITREF_MAIN_URL       = self::LITREF_ROOT;
    const PAGED_REFERENCE_URL   = self::LITREF_ROOT.'/alle_literaturreferenzen/band/'.self::BAND.'/seite/1';
    const ALL_REFERENCE_URL     = self::LITREF_ROOT.'/alle_literaturreferenzen_auf_einer_seite/band/'.self::BAND;
    const NEW_REFERENCE_URL     = self::LITREF_ROOT.'/neue_literaturreferenzen/band/'.self::BAND.'/seite/1';
    const UNCLEAR_REFERENCE_URL = self::LITREF_ROOT.'/unklare_literaturreferenzen/band/'.self::BAND.'/seite/1';


    const PAGED_REFERENCE_HEADLINE   = 'Liste aller Literaturreferenzen in Band '.self::BAND.' (Seitenweise)';
    const ALL_REFERENCE_HEADLINE     = 'Liste aller Literaturreferenzen in Band '.self::BAND.' (auf einer Seite)';
    const NEW_REFERENCE_HEADLINE     = 'Liste neuer Literaturreferenzen in Band '.self::BAND;
    const UNCLEAR_REFERENCE_HEADLINE = 'Liste unklarer Literaturreferenzen in Band '.self::BAND;

    const PAGED_REFERENCE_MENU   = 'Liste <b>alle</b> Literaturreferenzen aus Band '.self::BAND.' (Seitenweise)';
    const ALL_REFERENCE_MENU     = 'Liste <b>alle</b> Literaturreferenzen aus Band '.self::BAND.' (auf einer Seite)';
    const NEW_REFERENCE_MENU     = 'Liste <b>neue</b> Literaturreferenzen aus Band '.self::BAND;
    const UNCLEAR_REFERENCE_MENU = 'Liste <b>unklare</b> Literaturreferenzen aus Band '.self::BAND;

    const MODULE_HEADLINE = 'Literaturreferenz-Administration';
    const LIST_HEADLINE   = 'Bände der Dietrich-Bibliographie';

    public function setUp()
    {
        parent::setUp();
    }

    /**
     * Returns a DataProvider with the supported application URLs.
     *
     * @return array
     */
    public function dataProvider()
    {
        return [
            'Paged References failed' => [
                self::PAGED_REFERENCE_URL,
                new StringTestItem(self::MODULE_HEADLINE),
                new StringTestItem(self::PAGED_REFERENCE_HEADLINE),
                self::PAGED_REFERENCE_MENU,
            ],
            'All References failed' => [
                self::ALL_REFERENCE_URL,
                new StringTestItem(self::MODULE_HEADLINE),
                new StringTestItem(self::ALL_REFERENCE_HEADLINE),
                self::ALL_REFERENCE_MENU,
            ],
            'New References failed' => [
                self::NEW_REFERENCE_URL,
                new StringTestItem(self::MODULE_HEADLINE),
                new StringTestItem(self::NEW_REFERENCE_HEADLINE),
                self::NEW_REFERENCE_MENU,
            ],
            'Unclear References failed' => [
                self::UNCLEAR_REFERENCE_URL,
                new StringTestItem(self::MODULE_HEADLINE),
                new StringTestItem(self::UNCLEAR_REFERENCE_HEADLINE),
                self::UNCLEAR_REFERENCE_MENU,
            ],
        ];
    }

    /**
     * A functional test that at least checks if your application pages are successfully loading.
     *
     * @param string $url Contains the URL
     *
     * @dataProvider dataProvider
     */
    public function testMainPagesAreAvailable_isSuccessful(string $url)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));
        $this->validateClientResponse($this->client);
    }


    /**
     * A functional test that checks if the website is available, the headlines are right and if the menu's are there
     *
     * @param string|null $url URL given by the dataProvider
     * @param StringTestItem|null $moduleHeadline
     * @param StringTestItem|null $headline Headline given by the dataProvider
     * @param string|null $menu Menu Text given by the dataProvider
     *
     * @dataProvider dataProvider
     */
    public function test_AllPageData_isSuccessful(
        $url,
        $moduleHeadline,
        $headline,
        $menu
    )
    {
        $this->client->request('GET', $this->getTestHostUrl($url));

        if ($moduleHeadline !== null) {
            self::assertTrue(
                HtmlContentUtils::isTopLevelMenuAvailable($this->client, $moduleHeadline),
                sprintf('Headline of <%s> could not be validated.', $url)
            );
        }

        if ($headline !== null) {
            self::assertTrue(
                HtmlContentUtils::isHeadlineAvailable($this->client, $headline, 2),
                sprintf('Headline of <%s> could not be validated.', $url)
            );
        }
        self::assertTrue(
            $this->isMenuAvailable($this->client, $menu),
            sprintf('Menu of <%s> could not be validated.', $url)
        );
    }

    /**
     * Validates that the given response is ok.
     *
     * @param Client $client
     */
    private function validateClientResponse(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url      = $client->getRequest()->getUri();

        self::assertTrue(
            $response->isSuccessful(),
            sprintf(
                "Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertTrue(
            $response->isOk(),
            sprintf(
                "Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf(
                "Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
    }

    /**
     * Validates that the given Client contains the phrase
     *
     * @param Client $client
     * @param string $menuLabel Text of the Menu that should be found. Can contain HTML if wanted
     *
     * @return bool
     */
    private function isMenuAvailable(Client $client, string $menuLabel): bool
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($menuLabel, 'MenuLabel');

        $htmlContent = $client->getResponse()->getContent();

        $regEx = '%(<div class="item">)\n*\s*('.preg_quote($menuLabel, '/').')\n*\s*<\/div>%';

        if (!preg_match($regEx, $htmlContent)) {
            return false;
        }

        return true;
    }
}
