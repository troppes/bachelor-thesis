<?php


namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Util\Preconditions;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Controller\BaseWebTestCase;
use Tests\AppBundle\Util\HtmlContentUtils;
use Tests\AppBundle\Util\StringTestItem;

class EmployeeOverviewTest
    extends BaseWebTestCase
{
    const HTTP_OK = 200;
    const BAND = 2;

    const OVERVIEW_URL = 'employee-overview';


    const HEADLINE = 'Mitarbeiter Übersicht';

    public function setUp()
    {
        parent::setUp();
    }


    /**
     * A functional test that at least checks if your application pages are successfully loading.
     */
    public function testMainPagesAreAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::OVERVIEW_URL));
        $this->validateClientResponse($this->client);
    }


    public function test_isHeadline_Available()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::OVERVIEW_URL));

        self::assertTrue(
            HtmlContentUtils::isTopLevelMenuAvailable($this->client, new StringTestItem(self::HEADLINE)),
            sprintf('Headline of the module could not be validated.')
        );
    }

    /**
     * Validates that the given response is ok.
     *
     * @param Client $client
     */
    private function validateClientResponse(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url = $client->getRequest()->getUri();

        self::assertTrue(
            $response->isSuccessful(),
            sprintf(
                "Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertTrue(
            $response->isOk(),
            sprintf(
                "Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf(
                "Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
    }


}
