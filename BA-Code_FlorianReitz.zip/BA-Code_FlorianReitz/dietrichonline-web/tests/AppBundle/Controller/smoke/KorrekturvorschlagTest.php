<?php


namespace Tests\AppBundle\Controller;

use AppBundle\Util\Preconditions;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Util\HtmlContentUtils;
use Tests\AppBundle\Util\StringTestItem;
use Tests\AppBundle\Util\TestContainsString;

class KorrekturvorschlagTest
    extends BaseWebTestCase
{
    const HTTP_OK = 200;
    const BAND = 2;

    const OVERVIEW_URL = 'korrekturvorschlagRedaktion';
    const OVERVIEW_LONG_URL = 'korrekturvorschlagRedaktion/banduebersicht';

    const NEW_CORRECTION_URL = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/neu';
    const ACCEPTED_CORRECTION_URL = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/angenommen';
    const UNCLEAR_CORRECTION_URL = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/unklar';
    const DENIED_CORRECTION_URL = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/abgelehnt';

    const NEW_CORRECTION_HEADLINE = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/neu';
    const ACCEPTED_CORRECTION_HEADLINE = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/angenommen';
    const UNCLEAR_CORRECTION_HEADLINE = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/unklar';
    const DENIED_CORRECTION_HEADLINE = self::OVERVIEW_URL . '/liste_band/' . self::BAND . '/filter/abgelehnt';

    const NEW_CORRECTION_MENU_TEXT = 'Status: neu';
    const ACCEPTED_CORRECTION_MENU_TEXT = 'Status: angenommen';
    const UNCLEAR_CORRECTION_MENU_TEXT = 'Status: unklar';
    const DENIED_CORRECTION_MENU_TEXT = 'Status: abgelehnt';

    const MODULE_HEADLINE = 'Korrekturvorschlag-Redaktion';
    const LIST_HEADLINE = 'Bände der Dietrich-Bibliographie';

    /* Data we can not validate exactly atm */
    const BLURRED_LINK_HEADLINE = 'Bandübersicht';
    const BLURRED_LINK_DIETRICH_VOLUME = self::BAND;


    public function setUp()
    {
        parent::setUp();
    }

    /**
     * Returns a DataProvider with the supported application URLs.
     *
     * @return array
     */
    public function dataProvider(): array
    {
        return [
            'Short Overview failed' => [
                self::OVERVIEW_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::LIST_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                null,
            ],
            'Long Overview failed' => [
                self::OVERVIEW_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::LIST_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                null,
            ],
            // two test to check for headline and band number in one headline
            'New correction list failed' => [
                self::NEW_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_HEADLINE, StringTestItem::CONTAINS_BLURRY),
                self::NEW_CORRECTION_MENU_TEXT,
            ],
            'New correction list failed' => [
                self::NEW_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_DIETRICH_VOLUME, StringTestItem::CONTAINS_BLURRY),
                self::NEW_CORRECTION_MENU_TEXT,
            ],
            // two test to check for headline and band number in one headline
            'Accepted correction list failed' => [
                self::ACCEPTED_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_HEADLINE, StringTestItem::CONTAINS_BLURRY),
                self::ACCEPTED_CORRECTION_MENU_TEXT,
            ],
            'Accepted correction list failed' => [
                self::ACCEPTED_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_DIETRICH_VOLUME, StringTestItem::CONTAINS_BLURRY),
                self::ACCEPTED_CORRECTION_MENU_TEXT,
            ],
            // two test to check for headline and band number in one headline
            'Unclear correction list failed' => [
                self::UNCLEAR_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_HEADLINE, StringTestItem::CONTAINS_BLURRY),
                self::UNCLEAR_CORRECTION_MENU_TEXT,
            ],
            'Unclear correction list failed' => [
                self::UNCLEAR_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_DIETRICH_VOLUME, StringTestItem::CONTAINS_BLURRY),
                self::UNCLEAR_CORRECTION_MENU_TEXT,
            ],
            // two test to check for headline and band number in one headline
            'Denied correction list failed' => [
                self::DENIED_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_HEADLINE, StringTestItem::CONTAINS_BLURRY),
                self::DENIED_CORRECTION_MENU_TEXT,
            ],
            'Denied correction list failed' => [
                self::DENIED_CORRECTION_URL,
                new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY),
                new StringTestItem(self::BLURRED_LINK_DIETRICH_VOLUME, StringTestItem::CONTAINS_BLURRY),
                self::DENIED_CORRECTION_MENU_TEXT,
            ],
        ];
    }

    /**
     * A functional test that at least checks if your application pages are successfully loading.
     *
     * @dataProvider dataProvider
     * @param string $url Contains the URL
     */
    public function testMainPagesAreAvailable_isSuccessful($url)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));
        $this->validateClientResponse($this->client);
    }


    /**
     * A functional test that checks if the website is available, the headlines are right and if the menu's are there
     *
     * @dataProvider dataProvider
     *
     * @param string|null $url URL given by the dataProvider
     * @param StringTestItem|null $moduleHeadline
     * @param StringTestItem|null $headline Headline given by the dataProvider
     * @param string|null $menu Menu Text given by the dataProvider
     */
    public function test_AllPageData_isSuccessful($url,
                                                  $moduleHeadline,
                                                  $headline,
                                                  $menu)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));

        if ($moduleHeadline !== null) {
            $this->assertTrue(
                HtmlContentUtils::isTopLevelMenuAvailable($this->client, $moduleHeadline),
                sprintf('Headline of <%s> could not be validated.', $url)
            );
        }

        if ($headline !== null) {
            $this->assertTrue(
                HtmlContentUtils::isHeadlineAvailable($this->client, $headline, 2),
                sprintf('Headline of <%s> could not be validated.', $url)
            );
        }

        if ($menu !== null)
        {
            $this->assertTrue(
                $this->isStatusMenuActive($this->client, $menu),
                sprintf('Menu of <%s> could not be validated.', $url)
            );
        }
    }

    /**
     * A functional test that checks if the button for a specific Band is available
     */
    public function test_Button_isSuccessful()
    {
        $this->assertTrue(
            $this->isBandButtonAvailable(self::OVERVIEW_URL, self::BAND),
            sprintf('Button of Band <%d> could not be validated.', self::BAND)
        );
    }

    /**
     * Returns <code>true</code> if the Button is loaded
     *
     * @param string $url The URL for count lookup
     * @param string $band The Number of the Button
     * @return bool Returns <code>true</code> if the expected button exist, otherwise if will fail with an assertion.
     */
    private function isBandButtonAvailable(string $url, string $band): bool
    {
        Preconditions::notEmpty($url, 'url');
        Preconditions::notEmpty($band, 'band');

        $classesForButton = 'ui button dietrich band staff';
        $linkToPage = sprintf('/korrekturvorschlagRedaktion/liste_band/%d/filter/neu', $band);

        $client = static::createClient();
        $client->followRedirects();
        $spc = $client->request('GET', $url);

        $this->assertNotNull($spc, 'Page-URL is wrong!');
        $searchResultContent = $client->getResponse()->getContent();

        $this->assertContains($classesForButton, $searchResultContent, 'Button was not found!');
        $this->assertContains($linkToPage, $searchResultContent, 'Linkage to the correct Band was not found!');

        return true;
    }


    /**
     * Validates that the given response is ok.
     * @param Client $client
     */
    private function validateClientResponse(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url = $client->getRequest()->getUri();

        $this->assertTrue(
            $response->isSuccessful(),
            sprintf(
                "Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        $this->assertTrue(
            $response->isOk(),
            sprintf(
                "Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        $this->assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf(
                "Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
    }

    /**
     * Validates that the given menu label ist available and set to active in the level two headline (<code>h2</code>).
     *
     * @param Client $client
     * @param string $menuLabel Text of the Menu that should be found. Can contain HTML if wanted
     * @return bool
     */
    private function isStatusMenuActive(Client $client, string $menuLabel): bool
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($menuLabel, 'HeadLineLabel');

        $htmlContent = $client->getResponse()->getContent();

        $searchString = '<a href="#" class="ui popupTrigger">' . $menuLabel . '<i class="dropdown icon"></i></a>';
        $checkForActiveString = '<a class="active item"';

        $startHeadline = strpos($htmlContent, '<h2>');
        $endHeadline = strpos($htmlContent, '</h2>');
        $completeHeadline = substr($htmlContent, $startHeadline, $endHeadline);

        $this->assertContains($checkForActiveString, $completeHeadline, 'Active menu entry was not found!');
        $this->assertContains($searchString, $completeHeadline, 'menu text was not found!');

        return true;
    }
}
