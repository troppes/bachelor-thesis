<?php

namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Entity\BandEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Entity\LiteraturreferenzbearbeitungsstatusEntity;
use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\DietrichliteraturreferenzRepository;
use AppBundle\Util\Preconditions;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Doctrine\ORM\TransactionRequiredException;
use DOMDocument;
use DOMXPath;
use Exception;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Controller\BaseWebTestCase;
use Tests\AppBundle\Util\HtmlContentUtils;
use Tests\AppBundle\Util\QueryObjectHelper;
use Tests\AppBundle\Util\StringTestItem;

class LiteraturreferenzAdminPageTest
    extends BaseWebTestCase
{
    const HTTP_OK = 200;

    const LITREF_ROOT = 'literaturreferenzadministration';

    const MODULE_HEADLINE = 'Literaturreferenz-Administration';
    const SITE_HEADLINE   = 'Literaturreferenz';

    const ARTICLE_LINK_STATUS = 'Der Band wurde noch nicht eingelesen.';

    const BAND    = '30';
    const BAND_ID = '37';

    const NORMLITREF_ID_WHERE_ZDB_NULL = '340';
    const NORMLITREF_ID_WHERE_KVK_NULL = '3';

    //Only use non spaced Sigles, since spaces break the URL
    const LITREF_A_SIGLE = '999TA';
    const LITREF_B_SIGLE = '999TB';
    const LITREF_C_SIGLE = '999TC';

    const LITREF_A_TERM = 'Test A';
    const LITREF_B_TERM = 'Test B';
    const LITREF_C_TERM = 'Test C';

    const LITREF_A_URL = self::LITREF_ROOT.'/literaturreferenz/band/'.self::BAND.'/sigle/'.self::LITREF_A_SIGLE.'?filter=all_paged';
    const LITREF_B_URL = self::LITREF_ROOT.'/literaturreferenz/band/'.self::BAND.'/sigle/'.self::LITREF_B_SIGLE.'?filter=all_paged';
    const LITREF_C_URL = self::LITREF_ROOT.'/literaturreferenz/band/'.self::BAND.'/sigle/'.self::LITREF_C_SIGLE.'?filter=all_paged';


    /**
     * Create Database Entries for Testing
     *
     * @throws NonUniqueResultException
     * @throws OptimisticLockException
     * @throws Exception
     */
    public function setup()
    {
        parent::setUp();


        /* @var EntityManager $em */
        $em = $this->container->get('doctrine')->getManager(FeatureBase::DB_BACKEND);

        $qb = $em->createQueryBuilder();

        $qb->select('litStatus');
        $qb->from(LiteraturreferenzbearbeitungsstatusEntity::class, 'litStatus');
        $qb->andWhere('litStatus.id = 2');

        $litStatus = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($litStatus, 'litStatus');

        $qb->select('band');
        $qb->from(BandEntity::class, 'band');
        $qb->andWhere('band.id = '.self::BAND_ID);

        $band = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($band, 'band');


        $qb->select('normLitRefKvkNull');
        $qb->from(NormliteraturreferenzEntity::class, 'normLitRefKvkNull');
        $qb->andWhere('normLitRefKvkNull.id ='.self::NORMLITREF_ID_WHERE_KVK_NULL);

        $normLitRefKvkNull = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($normLitRefKvkNull, 'normLitRefKvkNull');

        $qb->select('normLitRefZdbNull');
        $qb->from(NormliteraturreferenzEntity::class, 'normLitRefZdbNull');
        $qb->andWhere('normLitRefZdbNull.id ='.self::NORMLITREF_ID_WHERE_ZDB_NULL);

        $normLitRefZdbNull = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($normLitRefZdbNull, 'normLitRefZdbNull');

        $litRefA = QueryObjectHelper::createLitRefEntity(
            self::LITREF_A_SIGLE,
            self::LITREF_A_TERM,
            $litStatus,
            $band
        );
        $litRefA->setAllgemeinebemerkung('Test-'.self::class);

        $litRefB = QueryObjectHelper::createLitRefEntity(
            self::LITREF_B_SIGLE,
            self::LITREF_B_TERM,
            $litStatus,
            $band
        );
        $litRefB->setAllgemeinebemerkung('Test-'.self::class);

        $litRefC = QueryObjectHelper::createLitRefEntity(
            self::LITREF_C_SIGLE,
            self::LITREF_C_TERM,
            $litStatus,
            $band
        );
        $litRefC->setAllgemeinebemerkung('Test-'.self::class);

        $dietrichNormLitRefKvkNull = new DietrichlitrefNormlitrefEntity();
        $dietrichNormLitRefKvkNull->setNormliteraturreferenzEntity($normLitRefZdbNull);
        $dietrichNormLitRefKvkNull->setDietrichliteraturreferenzEntity($litRefA);

        $dietrichNormLitRefZdbNull = new DietrichlitrefNormlitrefEntity();
        $dietrichNormLitRefZdbNull->setNormliteraturreferenzEntity($normLitRefKvkNull);
        $dietrichNormLitRefZdbNull->setDietrichliteraturreferenzEntity($litRefC);

        $em->persist($litRefA);
        $em->persist($litRefB);
        $em->persist($litRefC);
        $em->persist($dietrichNormLitRefZdbNull);
        $em->persist($dietrichNormLitRefKvkNull);


        $em->flush();
        /*
         *  What happens without:
         *    After the persist the data is in the cache. Normally a find/findById get the actual data from the entity.
         *    In this case/version there are problems.
         *    So you have to use em->refresh($object) to load again.
         *
         *  Workaround:
         *    test fails because doctrine has problems
         *    generating a collection for litref->dietrichlitrefNormlitrefs.
         *    When the manager is closed and opened again doctrine works as expected.
         *
         *  Further details:
         *    - see: https://www.doctrine-project.org/projects/doctrine-orm/en/2.6/reference/limitations-and-known-issues.html#persist-keys-of-collections
         */
        $em->close();


        $this->assertEntity($litRefA);
        $this->assertEntity($litRefB);
        $this->assertEntity($litRefC);
    }


    /**
     * Test if Entry is correctly loaded
     *
     * @link https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/issues/373
     */
    public function test_sigleWithoutArtikel_successfullyLoaded()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));
        $this->validateClientResponse($this->client);
    }

    /**
     * Tests if Entry with no ZDB-Entry is correctly loaded
     *
     * @link https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/issues/373
     */
    public function test_sigleWithZdbEntry_successfullyLoaded()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_C_URL));
        $this->validateClientResponse($this->client);
    }

    /**
     * Tests if Entry with no KVK-Entry is correctly loaded
     *
     * @link https://ub-docu.uni-trier.de/dietrichonline/dietrichonline-web/issues/373
     */
    public function test_sigleWithKvkEntry_successfullyLoaded()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_A_URL));
        $this->validateClientResponse($this->client);
    }


    /**
     * Deletes the Database Entries
     *
     * @throws OptimisticLockException
     * @throws ORMException
     * @throws TransactionRequiredException
     */
    protected function tearDown()
    {
        parent::tearDown();

        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->getManager(FeatureBase::DB_BACKEND);


        /* @var $dietrichLitrefRepo DietrichliteraturreferenzRepository */
        $dietrichLitrefRepo = $em->getRepository(DietrichliteraturreferenzEntity::class);

        $dietrichLitrefA = $dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(self::BAND, self::LITREF_A_SIGLE);
        $dietrichLitrefB = $dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(self::BAND, self::LITREF_B_SIGLE);
        $dietrichLitrefC = $dietrichLitrefRepo->findDietrichliteraturreferenzByBandkuerzelAndSigle(self::BAND, self::LITREF_C_SIGLE);

        $qb = $em->createQueryBuilder();
        $qb->select('dietrichLitRefNormLitRefA');
        $qb->from(DietrichlitrefNormlitrefEntity::class, 'dietrichLitRefNormLitRefA');
        $qb->where('dietrichLitRefNormLitRefA.dietrichliteraturreferenzEntity = (:litRefA)');
        $qb->setParameter('litRefA', $dietrichLitrefA);
        $dietrichLitRefNormLitRefA = $qb->getQuery()->getOneOrNullResult();

        $qb = $em->createQueryBuilder();
        $qb->select('dietrichLitRefNormLitRefC');
        $qb->from(DietrichlitrefNormlitrefEntity::class, 'dietrichLitRefNormLitRefC');
        $qb->where('dietrichLitRefNormLitRefC.dietrichliteraturreferenzEntity = (:litRefC)');
        $qb->setParameter('litRefC', $dietrichLitrefC);
        $dietrichLitRefNormLitRefC = $qb->getQuery()->getOneOrNullResult();

        $em->remove($em->find(DietrichlitrefNormlitrefEntity::class, $dietrichLitRefNormLitRefA->getId()));
        $em->remove($em->find(DietrichlitrefNormlitrefEntity::class, $dietrichLitRefNormLitRefC->getId()));

        $em->remove($dietrichLitrefA);
        $em->remove($dietrichLitrefB);
        $em->remove($dietrichLitrefC);

        $em->flush();
    }

    /**
     * @param DietrichliteraturreferenzEntity $entity
     *
     * @throws Exception
     */
    private function assertEntity(DietrichliteraturreferenzEntity $entity)
    {
        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->getManager(FeatureBase::DB_FRONTEND);

        try {
            $tObject = $em->find(DietrichliteraturreferenzEntity::class, $entity->getId());
        } catch (Exception $e) {
            throw new Exception(
                'Could not get DietrichLitRef with id '.$entity->getId().' (Possible connection error)'
            );
        }

        self::assertNotNull($tObject, $entity->getSigle().' not found in database');
        self::assertNotNull($tObject->getSortableSigle(), $entity->getSigle().'->sortableSigle is null');
    }

    /**
     * @throws Exception
     */
    public function test_nextAndPrevLinksAreAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));

        self::assertTrue(
            $this->validateNextPrevAvailable($this->client),
            'Es gab einen Fehler bei dem Next/Prev Links!'
        );
    }


    public function test_areHeadlines_Available()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));

        self::assertTrue(
            HtmlContentUtils::isTopLevelMenuAvailable($this->client, new StringTestItem(self::MODULE_HEADLINE)),
            sprintf('Headline of the module could not be validated.')
        );
        self::assertTrue(
            HtmlContentUtils::isHeadlineAvailable($this->client, new StringTestItem(self::SITE_HEADLINE), 2),
            sprintf('Headline of the site could not be validated.')
        );
    }

    public function test_isMagazineButton_Available()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));
        self::assertTrue(
            $this->checkMagazineButton($this->client),
            sprintf('Edit Sigle of the module could not be validated.')
        );
    }

    public function test_isEditSigle_Available()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));
        self::assertTrue(
            $this->checkEditSigle($this->client),
            sprintf('Magazine Button of the module could not be validated.')
        );
    }

    public function test_isArticleLink_Available()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));
        self::assertTrue(
            $this->checkArticleLink($this->client),
            sprintf('Magazine Button of the module could not be validated.')
        );
    }

    public function test_istCorrectStatus_Available()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LITREF_B_URL));
        self::assertTrue(
            $this->checkStatus($this->client),
            sprintf('Status of the module could not be validated.')
        );
    }


    /**
     * Checks if the next and previous elements are there, by checking if a node with the right url is found
     *
     * @param Client $client
     *
     * @return bool
     */
    private function validateNextPrevAvailable($client): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath = new DOMXpath($doc);

        $matchesA = $xpath->query("//a[contains(@href,'/".self::LITREF_A_URL."')][contains(@class, 'sigle-prev')]/..");
        $matchesC = $xpath->query("//a[contains(@href,'/".self::LITREF_C_URL."')][contains(@class, 'sigle-next')]/..");

        self::assertNotNull($matchesA[0], 'No previous node found.');
        self::assertEquals(1, count($matchesA), 'Previous node is not unique.');
        self::assertNotNull($matchesC[0], 'No next node found.');
        self::assertEquals(1, count($matchesC), 'Next node is not unique.');

        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim(self::LITREF_A_SIGLE, "\ \t\n\r\0\x0B"),
            trim($matchesA[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'Prev-Node text does not match!'
        );

        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim(self::LITREF_C_SIGLE, "\ \t\n\r\0\x0B"),
            trim($matchesC[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'Next-Node text does not match!'
        );

        return true;
    }

    /**
     * Validates if the Magazine Button is there
     *
     * @param Client $client
     *
     * @return bool
     */
    private function checkMagazineButton(Client $client): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//i[contains(@class,'magazine')]/../..");

        self::assertNotNull($matches[0], 'No magazine button was found.');
        self::assertEquals(1, count($matches), 'More than one magazine button was found.');

        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim(self::LITREF_B_TERM, "\ \t\n\r\0\x0B"),
            trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'The magazine button has the wrong value.'
        );

        return true;
    }

    /**
     * Validates if the Button to edit the sigle
     *
     * @param Client $client
     *
     * @return bool
     */
    private function checkEditSigle(Client $client): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//i[contains(@class,'change_sigle')]");

        //Cant match Text since the popup fills the element with more text
        self::assertNotNull($matches[0], 'No edit button was found.');
        self::assertEquals(1, count($matches), 'More than one edit button was found.');

        return true;
    }

    /**
     * Validates if the Article link Status is there
     *
     * @param Client $client
     *
     * @return bool
     */
    private function checkArticleLink(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//div[contains(@class,'article_link_status')]");

        self::assertNotNull($matches[0], 'No article link button was found.');
        self::assertEquals(1, count($matches), 'More than one article link button was found.');

        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim(self::ARTICLE_LINK_STATUS, "\ \t\n\r\0\x0B"),
            trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'The article link button has the wrong value.'
        );

        return true;
    }

    /**
     * Validates if the status option menu is there
     *
     * @param Client $client
     *
     * @return bool
     */
    private function checkStatus(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query(
            "//option[@value=".DietrichliteraturreferenzRepository::BEARBEITUNGSSTATUS_KLAR."]
            [@selected='selected']"
        );

        self::assertNotNull($matches[0], 'No status option menu was found.');
        self::assertEquals(1, count($matches), 'More than one status option menu was found.');

        return true;
    }

    /**
     * Validates that the given response is ok.
     *
     * @param Client $client
     */
    private function validateClientResponse(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url      = $client->getRequest()->getUri();

        self::assertTrue(
            $response->isSuccessful(),
            sprintf(
                "Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertTrue(
            $response->isOk(),
            sprintf(
                "Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf(
                "Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
    }

}
