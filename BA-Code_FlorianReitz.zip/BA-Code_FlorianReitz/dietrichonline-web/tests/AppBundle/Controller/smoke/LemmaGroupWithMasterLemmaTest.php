<?php

namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Controller\LemmaAdministration\LemmaGroupController;
use Symfony\Component\DomCrawler\Crawler;
use Tests\AppBundle\Controller\BaseWebTestCase;

class LemmaGroupWithMasterLemmaTest
    extends BaseWebTestCase
{
    const LEMMA_IDS       = [770, 44392, 62991, 77819];
    const MASTER_LEMMA_ID = 770;

    /**
     * @var Crawler
     */
    private $radioButtonCrawler;

    public function setUp()
    {
        parent::setUp();

        $url = $this->getRouter()->generate(
            LemmaGroupController::GROUP_LEMMAS_ROUTE,
            [
                LemmaGroupController::LEMMA_IDS_KEY => implode(',', self::LEMMA_IDS),
                LemmaGroupController::MASTER_LEMMA_ID_KEY => self::MASTER_LEMMA_ID
            ]
        );
        $this->client->request('GET', $url);

        $this->radioButtonCrawler = $this->client
            ->getCrawler()
            ->filterXPath('//input[@type="radio"]');
    }

    /**
     * Tests that the application pages is successfully loading.
     */
    public function test_responseStatusCode_valid()
    {
        $this->assertTrue($this->client->getResponse()->isOk(), 'site unreachable!');
    }

    public function test_NumberOfRadioButtons_valid()
    {
        self::assertEquals(count(self::LEMMA_IDS), $this->radioButtonCrawler->count());
    }

    public function test_radioBtnValues_valid()
    {
        $values = $this->radioButtonCrawler->extract(['value']);
        foreach (self::LEMMA_IDS as $lemmaId) {
            self::assertContains($lemmaId, $values);
        }
    }

    public function test_masterLemmaSelection_valid()
    {
        $extractedMasterLemmaId = $this->radioButtonCrawler
            ->filterXPath('input[@checked]')
            ->extract(['value']);
        self::assertCount(1, $extractedMasterLemmaId);
        self::assertEquals(self::MASTER_LEMMA_ID, $extractedMasterLemmaId[0]);
    }

    public function test_hiddenLemmaInput_valid()
    {
        $values = $this->client->getCrawler()
            ->filterXPath('//input[@type="hidden" and starts-with(@name, "lemma_ids")]')
            ->extract(['value']);
        self::assertCount(count(self::LEMMA_IDS), $values);
        foreach (self::LEMMA_IDS as $lemmaId) {
            self::assertContains($lemmaId, $values);
        }
    }
}
