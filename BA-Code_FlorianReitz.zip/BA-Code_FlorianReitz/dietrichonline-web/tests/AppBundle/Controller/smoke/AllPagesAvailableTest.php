<?php


namespace Tests\AppBundle\Controller;


use AppBundle\Util\Preconditions;
use Symfony\Bundle\FrameworkBundle\Client;

/**
 * Description of AllPagesAvailableTest
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class AllPagesAvailableTest extends BaseWebTestCase
{
    const HTTP_OK = 200;

    const FAVICON_HTML = '<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">';

    public function setUp()
    {
        parent::setUp();
    }

    /**
     * A functional test that at least checks if your application pages are successfully loading.
     *
     * @dataProvider urlProvider
     */
    public function testMainPagesAreAvailable_isSuccessful($url)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));
        $this->validateClientResponse($this->client);
    }

    /**
     * Tests that some basic search URLs give a 200 response.
     *
     * @dataProvider extSearchUrls
     */
    public function testExtendedSearchUrlsAreAvailable_isSuccessful($url)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));
        $this->validateClientResponse($this->client);
    }

    /**
     * A functional test that checks if the Favicon is loaded
     *
     * @param string $url The URL for testing
     *
     * @dataProvider urlProvider
     */
    public function testMainPagesFaviconIsAvailable_isSuccessful($url)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));
        $this->validateFavicon($this->client);
    }




    /**
     * Returns a DataProvider with the supported application URLs.
     *
     * @return \Generator
     */
    public function urlProvider()
    {
        yield [''];
        yield ['/'];
        yield ['suche'];
        yield ['dietrichbaende'];
        yield ['hilfe'];
        yield ['kontakt'];
        yield ['bookmarks'];
    }

    /**
     * Returns a DataProvider with some basic search URLs.
     * <p>
     * It's a collection of some rough URL tests only and an own class will follow.
     *
     * @return \Generator
     */
    public function extSearchUrls()
    {
        // one word 'test'
        yield ['suche?simpleUserSearch%5Bbegriff%5D=test'];
        // empty search (full extended)
        yield ['suche?user_search%5Bk1%5D=1&user_search%5Bb1%5D=&user_search%5Bj1%5D=2&user_search%5Bk2%5D=1&user_search%5Bb2%5D=&user_search%5Bj2%5D=2&user_search%5Bk3%5D=1&user_search%5Bb3%5D=&user_search%5Bj3%5D=2&user_search%5Bk4%5D=1&user_search%5Bb4%5D=&user_search%5Bj4%5D=2&user_search%5Bk5%5D=1&user_search%5Bb5%5D=&user_search%5Bj5%5D=2&user_search%5Bk6%5D=1&user_search%5Bb6%5D=&user_search%5Bj6%5D=2&user_search%5Bk7%5D=1&user_search%5Bb7%5D=&user_search%5Bj7%5D=2&user_search%5Bk8%5D=1&user_search%5Bb8%5D=&user_search%5Bj8%5D=2&user_search%5Bk9%5D=1&user_search%5Bb9%5D=&user_search%5Bj9%5D=2&user_search%5Bk10%5D=1&user_search%5Bb10%5D=&user_search%5Bj10%5D=2&user_search%5Bk11%5D=1&user_search%5Bb11%5D=&user_search%5BvonJahr%5D=&user_search%5BbisJahr%5D'];
        // first URL parameter set only
        yield ['suche?user_search[k1]=1&user_search[b1]=test&user_search[j1]=2'];
        // second URL parameter set only
        yield ['suche?user_search[k1]=1&user_search[b1]=&user_search[j1]=2&user_search[k2]=1&user_search[b2]=test&user_search[j2]=2'];
        // years URL parameters set only
        yield ['suche?user_search[k1]=1&user_search[b1]=&user_search[j1]=2&user_search[vonJahr]=1898&user_search[bisJahr]=1944'];
    }

    /**
     * Validates that the given response is ok.
     * <p>
     * Ok means:
     * <ul>
     * <li>was successful,
     * <li>was ok,
     * <li>equals 200.
     * </ul>
     *
     * @param Client $client
     */
    private function validateClientResponse($client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url = $client->getRequest()->getUri();

        // only to start debuging
        // $this->dump_more_informations($client);

        $this->assertTrue(
            $response->isSuccessful(),
            sprintf("Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()));
        $this->assertTrue(
            $response->isOk(),
            sprintf("Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()));
        $this->assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf("Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()));
    }

    private function validateFavicon($client)
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $this->client->getResponse()->getContent();

        $this->assertContains(self::FAVICON_HTML, $htmlContent, 'Favicon Link was not found!');

        return true;
    }

    /**
     * Call to get more debug informations when an assertion failed.
     *
     * @param Client $client
     */
    private function dump_more_informations($client)
    {
        $response = $client->getResponse();
        if (!$response->isSuccessful())
        {
            $crawler = $client->getCrawler();
            $css_selection = $crawler->filter('title');
            var_dump($css_selection);
        }
    }
}
