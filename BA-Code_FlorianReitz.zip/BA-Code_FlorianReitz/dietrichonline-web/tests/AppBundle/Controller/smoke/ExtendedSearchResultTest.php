<?php

namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Entity\ArtikelEntity;
use AppBundle\Entity\ArtikelUrlEntity;
use AppBundle\Entity\BandEntity;
use AppBundle\Entity\BandUrlEntity;
use AppBundle\Entity\DietrichliteraturreferenzEntity;
use AppBundle\Entity\DietrichlitrefNormlitrefEntity;
use AppBundle\Entity\GndEntity;
use AppBundle\Entity\LemmabearbeitungsstatusEntity;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Entity\LemmaGndEntity;
use AppBundle\Entity\LiteraturreferenzbearbeitungsstatusEntity;
use AppBundle\Entity\LiteraturtypEntity;
use AppBundle\Entity\NormliteraturreferenzEntity;
use AppBundle\Entity\WerkUrlEntity;
use AppBundle\Feature\FeatureBase;

use AppBundle\Util\Preconditions;
use Doctrine\ORM\EntityManager;
use Doctrine\ORM\NonUniqueResultException;
use Doctrine\ORM\OptimisticLockException;
use Doctrine\ORM\ORMException;
use Doctrine\ORM\TransactionRequiredException;
use DOMDocument;
use DOMXPath;
use Exception;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Controller\BaseWebTestCase;
use Tests\AppBundle\Util\QueryObjectHelper;

class ExtendedSearchResultTest
    extends BaseWebTestCase
{

    const BAND    = '30';
    const BAND_ID = '37';

    const GND_ID          = '31';
    const GND_NAME        = 'Toilette';
    const GND_LINK        = '/suche?user_search[k1]=2&user_search[b1]="'.self::GND_NAME.'"';
    const GND_BUTTON_TEXT = self::GND_NAME.' (GND)';

    const SIGLE = 'Sigle';

    const ID     = 999999999;
    const AUTHOR = 'Mc Write';
    const TITLE  = 'This is an Article with a Title';
    const PAGE   = 12;

    const LITREF_SIGLE = 'LitSigle';
    const LITREF_BEZ   = 'Bezeichnung';

    const KVK_BEZ     = 'TestForTestCase';
    const FIRST_ENTRY = '1.';

    const SEARCH_URL = 'suche?user_search%5Bk1%5D=13&user_search%5Bb1%5D='.self::ID;

    const SOURCE_URL          = 'https://uni-trier.rocks/very-hard/';
    const DOMAIN_NAME         = 'uni-trier.rocks';
    const TO_ARTICLE          = 'zum Artikel';
    const CORRECT_BUTTON_TEXT = 'Korrektur';

    private $lemma;
    private $article;
    private $lemmaGND;

    private $litRef;
    private $normLitRef;
    private $dLitRefNormLitRef;

    private $articleUrl;
    private $bandUrl;
    private $werkUrl;


    /**
     * Create Database Entries for Testing
     *
     * @throws NonUniqueResultException
     * @throws OptimisticLockException
     */
    public function setup()
    {
        parent::setUp();

        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->getManager(FeatureBase::DB_BACKEND);
        $qb = $em->createQueryBuilder();

        //Get Band
        $qb->select('band');
        $qb->from(BandEntity::class, 'band');
        $qb->andWhere('band.id = (:bandId)');
        $qb->setParameter('bandId', self::BAND_ID);
        $band = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($band, 'band');

        // Get Bearbeitungsstatus
        $qb->select('bStatus');
        $qb->from(LemmabearbeitungsstatusEntity::class, 'bStatus');
        $qb->andWhere('bStatus.id = 1');
        $bStatus = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($bStatus, 'bStatus');

        // Get LitRef Bearbeitungsstatus
        $qb->select('litStatus');
        $qb->from(LiteraturreferenzbearbeitungsstatusEntity::class, 'litStatus');
        $qb->andWhere('litStatus.id = 2');
        $litStatus = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($litStatus, 'litStatus');

        //Get Literature Type
        $qb->select('litType');
        $qb->from(LiteraturtypEntity::class, 'litType');
        $qb->andWhere('litType.id = 2');
        $litType = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($litType, 'litType');

        //Get GND Entry
        $qb->select('gnd');
        $qb->from(GndEntity::class, 'gnd');
        $qb->andWhere('gnd.id = '.self::GND_ID);
        $gnd = $qb->getQuery()->getOneOrNullResult();
        Preconditions::notNull($gnd, 'gnd');

        //Create Lemma
        $this->lemma = QueryObjectHelper::createLemmaEntity(self::SIGLE, 1, 0, $bStatus);

        //Create GND Entry
        $this->lemmaGND = QueryObjectHelper::createLemmaGndEntity($this->lemma, $gnd);

        //Create LitRef
        $this->litRef = QueryObjectHelper::createLitRefEntity(self::LITREF_SIGLE, self::LITREF_BEZ, $litStatus, $band);

        //Create NormLitRef
        $this->normLitRef = QueryObjectHelper::createNormLitRefEntity($litType, 0, self::KVK_BEZ);

        //Create LitRef-NormLitRef
        $this->dLitRefNormLitRef = QueryObjectHelper::createDietrichlitrefNormlitrefEntity(
            $this->litRef,
            $this->normLitRef
        );

        //Create Artikel
        $this->article = QueryObjectHelper::createArticleEntity(self::ID, $this->lemma, $band, self::TITLE);
        $this->article->setAutor(self::AUTHOR);
        $this->article->setPhysikalischeSeite(self::PAGE);
        $this->article->setBibliographieseite(self::PAGE);
        $this->article->setBibliographiespalte('l');
        $this->article->setBibliographiezeile(self::PAGE);
        $this->article->setDietrichliteraturreferenzEntity($this->litRef);

        // Push all Objects to the Database.
        $em->persist($this->article);
        $em->persist($this->lemma);
        $em->persist($this->lemmaGND);
        $em->persist($this->litRef);
        $em->persist($this->normLitRef);
        $em->persist($this->dLitRefNormLitRef);

        $em->flush();
    }

    /**
     * Deletes the Database Entries
     *
     * @throws OptimisticLockException
     * @throws ORMException
     * @throws TransactionRequiredException
     */
    protected function tearDown()
    {
        parent::tearDown();

        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->resetManager(FeatureBase::DB_BACKEND);

        //These objects are only set in one method, so they should be only removed if set
        if ($this->werkUrl !== null) {
            //The no inspection is needed since PHP doesn't know the definitive type for WerkUrl. It could be null
            /** @noinspection PhpUndefinedMethodInspection */
            $em->remove($em->find(WerkUrlEntity::class, $this->werkUrl->getId()));
        }

        if ($this->bandUrl !== null) {
            /** @noinspection PhpUndefinedMethodInspection */
            $em->remove($em->find(BandUrlEntity::class, $this->bandUrl->getId()));
        }

        if ($this->articleUrl !== null) {
            /** @noinspection PhpUndefinedMethodInspection */
            $em->remove($em->find(ArtikelUrlEntity::class, $this->articleUrl->getId()));
        }

        // Cleanup after every test case
        $em->remove($em->find(ArtikelEntity::class, $this->article->getId()));
        $em->remove($em->find(LemmaGndEntity::class, $this->lemmaGND->getId()));
        $em->remove($em->find(LemmaEntity::class, $this->lemma->getId()));
        $em->remove($em->find(DietrichlitrefNormlitrefEntity::class, $this->dLitRefNormLitRef->getId()));
        $em->remove($em->find(DietrichliteraturreferenzEntity::class, $this->litRef->getId()));
        $em->remove($em->find(NormliteraturreferenzEntity::class, $this->normLitRef->getId()));

        $em->flush();
    }

    public function test_idCorrect_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//small[contains(@class,'monospace')]", 'ID: '.self::ID),
            'The ID could not be verified!'
        );
    }

    public function test_resultNumberCorrect_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//div[contains(@class,'articleCount')]", self::FIRST_ENTRY),
            'The result number could not be verified!'
        );
    }

    public function test_authorCorrect_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//span[contains(@class,'author')]", self::AUTHOR),
            'The result number could not be verified!'
        );
    }

    public function test_correctionButtonIsAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual(
                $this->client,
                "//a[contains(@class,'correction_button')][1]",
                self::CORRECT_BUTTON_TEXT
            ),
            'The correction button could not be verified!'
        );
    }

    public function test_bandButtonIsAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual(
                $this->client,
                "//a[contains(@class,'dietrich_green')][1]",
                'Band '.self::BAND
            ),
            'The band button could not be verified!'
        );
    }

    public function test_bookmarkButtonIsAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//i[contains(@class,'bookmark')][1]", ''),
            'The bookmark button could not be verified!'
        );
    }

    public function test_gndSearchIsAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual(
                $this->client,
                "//a[contains(@class,'gnd_button')][1]",
                self::GND_BUTTON_TEXT
            ),
            'The GND button could not be verified!'
        );
        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'gnd_button')]/@href", self::GND_LINK),
            'The GND button link could not be verified!'
        );
    }

    /**
     * Adds a WerkURL to check if button exists.
     *
     * @throws ORMException
     * @throws OptimisticLockException
     * @throws TransactionRequiredException
     */
    public function test_werkLinkButtonIsAvailable_isSuccessful()
    {
        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->resetManager(FeatureBase::DB_BACKEND);

        // Add Werk Url
        $this->werkUrl = QueryObjectHelper::createWerkUrlEntity(
            self::SOURCE_URL,
            $em->find(
                NormliteraturreferenzEntity::class,
                $this->normLitRef->getId()
            )
        );
        $em->persist($this->werkUrl);
        $em->flush();

        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'werk_button')][1]", self::DOMAIN_NAME),
            'The WerkUrl button could not be verified!'
        );
        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'werk_button')]/@href", self::SOURCE_URL),
            'The WerkUrl button link could not be verified!'
        );

        //Check for BandUrl Button
        self::assertFalse(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'band_button')][1]", self::SOURCE_URL),
            'The BandUrl button was found!'
        );
        //Check for Article Button
        self::assertFalse(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'artikel_button')][1]", 'zum Artikel'),
            'The ArticleUrl Button was found!'
        );
    }

    /**
     * Adds a WerkURL + BandURL to test which button appears
     *
     * @throws ORMException
     * @throws OptimisticLockException
     * @throws TransactionRequiredException
     */
    public function test_bandLinkButtonIsAvailable_isSuccessful()
    {
        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->resetManager(FeatureBase::DB_BACKEND);

        // Add Werk Url
        $this->werkUrl = QueryObjectHelper::createWerkUrlEntity(
            self::SOURCE_URL,
            $em->find(
                NormliteraturreferenzEntity::class,
                $this->normLitRef->getId()
            )
        );
        $em->persist($this->werkUrl);
        $em->flush();
        //Add BandUrl
        $this->bandUrl = QueryObjectHelper::createBandUrlEntity(
            self::SOURCE_URL,
            $em->find(
                DietrichlitrefNormlitrefEntity::class,
                $this->dLitRefNormLitRef->getId()
            )
        );
        $em->persist($this->bandUrl);
        $em->flush();

        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'band_button')][1]", self::SOURCE_URL),
            'The BandUrl button could not be verified!'
        );
        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'band_button')]/@href", self::SOURCE_URL),
            'The BandUrl button link could not be verified!'
        );

        //Check for Werk Button
        self::assertFalse(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'werk_button')][1]", self::DOMAIN_NAME),
            'The WerkUrl button was found!'
        );
        //Check for Article Button
        self::assertFalse(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'artikel_button')][1]", self::TO_ARTICLE),
            'The ArticleUrl Button was found!'
        );
    }

    /**
     * Adds a WerkURL + BandURL + ArticleURL to test which button appears
     *
     * @throws ORMException
     * @throws OptimisticLockException
     * @throws TransactionRequiredException
     */
    public function test_articleLinkButtonIsAvailable_isSuccessful()
    {
        /** @var EntityManager $em */
        $em = $this->container->get('doctrine')->resetManager(FeatureBase::DB_BACKEND);

        // Add Werk Url
        $this->werkUrl = QueryObjectHelper::createWerkUrlEntity(
            self::SOURCE_URL,
            $em->find(
                NormliteraturreferenzEntity::class,
                $this->normLitRef->getId()
            )
        );
        $em->persist($this->werkUrl);
        $em->flush();
        //Add BandUrl
        $this->bandUrl = QueryObjectHelper::createBandUrlEntity(
            self::SOURCE_URL,
            $em->find(
                DietrichlitrefNormlitrefEntity::class,
                $this->dLitRefNormLitRef->getId()
            )
        );
        $em->persist($this->bandUrl);
        $em->flush();
        //Add Article URL
        $this->articleUrl = QueryObjectHelper::createArticleUrlEntity(
            self::SOURCE_URL,
            $em->find(
                ArtikelEntity::class,
                $this->article->getId()
            )
        );
        $em->persist($this->articleUrl);
        $em->flush();

        $this->client->request('GET', $this->getTestHostUrl(self::SEARCH_URL));

        self::assertTrue(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'artikel_button')][1]", self::TO_ARTICLE),
            'The ArtikelUrl button could not be verified!'
        );
        self::assertTrue(
            $this->validateStringIsEqual(
                $this->client,
                "//a[contains(@class,'artikel_button')]/@href",
                self::SOURCE_URL
            ),
            'The ArtikelUrl button link could not be verified!'
        );

        //Check for Werk Button
        self::assertFalse(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'werk_button')][1]", self::DOMAIN_NAME),
            'The WerkUrl button was found!'
        );
        //Check for BandUrl Button
        self::assertFalse(
            $this->validateStringIsEqual($this->client, "//a[contains(@class,'band_button')][1]", self::SOURCE_URL),
            'The BandUrl button was found!'
        );
    }

    /**
     * Checks if the given String matches the element
     *
     * @param Client $client
     * @param String $xpathQuery
     * @param String $inputToMatch
     *
     * @return bool
     */
    private function validateStringIsEqual(Client $client, string $xpathQuery, string $inputToMatch): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath = new DOMXpath($doc);

        $matches = $xpath->query($xpathQuery);

        try {
            self::assertNotNull($matches[0], 'No Match found.');

            //Trim because Element could have Spaces etc.
            self::assertSame(
                trim($inputToMatch, "\ \t\n\r\0\x0B"),
                trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
                'The found element does not match the given string!'
            );
        } catch (Exception $e) {
            return false;
        }

        return true;
    }
}
