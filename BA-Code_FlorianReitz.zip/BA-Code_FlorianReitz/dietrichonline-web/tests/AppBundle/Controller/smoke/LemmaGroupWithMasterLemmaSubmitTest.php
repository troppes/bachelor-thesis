<?php

namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Controller\LemmaAdministration\LemmaGroupController;
use AppBundle\Entity\ArtikelEntity;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\LemmaRepository;
use Doctrine\ORM\EntityManager;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Tests\AppBundle\Controller\BaseWebTestCase;

class LemmaGroupWithMasterLemmaSubmitTest
    extends BaseWebTestCase
{
    const LEMMA_IDS       = ['770', '44392', '62991', '77819'];
    const MASTER_LEMMA_ID = '770';

    /**
     * @var EntityManager
     */
    private $doctrineManager;

    /**
     * @var LemmaRepository
     */
    private $lemmaRepo;

    /**
     * @var Router
     */
    private $router;

    public function setUp()
    {
        parent::setUp();

        $this->router = $this->container->get('router');
        $this->doctrineManager = $this->container->get('doctrine')->getManager(FeatureBase::DB_BACKEND);
        $this->lemmaRepo = $this->doctrineManager->getRepository(LemmaEntity::class);

        // assert master lemma unset
        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            self::assertNull($lemma->getMasterLemma(), "setup failed: master lemma of $lemmaId must be null");
        }

        // make group request with master lemma
        $url = $this->router->generate(LemmaGroupController::MASTER_LEMMA_SUBMIT_ROUTE);
        $params = [];
        foreach (self::LEMMA_IDS as $lemmaId) {
            $params[LemmaGroupController::LEMMA_IDS_KEY][] = $lemmaId;
        }
        $params[LemmaGroupController::MASTER_LEMMA_ID_KEY] = self::MASTER_LEMMA_ID;
        $this->client->request('POST', $url, $params);
    }

    public function tearDown()
    {
        parent::tearDown();

        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            $lemma->setMasterLemma(null);
        }
        $this->doctrineManager->flush();
    }

    public function test_responseStatusCode_valid()
    {
        $response = $this->client->getResponse();
        $this->assertTrue($response->isSuccessful() || $response->isRedirect());
    }

    public function test_MasterLemmaStructure_valid()
    {
        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            self::assertNotNull($lemma, "cannot find lemma with id $lemmaId");
            self::assertNotNull($lemma->getMasterLemma(), "master lemma of lemma $lemmaId must not be null.");
            self::assertEquals(self::MASTER_LEMMA_ID, $lemma->getMasterLemma()->getId());
        }
    }

    public function test_triggerFilledArtikelTitelMitLemmaFormenRow_hasAllLemmaFormen()
    {
        $lemmas = [];
        foreach (self::LEMMA_IDS as $lemmaId) {
            $lemma = $this->lemmaRepo->find($lemmaId);
            self::assertNotNull($lemma, "Lemma with id $lemmaId cannot be found.");
            $lemmas[] = $lemma;
        }

        /** @var LemmaEntity $lemma */
        foreach ($lemmas as $lemma) {
            /** @var ArtikelEntity $artikelEntity */
            foreach ($lemma->getArtikelEntities() as $artikelEntity) {
                /** @var LemmaEntity $checkLemma */
                foreach ($lemmas as $checkLemma) {
                    $checkLemmaFound = strpos($artikelEntity->getTitelMitLemmaFormen(), $checkLemma->getBezeichnung())
                        !== false;
                    self::assertTrue(
                        $checkLemmaFound,
                        'Cannot find "'.$checkLemma->getBezeichnung().' lemma_id: '.$checkLemma->getId()
                        .'" in "'.$artikelEntity->getTitelMitLemmaFormen().'" artikel_id: '.$artikelEntity->getId()
                    );
                }
            }
        }
    }
}
