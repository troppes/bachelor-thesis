<?php


namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Repository\LemmaRepository;
use AppBundle\Util\Preconditions;
use DOMDocument;
use DOMXPath;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Controller\BaseWebTestCase;
use Tests\AppBundle\Util\HtmlContentUtils;
use Tests\AppBundle\Util\StringTestItem;

class LemmaAdministrationTest
    extends BaseWebTestCase
{
    const HTTP_OK = 200;
    const BAND    = 2;

    const LEMMA_ROOT = 'lemma_administration';

    const LEMMA_MAIN_URL      = self::LEMMA_ROOT;
    const LEMMA_MAIN_LONG_URL = self::LEMMA_ROOT.'/lemmauebersicht';
    const LEMMA_MAIN_LIST_URL = self::LEMMA_ROOT.'/lemmauebersicht/lemmaliste';

    const LEMMA_LIST_A_ALL_URL     = self::LEMMA_ROOT.'/lemma_liste/A/filter/alle';
    const LEMMA_LIST_A_CLEAR_URL   = self::LEMMA_ROOT.'/lemma_liste/A/filter/klar';
    const LEMMA_LIST_A_UNCLEAR_URL = self::LEMMA_ROOT.'/lemma_liste/A/filter/unklar';
    const LEMMA_LIST_A_NEW_URL     = self::LEMMA_ROOT.'/lemma_liste/A/filter/neu';

    const LEMMA_LIST_ATOZ_ALL_URL    = self::LEMMA_ROOT.'/lemma_liste/not_a-z/filter/alle';
    const LEMMA_LIST_DELETED_ALL_URL = self::LEMMA_ROOT.'/lemma_liste/geloeschte/filter/alle';

    const LEMMA_ENTRY_URL               = self::LEMMA_ROOT.'/lemma/128559';
    const LEMMA_ENTRY_URL_FILTER_KLAR   = self::LEMMA_ENTRY_URL.'/'.LemmaRepository::STATUS_FILTER_KLAR;
    const LEMMA_ENTRY_URL_FILTER_UNKLAR = self::LEMMA_ENTRY_URL.'/'.LemmaRepository::STATUS_FILTER_UNKLAR;
    const LEMMA_ENTRY_URL_FILTER_NEU    = self::LEMMA_ENTRY_URL.'/'.LemmaRepository::STATUS_FILTER_NEU;
    const LEMMA_ENTRY_URL_FILTER_NO_DDC = self::LEMMA_ENTRY_URL.'/'.LemmaRepository::STATUS_FILTER_NO_DDC;

    const LEMMA_GENERAL_HEADLINE = 'Lemma-Administration';
    const LEMMA_LIST_HEADLINE    = 'Liste aller Lemmata';


    public function setUp()
    {
        parent::setUp();
    }

    /**
     * Returns a DataProvider with the supported application URLs.
     *
     * @return array
     */
    public function dataProvider()
    {
        return [
            'Short Link Lemma Administration failed' => [
                self::LEMMA_MAIN_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                null,
                null,
            ],
            'Long Link Lemma Administration failed' => [
                self::LEMMA_MAIN_LONG_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                null,
                null,
            ],
            'List Link Lemma Administration failed' => [
                self::LEMMA_MAIN_LIST_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                null,
                null,
            ],
            'Letter A ALL Administration List failed' => [
                self::LEMMA_LIST_A_ALL_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                'A',
                'alle',
            ],
            'Letter A CLEAR Administration List failed' => [
                self::LEMMA_LIST_A_CLEAR_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                'A',
                'klar',
            ],
            'Letter A UNCLEAR Administration List failed' => [
                self::LEMMA_LIST_A_UNCLEAR_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                'A',
                'unklar',
            ],
            'Letter A NEW Administration List failed' => [
                self::LEMMA_LIST_A_NEW_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                'A',
                'neu',
            ],
            'Letter A-Z ALL Administration List failed' => [
                self::LEMMA_LIST_ATOZ_ALL_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                'sonstige',
                'alle',
            ],
            'DELETED ALL Administration List failed' => [
                self::LEMMA_LIST_DELETED_ALL_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                new StringTestItem(self::LEMMA_LIST_HEADLINE),
                'gelöschte',
                'alle',
            ],
            'SINGLE ENTRY Administration failed' => [
                self::LEMMA_ENTRY_URL,
                new StringTestItem(self::LEMMA_GENERAL_HEADLINE),
                null,
                null,
                null,
            ],
        ];
    }

    /**
     * A functional test that at least checks if your application pages are successfully loading.
     *
     * @param string $url Contains the URL
     *
     * @dataProvider dataProvider
     */
    public function testMainPagesAreAvailable_isSuccessful($url)
    {
        $this->client->request('GET', $this->getTestHostUrl($url));
        $this->validateClientResponse($this->client);
    }


    /**
     * A functional test that checks if the website is available, the headlines are right and if the menu's are there
     *
     * @param string|null $url URL given by the dataProvider
     * @param StringTestItem|null $generalHeadline Headline given by the dataProvider
     * @param StringTestItem|null $listHeadline Headline given by the dataProvider
     * @param string|null $labelChar Label from the selected Char given by the dataProvider
     * @param string|null $labelFilter Label from the selected Filter given by the dataProvider
     *
     * @dataProvider dataProvider
     */
    public function test_AllPageData_isSuccessful(
        $url,
        $generalHeadline,
        $listHeadline,
        $labelChar,
        $labelFilter
    )
    {
        $this->client->request('GET', $this->getTestHostUrl($url));


        if ($generalHeadline !== null) {
            self::assertTrue(
                HtmlContentUtils::isTopLevelMenuAvailable($this->client, $generalHeadline),
                sprintf('Headline of <%s> could not be validated.', $url)
            );
        }

        if ($listHeadline !== null) {
            self::assertTrue(
                HtmlContentUtils::isHeadlineAvailable($this->client, $listHeadline, 2),
                sprintf('Headline of <%s> could not be validated.', $url)
            );
        }

        if ($labelChar !== null) {
            self::assertTrue(
                $this->isButtonAvailable($this->client, $labelChar, 'list-chars'),
                sprintf('Menu of <%s> could not be validated.', $url)
            );
        }

        if ($labelFilter !== null) {
            self::assertTrue(
                $this->isButtonAvailable($this->client, $labelFilter, 'list-filter'),
                sprintf('Menu of <%s> could not be validated.', $url)
            );
        }
    }

    /**
     * A functional test that checks if the the given Entry has the status "klar"
     */
    public function test_SingeEntryStatus_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LEMMA_ENTRY_URL));
        self::assertTrue($this->isStatusAvailableSingeEntry($this->client, "klar"));
    }

    /**
     * A functional test that at least checks if single lemma entries with status "klar" are successfully loading.
     */
    public function test_singleEntryFilterKlar_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LEMMA_ENTRY_URL_FILTER_KLAR));
        $this->validateClientResponse($this->client);
    }

    /**
     * A functional test that at least checks if single lemma entries with status "unklar" are successfully loading.
     */
    public function test_singleEntryFilterUnklar_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LEMMA_ENTRY_URL_FILTER_UNKLAR));
        $this->validateClientResponse($this->client);
    }

    /**
     * A functional test that at least checks if single lemma entries with status "neu" are successfully loading.
     */
    public function test_singleEntryFilterNeu_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LEMMA_ENTRY_URL_FILTER_NEU));
        $this->validateClientResponse($this->client);
    }

    /**
     * A functional test that at least checks if single lemma entries with status "keine DDC" are successfully loading.
     */
    public function test_singleEntryFilterNoDdc_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::LEMMA_ENTRY_URL_FILTER_NO_DDC));
        $this->validateClientResponse($this->client);
    }

    /**
     * Validates that the given response is ok.
     *
     * @param Client $client
     */
    private function validateClientResponse($client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url      = $client->getRequest()->getUri();

        self::assertTrue(
            $response->isSuccessful(),
            sprintf(
                "Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertTrue(
            $response->isOk(),
            sprintf(
                "Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf(
                "Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
    }


    /**
     * Validates that the given Client contains the phrase
     *
     * @param Client $client
     * @param string $label Text of the Button that should be found.
     * @param string $listId Name of the class used, to define the region on the button
     *
     * @return bool
     */
    private function isButtonAvailable(Client $client, string $label, string $listId): bool
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($label, 'Label');
        Preconditions::notNull($listId, 'Id');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();
        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//div[contains(@id,'".$listId."')]//a[contains(@class,'primary')]");

        if ($matches[0] === null) {
            echo 'Es wurde keine Node gefunden!';

            return false;
        }

        if (count($matches) === 1) {
            self::assertSame(
                trim($label, "\ \t\n\r\0\x0B"),
                trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
                "Der Text stimmt nicht mit dem Label überein!"
            ); //Trim because Element could have Spaces etc.

            return true;
        }

        return false;
    }


    /**
     * Validates that the given Client contains the phrase
     *
     * @param Client $client
     * @param string $status Text of the Status: unklar, klar, neu
     *
     * @return bool
     */
    private function isStatusAvailableSingeEntry(Client $client, string $status): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//option[contains(@selected,'selected')]");

        self::assertNotNull($matches[0], "No Status for the entry was found!");

        if (count($matches) === 1) {
            self::assertSame(
                trim($status, "\ \t\n\r\0\x0B"),
                trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
                "Der Text stimmt nicht mit dem Label überein!"
            ); //Trim because Element could have Spaces etc.

            return true;
        }

        return false;
    }
}
