<?php


namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Controller\BandSegmentation\BandSegmentationController;
use AppBundle\Util\Preconditions;
use DOMDocument;
use DOMXPath;
use Symfony\Bundle\FrameworkBundle\Client;
use Tests\AppBundle\Controller\BaseWebTestCase;
use Tests\AppBundle\Util\HtmlContentUtils;
use Tests\AppBundle\Util\StringTestItem;

class BandSegmentationTest
    extends BaseWebTestCase
{
    const HTTP_OK = 200;
    const BAND    = 1;

    const ERROR_LIST_ROOT = 'fehler_liste';

    const ERROR_LIST_OVERVIEW   = self::ERROR_LIST_ROOT;
    const ERROR_LIST_FIRST_PAGE = self::ERROR_LIST_ROOT.'/band/'.self::BAND.'?pageNumber=1';
    const ERROR_LIST_ALL        = self::ERROR_LIST_ROOT.'/band/'.self::BAND.'?noPagination';

    const PAGED_MENU = 'Alle Fehler aus Band '.self::BAND.' (Seitenweise)';
    const ALL_MENU   = 'Alle Fehler aus Band '.self::BAND.' (auf einer Seite)';

    const MODULE_HEADLINE   = 'Band-Analyse: Segmentierungsfehler';
    const OVERVIEW_HEADLINE = 'Bände der Dietrich-Bibliographie';
    const BAND_HEADLINE     = 'Band '.self::BAND;

    const FIRST_ENTRY_EID    = '900001000';
    const FIRST_ENTRY_LEMMA  = 'First_Entry';
    const FIRST_ENTRY_ERROR1 = 'Am Anfang des Autoren-Bereiches steht Nummer bzw. Satzzeichen!';

    const LAST_ENTRY_EID    = '900040000';
    const LAST_ENTRY_LEMMA  = 'Last_entry';
    const LAST_ENTRY_ERROR1 = '<entry> => Mehrfach Autor/<a>';
    const LAST_ENTRY_ERROR2 = "Im Bereich gibt es keine ungültige Zeichen wie '^' oder '^^'!";

    const TEXT_ERRORS_FIRST_ENTRY = [self::FIRST_ENTRY_ERROR1];
    const TEXT_ERRORS_LAST_ENTRY  = [self::LAST_ENTRY_ERROR1, self::LAST_ENTRY_ERROR2];

    public function setUp()
    {
        parent::setUp();
    }

    public function test_allPagesAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_OVERVIEW));
        $this->validateClientResponse($this->client);

        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_FIRST_PAGE));
        $this->validateClientResponse($this->client);

        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_ALL));
        $this->validateClientResponse($this->client);
    }

    public function test_isDefaultItemsPerPageNotZero_isSuccessful()
    {
        self::assertNotSame(
            0,
            BandSegmentationController::DEFAULT_ITEMS_PER_PAGE,
            "The default Number of the Items per Page is Zero!"
        );
    }

    public function test_isBandButton_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_OVERVIEW));
        self::assertTrue(
            $this->checkBandButton($this->client, self::BAND),
            sprintf('Band Button could not be validated!')
        );
    }

    public function test_areHeadlinesAvailableOverview_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_OVERVIEW));


        $moduleHeadline = new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY);
        $headline       = new StringTestItem(self::OVERVIEW_HEADLINE, StringTestItem::CONTAINS_EXACTLY);

        if ($moduleHeadline !== null) {
            self::assertTrue(
                HtmlContentUtils::isTopLevelMenuAvailable($this->client, $moduleHeadline),
                sprintf('Headline of <%s> could not be validated.', $moduleHeadline->getString())
            );
        }

        if ($headline !== null) {
            self::assertTrue(
                HtmlContentUtils::isHeadlineAvailable($this->client, $headline, 2),
                sprintf('Headline of <%s> could not be validated.', $headline->getString())
            );
        }
    }

    public function test_areHeadlinesAvailableBand_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_FIRST_PAGE));

        $moduleHeadline = new StringTestItem(self::MODULE_HEADLINE, StringTestItem::CONTAINS_EXACTLY);
        $headline       = new StringTestItem(self::BAND_HEADLINE, StringTestItem::CONTAINS_BLURRY);


        if ($moduleHeadline !== null) {
            self::assertTrue(
                HtmlContentUtils::isTopLevelMenuAvailable($this->client, $moduleHeadline),
                sprintf('Headline of <%s> could not be validated.', $moduleHeadline->getString())
            );
        }

        if ($headline !== null) {
            self::assertTrue(
                HtmlContentUtils::isHeadlineAvailable($this->client, $headline, 2),
                sprintf('Headline of <%s> could not be validated.', $headline->getString())
            );
        }
    }

    public function test_isPagedMenuAndFirstEntryAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_FIRST_PAGE));

        $this->validateEntry(
            $this->client,
            self::FIRST_ENTRY_EID,
            self::FIRST_ENTRY_LEMMA,
            self::TEXT_ERRORS_FIRST_ENTRY
        );

        $this->isMenuAvailable($this->client, self::PAGED_MENU);
    }

    public function test_isAllMenuAndLastEntryAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_ALL));

        $this->validateEntry($this->client, self::LAST_ENTRY_EID, self::LAST_ENTRY_LEMMA, self::TEXT_ERRORS_LAST_ENTRY);

        $this->isMenuAvailable($this->client, self::ALL_MENU);
    }

    public function test_isGotoButtonAvailable_isSuccessful()
    {
        $this->client->request('GET', $this->getTestHostUrl(self::ERROR_LIST_FIRST_PAGE));

        $this->checkGotoButton($this->client);
    }



    /**
     * Validates that the given response is ok.
     *
     * @param Client $client
     */
    private function validateClientResponse(Client $client)
    {
        Preconditions::notNull($client, 'Client');

        $response = $client->getResponse();
        $url      = $client->getRequest()->getUri();

        self::assertTrue(
            $response->isSuccessful(),
            sprintf(
                "Response for url '%s' is not successful (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertTrue(
            $response->isOk(),
            sprintf(
                "Response for url '%s' is not ok (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
        self::assertEquals(
            self::HTTP_OK,
            $response->getStatusCode(),
            sprintf(
                "Response for url '%s' is not 200 (got code: '%s')\n",
                $url,
                $this->client->getResponse()->getStatusCode()
            )
        );
    }


    /**
     * Validates that the given Client contains the phrase
     *
     * @param Client $client
     * @param string $menuLabel Text of the Menu that should be found. Can contain HTML if wanted
     *
     * @return bool
     */
    private function isMenuAvailable(Client $client, string $menuLabel): bool
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($menuLabel, 'MenuLabel');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//div[@class='item'][not(@href)]");

        self::assertNotNull($matches[0], 'No menu label could be found.');
        self::assertEquals(1, count($matches), 'More than one menu label found.');

        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim($menuLabel, "\ \t\n\r\0\x0B"),
            trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'The menu label has not the right value!'
        );


        return true;
    }

    /**
     * Validates if the Band Button is there
     *
     * @param Client $client
     * @param string $bandNo
     *
     * @return bool
     */
    private function checkBandButton(Client $client, string $bandNo): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//a[contains(@class,'band')]");

        self::assertNotNull($matches[0], 'No Band buttons were found.');

        $bandFound = false;
        foreach ($matches as $match) {
            if ($bandNo == trim($match->nodeValue, "\ \t\n\r\0\x0B")) {
                $bandFound = true;
            }
        }

        return $bandFound;
    }

    /**
     * Validates if the Goto Button is there
     *
     * @param Client $client
     *
     * @return bool
     */
    private function checkGotoButton(Client $client): bool
    {
        Preconditions::notNull($client, 'Client');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//div[contains(@class,'gotoButton')]");

        self::assertNotNull($matches[0], 'The goto-Button was not found.');
        self::assertEquals(1, count($matches), 'More than one goto-Button was found.');

        return true;
    }


    /**
     * Validates if the given Data matches a row in the Error-Table
     *
     * @param Client $client
     * @param string $eid
     * @param string $lemma
     * @param array $allErrors
     *
     * @return bool
     */
    private function validateEntry(Client $client, string $eid, string $lemma, array $allErrors)
    {
        Preconditions::notNull($client, 'Client');
        Preconditions::notNull($eid, 'E-ID');
        Preconditions::notNull($lemma, 'Lemma');
        Preconditions::notNull($allErrors, 'Description');

        $htmlContent = $client->getResponse()->getContent();

        $doc = new DOMDocument();

        @$doc->loadHTML($htmlContent);

        $xpath   = new DOMXpath($doc);
        $matches = $xpath->query("//tr[@id='".$eid."']");

        self::assertNotNull($matches[0], 'No row ith this EID found.');
        self::assertEquals(1, count($matches), 'More than on row with this EID found.');

        $matches = $xpath->query("//tr[@id='".$eid."']/td[1]");

        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim($lemma, "\ \t\n\r\0\x0B"),
            trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'The lemma element does not match the given string!'
        );

        $matches = $xpath->query("//tr[@id='".$eid."']/td[2]");
        //Trim because Element could have Spaces etc.
        self::assertSame(
            trim($eid, "\ \t\n\r\0\x0B"),
            trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
            'The EID element does not match the given string!'
        );

        $matches = $xpath->query("//tr[@id='".$eid."']/td[6]");
        //Trim because Element could have Spaces etc.

        foreach ($allErrors as $error) {
            self::assertContains(
                trim($error, "\ \t\n\r\0\x0B"),
                trim($matches[0]->nodeValue, "\ \t\n\r\0\x0B"),
                'The Error Description element does not match the given string!'
            );
        }

        return true;
    }
}
