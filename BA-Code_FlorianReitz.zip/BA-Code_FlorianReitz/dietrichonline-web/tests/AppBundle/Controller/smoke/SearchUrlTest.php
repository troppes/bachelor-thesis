<?php
/**
 * Created by PhpStorm.
 * User: kock
 * Date: 20.11.2018
 * Time: 15:08
 */

namespace Tests\AppBundle\Controller\smoke;

use AppBundle\NativeSql\UserSearchItem;
use AppBundle\Util\Preconditions;
use Tests\AppBundle\Controller\BaseWebTestCase;

/**
 * The class SearchUrlTest contains some rough test cases to assure the basic function of the search mask.
 * <p>
 * The most cases are represent a kind of URL calling in combination with a more kind of smoke test.
 *
 * @package Tests\AppBundle\Controller\smoke
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class SearchUrlTest
    extends BaseWebTestCase
{
    const URL = 'suche';

    const HTML_BLOCK_SEARCH_RESULTS_COUNT = 'search-result-count';

    public function setUp()
    {
        parent::setUp();
        $this->client->request('GET', $this->getTestHostUrl(self::URL));
    }

    /**
     * Tests the equality of a short and long search URL.
     * <p>
     * Equality means, that the expected results should be equal.
     * In our first case, we test that both results return a similiar count.
     */
    public function test_shortUrlsHasSameResultsAsFullUrl()
    {
        $shortUrl = 'http://localhost:8000/suche?user_search[k1]=1&user_search[b1]=Trier&user_search[j1]=2';
        $longUrl = 'http://localhost:8000/suche?user_search%5Bk1%5D=1&user_search%5Bb1%5D=Trier&user_search%5Bj1%5D=2&user_search%5Bk2%5D=1&user_search%5Bb2%5D=&user_search%5Bj2%5D=2&user_search%5Bk3%5D=1&user_search%5Bb3%5D=&user_search%5Bj3%5D=2&user_search%5Bk4%5D=1&user_search%5Bb4%5D=&user_search%5Bj4%5D=2&user_search%5Bk5%5D=1&user_search%5Bb5%5D=&user_search%5Bj5%5D=2&user_search%5Bk6%5D=1&user_search%5Bb6%5D=&user_search%5Bj6%5D=2&user_search%5Bk7%5D=1&user_search%5Bb7%5D=&user_search%5Bj7%5D=2&user_search%5Bk8%5D=1&user_search%5Bb8%5D=&user_search%5Bj8%5D=2&user_search%5Bk9%5D=1&user_search%5Bb9%5D=&user_search%5Bj9%5D=2&user_search%5Bk10%5D=1&user_search%5Bb10%5D=&user_search%5Bj10%5D=2&user_search%5Bk11%5D=1&user_search%5Bb11%5D=&user_search%5BvonJahr%5D=&user_search%5BbisJahr%5D=';
        // test only if more than 30 are available, otherwise we need db access and thats to much as starter
        $this->assertTrue($this->doesPageContainResultCountMinimumOne($shortUrl));
        $this->assertTrue($this->doesPageContainResultCountMinimumOne($longUrl));
    }

    public function test_validIdHasOnlyOneResult()
    {
        $validId = 920014300;

        $urlValidId = 'http://localhost:8000/suche?user_search[k1]=13&user_search[b1]=' . $validId;

        $this->assertTrue($this->doesPageContainOneResultExactly($urlValidId));

    }


    /**
     * Tests the search URL with an empty ID.
     * <p>
     * It's special for, because here no active search will be executed and so no result and no information are expected.
     */
    public function test_emptyIDHasNoResults()
    {

        $emptyString = '';
        $willSearchExecuted = false;

        $urlEmptyString = 'http://localhost:8000/suche?user_search[k1]=13&user_search[b1]=' . $emptyString;

        $this->assertTrue($this->doesPageContainNoResult($urlEmptyString, $willSearchExecuted));
    }


    public function test_invalidIDHasNoResults()
    {

        $idRepeated = 920014300920014300920014300;
        $urlIDRepeated = 'http://localhost:8000/suche?user_search[k1]=13&user_search[b1]=' . $idRepeated;

        $this->assertTrue($this->doesPageContainNoResult($urlIDRepeated));
    }


    public function test_idWithSpacesHasNoResults()
    {

        $idWithSpaces = '920014 300';
        $textWithSpaces = 'Test mit Leerzeichen';

        $urlTextWithSpaces = 'http://localhost:8000/suche?user_search[k1]=13&user_search[b1]=' . $textWithSpaces;
        $urlIDWithSpaces = 'http://localhost:8000/suche?user_search[k1]=13&user_search[b1]=' . $idWithSpaces;

        $this->assertTrue($this->doesPageContainNoResult($urlTextWithSpaces));
        $this->assertTrue($this->doesPageContainNoResult($urlIDWithSpaces));
    }


    public function test_idWithTextHasNoResults()
    {

        $text = "Text";

        $urlText = 'http://localhost:8000/suche?user_search[k1]=13&user_search[b1]=' . $text;

        $this->assertTrue($this->doesPageContainNoResult($urlText));
    }


    /**
     * Tests if a search url with AND combined terms delivers one result.
     * <p>
     * The defined url searches for ARTIKEL `Test` AND ARTIKEL-ID `920548790`.
     */
    public function test_andCombinedSearchUrl_successfulDeliversOneResult()
    {
        $titel = 'Test';
        $titelType = UserSearchItem::TYPE_ARTIKEL;
        $articleId = 920548790;
        $articleType = UserSearchItem::TYPE_ID;
        $junktor = UserSearchItem::JUNKTOR_AND;

        $url = 'http://localhost:8000/suche?user_search[k1]=' . $titelType . '&user_search[b1]=' . $titel . '&user_search[j1]=' . $junktor . '&user_search[k2]=' . $articleType . '&user_search[b2]=' . $articleId;

        $this->assertTrue($this->doesPageContainOneResultExactly($url));
    }


    /**
     * Tests if a search url with OR combined terms delivers a minimum of one result.
     * <p>
     * The defined url searches for ARTIKEL `Test` OR ARTIKEL-ID `920548790`.
     */
    public function test_orCombinedSearchUrl_successfulDeliversMultiResults()
    {
        $titel = 'Test';
        $titelType = UserSearchItem::TYPE_ARTIKEL;
        $articleId = 920548790;
        $articleType = UserSearchItem::TYPE_ID;
        $junktor = UserSearchItem::JUNKTOR_OR;

        $url = 'http://localhost:8000/suche?user_search[k1]=3&user_search[b1]=test&user_search[j1]=3&user_search[k2]=13&user_search[b2]=920548790';

        $this->assertTrue($this->doesPageContainResultCountMinimumOne($url));
    }


    /**
     * Tests if a search url with AND NOT combined terms delivers a minimum of one result.
     * <p>
     * The defined url searches for ARTIKEL `Test` AND NOT ARTIKEL-ID `920548790`.
     */
    public function test_andNotCombinedSearchUrl_successfulDeliversMultiResults()
    {
        $titel = 'Test';
        $titelType = UserSearchItem::TYPE_ARTIKEL;
        $articleId = 920548790;
        $articleType = UserSearchItem::TYPE_ID;
        $junktor = UserSearchItem::JUNKTOR_AND_NOT;

        $url = 'http://localhost:8000/suche?user_search[k1]=3&user_search[b1]=test&user_search[j1]=4&user_search[k2]=13&user_search[b2]=920548790';

        $this->assertTrue($this->doesPageContainResultCountMinimumOne($url));
    }

    /**
     * Test for attribute in  SearchNormalization::getCleanedFulltextSearchTermString().
     * <p>
     * A simple test for results is ok, because if we run getStringWithReplacedFulltextEngineKeywords() in this combination with NO_SPACE the search will fail.
     */
    public function test_fulltextEngineKeywordIsReplaced_successfulDeliversMultiResults()
    {
        $twoWordsCombinedWithSpace = 'http://localhost:8000/suche?user_search%5Bk1%5D=3&user_search%5Bb1%5D=trier%20flug';
        $twoWordsCombinedWithKeywordPlus = 'http://localhost:8000/suche?user_search%5Bk1%5D=3&user_search%5Bb1%5D=trier%2Bflug';

        // test only if more than 30 are available, otherwise we need db access and that is to much as starter
        $this->assertTrue($this->doesPageContainResultCountMinimumOne($twoWordsCombinedWithSpace));
        $this->assertTrue($this->doesPageContainResultCountMinimumOne($twoWordsCombinedWithKeywordPlus));
    }


    /**
     * Returns <code>true</code> if a minimum of one result exists on the response url.
     *
     * @param string $url The URL for count lookup
     * @return bool Returns <code>true</code> if the expected minimum of one result exists, otherwise if will fail with an assertion.
     */
    private function doesPageContainResultCountMinimumOne(string $url): bool
    {
        Preconditions::notEmpty($url, 'url');
        $countMin = 1;

        $expectedSearchResultMsg = sprintf('Suchtreffer %d -', $countMin);

        $searchPageClient = static::createClient();
        $searchPageClient->followRedirects();
        $spc = $searchPageClient->request('GET', $url);

        $this->assertNotNull($spc);
        $searchResultContent = $searchPageClient->getResponse()->getContent();
        $this->assertContains(self::HTML_BLOCK_SEARCH_RESULTS_COUNT, $searchResultContent);
        $this->assertContains($expectedSearchResultMsg, $searchResultContent);

        return true;
    }


    /**
     * Returns <code>true</code> if exactly one result exists on the response url.
     *
     * @param string $url The URL for count lookup
     * @return bool Returns <code>true</code> if the expected value of one result exists, otherwise if will fail with an assertion.
     */
    private function doesPageContainOneResultExactly(string $url): bool
    {
        Preconditions::notEmpty($url, 'url');

        $expectedSearchResultMsg = 'Suchtreffer 1 - 1 von insgesamt 1';

        $searchPageClient = static::createClient();
        $searchPageClient->followRedirects();
        $spc = $searchPageClient->request('GET', $url);

        $this->assertNotNull($spc);
        $searchResultContent = $searchPageClient->getResponse()->getContent();
        $this->assertContains(self::HTML_BLOCK_SEARCH_RESULTS_COUNT, $searchResultContent);
        $this->assertContains($expectedSearchResultMsg, $searchResultContent);

        return true;
    }


    /**
     * Returns <code>true</code> if exactly no results exist on the response url.
     * <p>
     * The given $searchWillBeExecuted parameter is special, because some empty searches does not trigger the
     * search execution and so no information will be delivered to the client instead of a no results found message.
     *
     * @param string $url The URL for count lookup
     * @param bool $searchWillBeExecuted Flag if the search will be really triggered or not.
     *
     * @return bool Returns <code>true</code> if the expected value of none result exists, otherwise if will fail with an assertion.
     */
    private function doesPageContainNoResult(string $url, bool $searchWillBeExecuted = true): bool
    {
        Preconditions::notEmpty($url, 'url');

        $unexpectedSearchResultMsg = sprintf('Suchtreffer 1 -');
        $expectedSearchResultMsg = 'Die Suche ergab keine Treffer.';

        $searchPageClient = static::createClient();
        $searchPageClient->followRedirects();
        $spc = $searchPageClient->request('GET', $url);

        $this->assertNotNull($spc);
        $searchResultContent = $searchPageClient->getResponse()->getContent();
        $this->assertNotContains($unexpectedSearchResultMsg, $searchResultContent); // Check for not Contains since Empty Searches dont include "Die Suche ergab keine Treffer."

        // checks if a 'no search results' message will be shown
        if ($searchWillBeExecuted)
        {
            $this->assertContains($expectedSearchResultMsg, $searchResultContent);
        }

        return true;
    }
}