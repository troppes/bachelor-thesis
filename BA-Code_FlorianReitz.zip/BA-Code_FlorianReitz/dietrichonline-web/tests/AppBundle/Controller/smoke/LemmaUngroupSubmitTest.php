<?php

namespace Tests\AppBundle\Controller\smoke;

use AppBundle\Controller\LemmaAdministration\LemmaGroupController;
use AppBundle\Entity\LemmaEntity;
use AppBundle\Feature\FeatureBase;
use AppBundle\Repository\LemmaRepository;
use Doctrine\ORM\EntityManager;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Tests\AppBundle\Controller\BaseWebTestCase;

class LemmaUngroupSubmitTest
    extends BaseWebTestCase
{
    const LEMMA_IDS        = ['100510', '51199', '12517'];
    const MASTER_LEMMA_ID  = '100510';
    const UNGROUP_LEMMA_ID = '12517';

    /**
     * @var EntityManager
     */
    private $doctrineManager;

    /**
     * @var LemmaRepository
     */
    private $lemmaRepo;

    /**
     * @var Router
     */
    private $router;

    public function setUp()
    {
        parent::setUp();

        $this->router = $this->container->get('router');
        $this->doctrineManager = $this->container->get('doctrine')->getManager(FeatureBase::DB_BACKEND);
        $this->lemmaRepo = $this->doctrineManager->getRepository(LemmaEntity::class);

        // assert master lemma unset
        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            self::assertNull($lemma->getMasterLemma(), "setup failed: master lemma of $lemmaId must be null");
        }

        // make group request with master lemma
        $url = $this->router->generate(LemmaGroupController::MASTER_LEMMA_SUBMIT_ROUTE);
        $params = [];
        foreach (self::LEMMA_IDS as $lemmaId) {
            $params[LemmaGroupController::LEMMA_IDS_KEY][] = $lemmaId;
        }
        $params[LemmaGroupController::MASTER_LEMMA_ID_KEY] = self::MASTER_LEMMA_ID;
        $this->client->request('POST', $url, $params);
    }

    public function tearDown()
    {
        parent::tearDown();

        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            $lemma->setMasterLemma(null);
        }
        $this->doctrineManager->flush();
    }

    public function test_responseStatusCode_valid()
    {
        $response = $this->client->getResponse();
        $this->assertTrue($response->isSuccessful() || $response->isRedirect());
    }

    public function test_MasterLemmaStructureAfterUngroup1_valid()
    {
        // make ungroup request
        $url = $this->router->generate('ungroup_lemma_action', ['subLemmaId' => self::UNGROUP_LEMMA_ID]);
        $this->client->request('POST', $url);

        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            self::assertNotNull($lemma, "cannot find lemma with id $lemmaId");
            if ($lemmaId === self::UNGROUP_LEMMA_ID) {
                self::assertNull($lemma->getMasterLemma(), "master lemma of lemma $lemmaId must be null.");
            } else {
                self::assertNotNull($lemma->getMasterLemma(), "master lemma of lemma $lemmaId must not be null.");
                self::assertEquals(self::MASTER_LEMMA_ID, $lemma->getMasterLemma()->getId());
            }
        }
    }

    public function test_masterLemmaStructureAfterUngroupAllSubLemmas_valid()
    {
        $subLemmaIds = [];
        foreach (self::LEMMA_IDS as $lemmaId) {
            if ($lemmaId !== self::MASTER_LEMMA_ID) {
                $subLemmaIds[] = $lemmaId;
            }
        }

        foreach ($subLemmaIds as $subLemmaId) {
            $url = $this->router->generate('ungroup_lemma_action', ['subLemmaId' => $subLemmaId]);
            $this->client->request('POST', $url);
        }

        foreach (self::LEMMA_IDS as $lemmaId) {
            /** @var LemmaEntity $lemma */
            $lemma = $this->lemmaRepo->find($lemmaId);
            self::assertNull($lemma->getMasterLemma());
        }
    }
}
