<?php

namespace Tests\AppBundle\Controller;


/**
 * Class KontaktPageTest
 *
 * @package Tests\AppBundle\Controller
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class KontaktPageTest extends BaseWebTestCase
{
    const URL = 'kontakt';

    /** @var array crawler extraction config. */
    const EMAIL_CRAWLER = [
        self::EMAIL_CRAWLER_HREF_POSITION => self::EMAIL_CRAWLER_HREF_PARAM_NAME,
        self::EMAIL_CRAWLER_TEXT_POSITION => self::EMAIL_CRAWLER_TEXT_PARAM_NAME
    ];

    const EMAIL_CRAWLER_HREF_PARAM_NAME = 'href';
    const EMAIL_CRAWLER_HREF_POSITION = 0;
    const EMAIL_CRAWLER_TEXT_PARAM_NAME = '_text';
    const EMAIL_CRAWLER_TEXT_POSITION = 1;

    /** @var string The email address contact the dietrich team. */
    const DIETRICH_CONTACT_EMAIL = 'dietrichonline@uni-trier.de';
    /** @var string The generated default subject of an email. */
    const DIETRICH_CONTACT_EMAIL_SUBJECT = 'Dietrich%20Kontakt';


    public function setUp()
    {
        parent::setUp();
        $this->client->request('GET', $this->getTestHostUrl(self::URL));
    }


    /**
     * Tests that the application pages is successfully loading.
     */
    public function test_doesPageExists_success()
    {
        $this->assertTrue($this->client->getResponse()->isOk());
        $this->assertTrue($this->client->getResponse()->isSuccessful());
    }


    /**
     * Tests that only one email address is on the page.
     */
    public function test_oneEmailAddressAvailableOnly()
    {
        $expectedEmailAddressesOnPage = 1;
        $linksOnPage = $this->client
            ->getCrawler()
            ->filterXpath('//a')
            ->extract(self::EMAIL_CRAWLER);

        $emailsOnPage = $this->getEmailAddressesFromLink($linksOnPage);

        $this->assertGreaterThan(0, $linksOnPage);
        $this->assertLessThan($linksOnPage, $emailsOnPage);
        $this->assertCount($expectedEmailAddressesOnPage, $emailsOnPage);

    }


    /**
     * Tests that the contact email address is on the page with default mail open tag.
     * <p>
     * Tests that:
     * <ol>
     * <li>more than zero emails exists on the page
     * <li><code>text</code> parameter of email link is the dietrich email
     * <li><code>href</code> parameter of email link contains the dietrich email
     * <li><code>href</code> parameter of email link contains the value technical mailto value
     * <li><code>href</code> parameter of email link contains the technical subject value
     * <li><code>href</code> parameter of email link contains the dietrich default subject
     * </ol>
     */
    public function test_contactEmailAddressIsAvailable()
    {
        $contactEmailAddress = self::DIETRICH_CONTACT_EMAIL;
        $emailSubject = self::DIETRICH_CONTACT_EMAIL_SUBJECT;
        $emailMailtoPrefix = 'mailto:';
        $emailSubjectPrefix = '?subject=';

        $linksOnPage = $this->client
            ->getCrawler()
            ->filterXpath('//a')
            ->extract(self::EMAIL_CRAWLER);
        $emailsOnPage = $this->getEmailAddressesFromLink($linksOnPage);

        $this->assertGreaterThan(0, $linksOnPage);
        foreach ($emailsOnPage as $emailItem)
        {
            $this->assertEquals($contactEmailAddress, $emailItem[self::EMAIL_CRAWLER_TEXT_POSITION]);
            $this->assertContains($contactEmailAddress, $emailItem[self::EMAIL_CRAWLER_HREF_POSITION]);
            $this->assertContains($emailMailtoPrefix, $emailItem[self::EMAIL_CRAWLER_HREF_POSITION]);
            $this->assertContains($emailSubjectPrefix, $emailItem[self::EMAIL_CRAWLER_HREF_POSITION]);
            $this->assertContains($emailSubject, $emailItem[self::EMAIL_CRAWLER_HREF_POSITION]);
        }
    }


    /**
     * Returns the extracted email addresses of the given crawler links.
     * <p>
     * Is solved via <code>@</code> symbol lookup in the technical <code>href</code> parameter.
     * <p>
     * The result array contains the same key order like the given input $links.
     *
     * @param string[] $links the links of the crawler
     * @return array The extracted email addresses, otherwise an empty array
     */
    private function getEmailAddressesFromLink($links): array
    {
        $emailsOnPage = [];

        foreach ($links as $link)
        {
            if (\strpos($link[self::EMAIL_CRAWLER_HREF_POSITION], '@') !== false)
            {
                $emailsOnPage = [$link];
            }
        }

        return $emailsOnPage;
    }
}