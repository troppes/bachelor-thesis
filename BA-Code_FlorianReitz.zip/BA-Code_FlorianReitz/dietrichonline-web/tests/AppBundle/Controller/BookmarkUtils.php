<?php
/**
 * Created by PhpStorm.
 * User: kock
 * Date: 16.08.2018
 * Time: 16:28
 */

namespace Tests\AppBundle\Controller;


class BookmarkUtils
{
    /**
     * Returns the number of stored bookmarks.
     *
     * @param string $pageContent
     * @return int The count of the bookmarks, otherwise 0 (if no bookmarks in the content too).
     */
    public static function getBookmarkCount($pageContent): int
    {
        $count = 0;

        if ($pageContent !== null)
        {
            $pattern = "/<b id=\"bookmark-counter\" >(.*?)<\/b>/";
            preg_match($pattern, $pageContent, $matches);

            if (isset($matches[1]) AND $matches !== '')
            {
                $count = intval($matches[1]);
            }
        }

        return $count;
    }
}