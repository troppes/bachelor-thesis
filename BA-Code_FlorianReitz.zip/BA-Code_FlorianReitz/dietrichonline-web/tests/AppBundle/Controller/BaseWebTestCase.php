<?php


namespace Tests\AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Client;
use Symfony\Bundle\FrameworkBundle\Routing\Router;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

/**
 * Description of BaseWebTestCase
 * <p>
 * Followed some informations <a href='https://blog.joeymasip.com/symfony-3-4-phpunit-testing-database-data/'>here</a>.
 *
 * @author Martin Kock <kock@uni-trier.de>
 */
class BaseWebTestCase extends WebTestCase
{

    private static $TEST_HOST_PARAMETER_NAME = 'test.hostname';

    /** @var  Application $application */
    protected static $application;

    /** @var Client $client */
    protected $client;

    /** @var  ContainerInterface $container */
    protected $container;

    /** @var  EntityManager $entityManager */
    protected $entityManager;

    public function setUp()
    {
        $this->client = static::createClient();
        $this->container = $this->client->getContainer();
        $this->entityManager = $this->container->get('doctrine.orm.entity_manager');

        parent::setUp();
    }

    protected static function getApplication()
    {
        if (null === self::$application)
        {
            $client = static::createClient();

            self::$application = new Application($client->getKernel());
            self::$application->setAutoExit(false);
        }

        return self::$application;
    }

    protected function getTestHostUrl($path = '')
    {
        return $this->client->getContainer()->getParameter(self::$TEST_HOST_PARAMETER_NAME) . '/' . $path;
    }

    /**
     * @return Router
     */
    protected function getRouter(): Router
    {
        return $this->container->get('router');
    }

    protected function tearDown()
    {
        parent::tearDown();

        $this->entityManager->close();
        $this->entityManager = null; // avoid memory leaks
    }

}
