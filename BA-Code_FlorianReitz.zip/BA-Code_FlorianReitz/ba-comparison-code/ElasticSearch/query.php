<?php
require_once(__DIR__."/../vendor/autoload.php");
use Elasticsearch\ClientBuilder;

$clientBuilder = ClientBuilder::create()->setHosts(['136.199.34.55']);
$client        = $clientBuilder->build();
$timeAcc = 0;
$time = 0;
$params = [
    'index' => 'lemma',
    'body' => [
        'size' => 1000000,
        'query' => [
            "wildcard" => ["bezeichnung.keyword" => "S*"],
        ],
    ],
];

for($i = 0; $i < 100; $i++){
    $time_start = microtime(true);
    $results = $client->search($params);
    $time_end = microtime(true);

    $time = $time_end - $time_start;
    $timeAcc += $time;
    $count=0;
    foreach ($results['hits']['hits'] as $hit){
        $count++;
    }
    echo "Ran Query#$i. It took $time seconds and got $count Results. <br/>";
}
$median = round($timeAcc/100, 2);
$time = round($time);
echo "Ran Query 100 Times. It took $timeAcc seconds and got $count Results. The Median was $median seconds. \r\n";
