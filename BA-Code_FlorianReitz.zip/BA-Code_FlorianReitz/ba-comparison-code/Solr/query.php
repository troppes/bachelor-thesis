<?php
require_once(__DIR__."/../vendor/autoload.php");
use Solarium\Client;

$timeAcc = 0;
$time = 0;
$config = array(
    'endpoint' => array(
        'localhost' => array(
            'host' => '136.199.34.55',
            'port' => 8983,
            'core' => 'dietrich',
        )
    )
);

$queryLemmaS = 'original_bezeichnung:S*';
$queryErrorList = 'originalText:*';

$solr = new Client($config);
$query = $solr->createSelect();
$query->setQuery($queryErrorList);
$query->setRows(2147483647);

for($i = 0; $i < 100; $i++){
    $time_start = microtime(true);
    $resultSet = $solr->select($query);
    $time_end = microtime(true);

    $time = $time_end - $time_start;
    $timeAcc += $time;
    $count = $resultSet->count();
    echo "Ran Query#$i '$queryErrorList'. It took $time seconds and got $count Results.";
}

$median = round($timeAcc/100, 2);
$time = round($time);
echo "Ran Query '$queryErrorList' 100 Times. It took $timeAcc seconds and got $count Results. The Median was $median seconds. \r\n";









