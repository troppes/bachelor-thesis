<?php
require_once("xapian.php");

$servername = "localhost";
$username   = "datafari";
$password   = "123456";
$db         = 'dietrichonline';

$xapianDb = 'db';

$sql = "SELECT lemma.id,
             lemma.bezeichnung,
             lemma.original_bezeichnung,
             lemma.erweiterung,
             lemma.original_homonym_zusatz,
             lemma.neuer_homonym_zusatz,
             lemma.allgemeinebemerkung,
             lemma.ist_gnd_verzeichnet,
             lemma.ist_geloescht,
             lemma.verweis,
             lemmaBStatus.bezeichnung bStatusBezeichnung,
             lemmaBStatus.beschreibung AS bStatusBeschreibung,
             gnd.nummer AS gndNummer,
             gnd.schlagwort AS gndSchlagwort,
             ddc.notation AS gndNotation,
             ddc.schlagwort AS ddcSchlagwort,
             ddc.webdewey_is_checked AS ddcWebdeweyCheck
      FROM lemma lemma
               INNER JOIN lemmabearbeitungsstatus lemmaBStatus ON lemma.fk_lemmabearbeitungsstatus = lemmaBStatus.id
               LEFT JOIN lemma_gnd lemma_gnd_map ON lemma.id = lemma_gnd_map.fk_lemma
               LEFT JOIN gnd gnd ON lemma_gnd_map.fk_gnd = gnd.id
               LEFT JOIN gnd_ddc gnd_ddc_map ON gnd.id = gnd_ddc_map.fk_gnd
               LEFT JOIN ddc ddc ON gnd_ddc_map.fk_ddc = ddc.id
      WHERE lemma.ist_geloescht = 0";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: ".$conn->connect_error);
}
echo "Connected successfully";

$result = $conn->query($sql);

// Create or open the database we're going to be writing to.
$db = new XapianWritableDatabase($xapianDb, Xapian::DB_CREATE_OR_OPEN);
// Set up a TermGenerator that we'll use in indexing.
$termgenerator = new XapianTermGenerator();
$termgenerator->set_stemmer(new XapianStem('de'));

while ($row = $result->fetch_assoc()) {

    $identifier = $row['id'];
    unset($row['id']);
    $searchIndexLetter = $row['original_bezeichnung'][0];

    $doc = new XapianDocument();
    $termgenerator->set_document($doc);
    $termgenerator->index_text($searchIndexLetter, 1, 'K'); // Index the field with a suitable prefix.
    $termgenerator->index_text($searchIndexLetter); // Make it available for Search

    foreach ($row as $index) {
        if ($index = '') {
            $index = 'EMPTY';
        }
        $termgenerator->increase_termpos();
        $termgenerator->index_text($index);
    }
    $doc->set_data(json_encode($row)); // Store all the fields for display purposes.

    // We use the identifier to ensure each object ends up in the
    // database only once no matter how many times we run the
    // indexer.
    $idterm = "Q".$identifier;
    $doc->add_boolean_term($idterm);
    $db->replace_document($idterm, $doc);

    print_r("Sucessfully imported Line \n");
}

$conn->close();