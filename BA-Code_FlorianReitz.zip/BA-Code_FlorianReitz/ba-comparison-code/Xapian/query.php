<?php
require_once("xapian.php");

// Open the database we're going to search.
$db = new XapianDatabase('db');

$timeAcc = 0;
$time = 0;

$queryParser = new XapianQueryParser();
$queryParser->add_prefix("searchIndexLetter", "K"); //Set Prefix for search so we search the rights column
$query = $queryParser->parse_query('S'); // Parse Query

for($i = 0; $i < 100; $i++){
    $count=0;
    $time_start = microtime(true);

    // Use an Enquire object on the database to run the query
    $enquire = new XapianEnquire($db);
    $enquire->set_query($query);
    $matches = $enquire->get_mset(0, 2147483647)->begin(); // Get Results: First Argument Offset, Second Max Results
    foreach ($matches as $matchID){
        $doc = $matches->get_document()->get_data();
        //$fields = json_decode($doc); // Decode all Data
        $count++;
    }

    $time_end = microtime(true);
    $time = $time_end - $time_start;
    $timeAcc += $time;
    print_r("Ran Query#$i. It took $time seconds and got $count Results. \n");
}

$median = round($timeAcc/100, 2);
$time = round($time);
print_r("Ran Query 100 Times. It took $timeAcc seconds and got $count Results. The Median was $median seconds. \r\n");
