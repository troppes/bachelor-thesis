Der Code von ba-docker und ba-comparison-code ist größtenteils von mir geschrieben worden, mithilfe der Dokumentationen der einzelnen Suchmaschinen.

Im dietrichonline-web wurden im Rahmen der BA vorallem folgende Dateien von mir bearbeitet:

dietrichonline-web\src\AppBundle\Controller\UserSearch\SearchAutocompletionController.php
dietrichonline-web\src\AppBundle\Controller\UserSearch\UserSearchController.php

dietrichonline-web\src\AppBundle\Repository\ArtikelRepository.php
dietrichonline-web\src\AppBundle\Repository\AutocompletableRepository.php
dietrichonline-web\src\AppBundle\Repository\LemmaRepository.php

dietrichonline-web\src\AppBundle\NativeSql\UserSearchItem.php
dietrichonline-web\src\AppBundle\NativeSql\UserSearchSqlBuilder.php